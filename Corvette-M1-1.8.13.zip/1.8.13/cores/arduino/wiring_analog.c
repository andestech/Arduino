#include "Arduino.h"

#ifdef __cplusplus
 extern "C" {
#endif

#define SARADC_WAIT_US    (20)
#define SARADC_DELAY_US    (5)
#define SARADC_SAMPLE_CNT  (30)

uint32_t ResolutionRead = 10;
uint32_t PWMBit = 0;

#define MAX(a,b) ((a>b)?a:b)
#define DIFF(a,b) ((a>b)?(a-b):(b-a))
#define AVGSAMPLE 0
int analogRead(uint8_t pin)
{
    int avg=0,max=0,cnt=0,val[SARADC_SAMPLE_CNT];
    int i=0,j=0;

    if (pin >= 4)
        return 0;

    AGPIO_ENA(pin);
    AGPIO_ENA_SAR_Func(pin);
    sarADC_Init();
    delayMicroseconds(SARADC_DELAY_US);

    for(i=0;i<SARADC_SAMPLE_CNT;i++) //sample adc servel times and average
    {
        sarADC_Start();
        delayMicroseconds(SARADC_WAIT_US);
        val[i]=sarADC_Read(pin);
        max =MAX(max,val[i]);
#if AVGSAMPLE
        if(i==(SARADC_SAMPLE_CNT-1))
        {
            for(j=0;j<SARADC_SAMPLE_CNT;j++)
            {
                if(val[j]>(max*95/100))
                {
                    avg+=val[j];
                    cnt++;
                }
            }
        }
#endif
    }
#if AVGSAMPLE
    avg/=cnt;
#else
    avg=max;
#endif
    //sarADC_DeInit();
    //AGPIO_DIS_SAR_Func(pin);
    //AGPIO_DIS(pin);

    //HW max resolution is actually 10 bits
    if(ResolutionRead)
    {
        #define ADJUST_FACTOR (1.82)
        //HW max resolution is actually 10 bits
        avg *= (1<<ResolutionRead)*ADJUST_FACTOR/1024;
    }

    return avg;
}

void analogReadResolution(uint8_t bit)
{
    int maskbit = 0;
    int i = 0;

    if(bit == 0)
        return;

    if (bit >= 16) //HW max resolution is actually 10 bits
        bit = 16;

//    for(i=0;i<bit;i++)
//        maskbit |= (0x1 << i);
//    ResolutionRead = maskbit;
    ResolutionRead = bit;
}

void analogWrite(uint8_t pin, int val)
{
    uint8_t PwmDiv = 0;
    uint32_t Duty = 0;
    uint32_t period = 0;
    uint32_t frequency = 1000; //make 1KHz frequency

    if((pin != 4)&&(pin != 5)&&(pin != 8)&&(pin != 9))  //only A4 & A5 & D8 &D9 can be set PWM( use PWM0,PWM1)
        return;

    PwmDiv = 0x0;

    period = 32768/frequency; //how many T

    if(val == 0)
        Duty = 0;
    else if(val == 255)
        Duty = period;
    else
        Duty = (period*val)/255;;

    if(PWMBit)
    {
        Duty &= PWMBit;
        period &= PWMBit;
        PWMBit = 0;
    }

    PWM_CLK_EN(pin);
    MTF_PWM_ENA(pin);
    PWM_Set_Clk_Src(pin);
    PWM_Config_Setting(pin,Duty,period-1,PwmDiv);
    PWM_ENA(pin);
}

void analogReference(uint8_t mode)
{
    //The feature is not supported.
}

void analogWriteResolution(uint8_t bit)
{
    int duty_maskbit = 0;
    int i = 0;

    if(bit == 0)
        return;

    if (bit >= 10) //max resolution is 10 bits
        bit = 10;

    for(i=0;i<bit;i++)
        duty_maskbit |= (0x1 << i);

    PWMBit = duty_maskbit;
}

#ifdef __cplusplus
}
#endif
