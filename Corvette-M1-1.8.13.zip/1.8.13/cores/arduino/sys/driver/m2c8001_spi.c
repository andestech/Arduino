#include "m2c8001_spi.h"

void SPI_EnableManualCS(SPI_TypeDef *spiPort)
{
    spiPort->CR0 |=SSP_CTRL0_MANUAL_EN; 
}

void SPI_DisableManualCS(SPI_TypeDef *spiPort)
{
    spiPort->CR0 &= ~SSP_CTRL0_MANUAL_EN; 
}

void SPI_SetCS(SPI_TypeDef *spiPort)
{
    spiPort->CR0 &= ~SSP_CTRL0_MANUAL_VAL; 
}

void SPI_ClrCS(SPI_TypeDef *spiPort)
{
    spiPort->CR0 |= SSP_CTRL0_MANUAL_VAL; 
}

void SPI_SetBitLength(SPI_TypeDef *spiPort,u8 u8Len)
{
    u8 len = (u8Len - 1) & 0x1F;
    spiPort->CR1 = (spiPort->CR1 & ~SSP_CTRL1_SDL) | (len << 16);
}

void SPI_StartTransfer(SPI_TypeDef *spiPort,u32 u32Data)
{
    spiPort->DR = u32Data;
    spiPort->CR2 |= (SSP_CTRL2_SSPEN | SSP_CTRL2_TXDOE);
}

u8 SPI_IsBusy(SPI_TypeDef *spiPort)
{
    return((spiPort->SR & SSP_STAS_BUSY) ? 1:0);
}

u32 SPI_ReadRxFIFO(SPI_TypeDef *spiPort)
{
    return spiPort->DR;
}

void SPI_WriteTxFIFO(SPI_TypeDef *spiPort,u32 u32Data)
{
     spiPort->DR = u32Data;
}

void SPI_ClrTxFIFO(SPI_TypeDef *spiPort)
{
    spiPort->CR2 |= SSP_CTRL2_TXFCLR;
}

void SPI_ClrRxFIFO(SPI_TypeDef *spiPort)
{
    spiPort->CR2 |= SSP_CTRL2_RXFCLR;
}

void SPI_SetClockFreq(SPI_TypeDef *spiPort,u8 u8Div)
{
/* SPI clock PCLK/(2*(divider+1)) */
     spiPort->CR1 = (spiPort->CR1 &~SSP_CTRL1_DIV) | u8Div;
}

void SPI_Init_portonly(SPI_TypeDef *spiPort)
{
    if((u32)spiPort == SPI0_BASE){
    	MFP_SPI0_ENABLE();
        RCU->CSRSWRSTN &= ~RCU_SW_RST_SPI0;
        CGU->PIPCLKSW |= (PIP_EN_SSP0_CLK|PIP_EN_SSP0_APBCLK); //Enable SPI0 clock
    }
    else if((u32)spiPort == SPI1_BASE){
    	MFP_SPI1_ENABLE();
        RCU->CSRSWRSTN &= ~RCU_SW_RST_SPI1;
        CGU->PIPCLKSW |= (PIP_EN_SSP1_CLK); //Enable SPI1 clock
    }
    
    SPI_SetMaster(spiPort);
    SPI_DisableManualCS(spiPort);
}

void SPI_Init(SPI_TypeDef *spiPort,SPI_DATA_t *tParam)
{
    if((u32)spiPort == SPI0_BASE){
        RCU->CSRSWRSTN &= ~RCU_SW_RST_SPI0;
        CGU->PIPCLKSW |= (PIP_EN_SSP0_CLK|PIP_EN_SSP0_APBCLK); //Enable SPI0 clock
    }
    else if((u32)spiPort == SPI1_BASE){
        RCU->CSRSWRSTN &= ~RCU_SW_RST_SPI1;
        CGU->PIPCLKSW |= (PIP_EN_SSP1_CLK|PIP_EN_SSP1_APBCLK); //Enable SPI1 clock
    }
    //SPI_IsrInit(spiPort);//Init SPI ISR callback

    if(tParam->u8Mode == SPI_DRV_MODE_MASTER){/*Master*/
        spiPort->CR0 = SSP_CTRL0_FFMT_SPI | SSP_CTRL0_OPM_MASTER;
        SPI_SetClockFreq(spiPort,tParam->u8Div);
    }
    else{/*Slave*/
        spiPort->CR0 = SSP_CTRL0_FFMT_SPI | SSP_CTRL0_OPM_SLAVE;
        spiPort->CR2 = SSP_CTRL2_SSPEN | SSP_CTRL2_TXDOE;
    }
    if(tParam->u8ClkPhase == SPI_DRV_CLKPH_HALF)
        spiPort->CR0 |= SSP_CTRL0_SCLKPH;
    if(tParam->u8ClkPolarity == SPI_DRV_CLKPO_HIGH)
        spiPort->CR0 |= SSP_CTRL0_SCLKPO;
}

void SPI_DeInit(SPI_TypeDef *spiPort)
{
    if((u32)spiPort == SPI0_BASE)
        CGU->PIPCLKSW &= ~(PIP_EN_SSP0_CLK|PIP_EN_SSP0_APBCLK);
    else if((u32)spiPort == SPI1_BASE)
        CGU->PIPCLKSW &= ~(PIP_EN_SSP1_CLK|PIP_EN_SSP1_APBCLK);

    //SPI_IsrDeInit(spiPort);
}

void SPI_SetMaster(SPI_TypeDef *spiPort)
{
    spiPort->CR0 |= SSP_CTRL0_FFMT_SPI | SSP_CTRL0_OPM_MASTER;
}

void _SPI_SetDataMode(SPI_TypeDef *spiPort,SPI_DATA_t *tParam)
{
    if(tParam->u8ClkPhase == SPI_DRV_CLKPH_HALF)
        spiPort->CR0 |= SSP_CTRL0_SCLKPH;
    else if(tParam->u8ClkPhase == SPI_DRV_CLKPH_ONE)
        spiPort->CR0 &= ~(SSP_CTRL0_SCLKPH);

    if(tParam->u8ClkPolarity == SPI_DRV_CLKPO_HIGH)
        spiPort->CR0 |= SSP_CTRL0_SCLKPO;
    else if(tParam->u8ClkPolarity != SPI_DRV_CLKPO_LOW)
        spiPort->CR0 &= ~(SSP_CTRL0_SCLKPO);
}

void SPI_SetSPIDataMode(SPI_TypeDef *spiPort, u8 dataMode)
{
    SPI_DATA_t tSpiData;

    if(dataMode == 0)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 1)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 2)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }
    else if(dataMode == 3)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }
    
    _SPI_SetDataMode(spiPort, &tSpiData);
}

void SPI_Settings(SPI_TypeDef *spiPort, u8 div, u8 dataMode)
{
    SPI_DATA_t tSpiData;   
         
    tSpiData.u8Mode = SPI_DRV_MODE_MASTER;
    tSpiData.u8Div = div;
    
    if(dataMode == 0)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 1)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 2)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }
    else if(dataMode == 3)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }

    _SPI_SetDataMode(spiPort, &tSpiData); /* mode 0 */
    SPI_SetClockFreq(spiPort, div);
   
#if 0
    /*SPI0 PAD MUX*/
    MFP_SPI0_ENABLE();
    
    SPI_Init(spiPort,&tSpiData);
    SPI_EnableManualCS(spiPort);
    SPI_ClrCS(spiPort);
#endif
}

u32 SPI_Transfer(SPI_TypeDef *spiPort, u8 byte_lens, u32 data)
{
    u32 rx_fifo;

    SPI_SetBitLength(spiPort, (byte_lens << 3) );
    SPI_ClrRxFIFO(spiPort);
    SPI_ClrTxFIFO(spiPort);
    SPI_StartTransfer(spiPort, data);
    while(SPI_IsBusy(spiPort));
    
    rx_fifo = SPI_ReadRxFIFO(spiPort);

    return rx_fifo;
}
