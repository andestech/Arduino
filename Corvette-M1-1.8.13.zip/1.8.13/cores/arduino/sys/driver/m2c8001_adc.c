#include "Arduino.h"

void sarADC_Init(void)
{
    outw( 0x00f18000, inw(0x00f18000)|0x1 << 7); // Enable RF function register.
    outw( 0x00D0002C, inw(0x00D0002C) | (0x1 << 29)); // en_sar 24m_clk,[29] csr_en_sar_G = 1
    outw( 0x00d0004c, 0x00004000); // pd_sar power down control
    //csr_saradc_idx_0 = SARADC_CTRL_1[3:0] = 0x1
    //csr_saradc_idx_1 = SARADC_CTRL_1[7:4] = 0x2
    //csr_saradc_idx_2 = SARADC_CTRL_1[11:8] = 0x3
    //csr_saradc_idx_3 = SARADC_CTRL_1[15:12] = 0x5
    //csr_saradc_idx_4 = SARADC_CTRL_1[19:16] = 0xf
    //csr_saradc_idx_5 = SARADC_CTRL_1[23:20] = 0xf
    //csr_saradc_idx_6 = SARADC_CTRL_1[27:24] = 0xf
    //csr_saradc_idx_7 = SARADC_CTRL_1[31:28] = 0xf
    outw( 0x00d0009c, 0xffff5321); // saradc channel select (first time need)[7:4]csr_saradc_idx_1 = 5
}

void sarADC_DeInit(void)
{
    outw( 0x00D0002C, inw(0x00D0002C) &~ (0x1 << 29) ); // en_sar 24m_clk,[29] csr_en_sar_G = 0

    outw( 0x00d0004c, 0x00004200 ); // [9] csr_pd_sar_G = 1
}

void sarADC_Start(void)
{
    // SARADC_CTRL_0[11:12] = control saradc mode(0:job 1: one shot 2: freerun)
    outw(0xD00098,0x450);// start saradc
}

u32 sarADC_Read(u8 ch)
{
    u32 value  = 0;

    switch(ch)
    {
        case 0:
        case 1:
            //  idx_1 report data = SARADC_RPT_0[23:12]
            //  idx_0 report data = SARADC_RPT_0[11:0]
            value = inw(0xd00100);
            if(ch == 0)
            {
                value &= 0xFFF;
                value = value >> 2;
            }
            else
            {
                value = (value >> 12) & 0xFFF;
                value = value >> 2;
            }
            break;
        case 2:
        case 3:
            //  idx_3 report data = SARADC_RPT_1[23:12]
            //  idx_2 report data = SARADC_RPT_1[11:0]
            value = inw(0xd00104);
            if(ch == 2)
            {
                value &= 0xFFF;
                value = value >> 2;
            }
            else
            {
                value = (value >> 12) & 0xFFF;
                value = value >> 2;
            }
            break;
    }

    return value;
}
