/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "wiring.h"
#include "wiring_tone.h"

volatile uint32_t us_time = 0;
volatile uint32_t ms_time = 0;

__attribute__((weak)) void timer4_irq_handler (void)
{
}

void pit_irq_handler() {

	if (TIMER_IntStatus(TIMER1)) {
		uint32_t us_time_unit;
		uint32_t ms_time_unit;

		TIMER_ClearInt(TIMER1);

		/* Timer overflow, add time period to global timer counter */
		us_time_unit = PCLKFREQ / 1000000;
		us_time += TIMER_OVERFLOW_TICK / us_time_unit;

		ms_time_unit = PCLKFREQ / 1000;
		ms_time += TIMER_OVERFLOW_TICK / ms_time_unit;

		toneTimer1Overflow();
	}

	if (TIMER_IntStatus(TIMER2)) {
		timer2_irq_handler();
		TIMER_ClearInt(TIMER2);
	}

	if (TIMER_IntStatus(TIMER4)) {
		timer4_irq_handler();
		TIMER_ClearInt(TIMER4);
	}
}

void wiringTimerInit(void) {

	ms_time = 0;
	us_time = 0;
	TIMER_Init(TIMER1, TIMER_32, 0, TIMER_OVERFLOW_TICK);
	TIMER_EnableInt(TIMER1);
	TIMER_Start(TIMER1);

}

static uint32_t us_ticker_read(void) {

	uint32_t tm1_cntr;
	uint32_t us_time_unit;
	us_time_unit = PCLKFREQ / 1000000;
	tm1_cntr = TIMER_Read(TIMER1) / us_time_unit;

	return tm1_cntr;

}

void delay(uint32_t ms) {

	volatile uint32_t start;
	start = millis();
	while ((millis() - start) < ms);

}

uint32_t millis( void ) {

	uint32_t ms_time_tmp;
	ms_time_tmp = (uint32_t) us_ticker_read() / 1000;
	return ms_time + ms_time_tmp;

}

uint32_t micros( void ) {

	uint32_t us_time_tmp;
	us_time_tmp = (uint32_t) us_ticker_read();
	return us_time + us_time_tmp;

}

void delayMicroseconds(uint32_t usec) {

	volatile uint32_t start;
	start = micros();
	while ((micros() - start) < usec);

}
