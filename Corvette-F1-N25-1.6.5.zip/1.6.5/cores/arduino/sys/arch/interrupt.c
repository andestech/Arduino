/*
 * Copyright (c) 2012-2017 Andes Technology Corporation
 * All rights reserved.
 *
 */

#include <stdio.h>
#include "platform.h"
#include "int.h"

#define STR(S)                  #S
#define XSTR(S)                 STR(S)

#define PUSH                    XSTR(STORE)
#define POP                     XSTR(LOAD)
#define REGSIZE                 XSTR(REGBYTES)

void default_irq_handler(void)
{
}

void wdt_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void rtc_period_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void rtc_alarm_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pit_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void spi1_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void spi2_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void i2c_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void gpio_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void uart1_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void uart2_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void dma_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void bmc_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void swint_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void spi3_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void spi4_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void sdc_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void mac_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void standby_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void wakeup_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pit2_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pit3_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pit4_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pit5_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));

__attribute__((always_inline)) static inline void IRQ_ENTER(void)
{
	__asm volatile
	(
		"addi sp, sp, -32*"REGSIZE"     \n"
		PUSH " x1, 0(sp)                \n"
		"call IRQ_SAVE_CONTEXT          \n"
		"csrrsi a5,mstatus,8            \n"		// allow nested
	);
}

__attribute__((always_inline)) static inline void IRQ_EXIT(void)
{
	__asm volatile
	(
		"j IRQ_RESTORE_CONTEXT          \n"
	);
}

__attribute__ (( naked )) void entry_irq1(void)
{
	IRQ_ENTER();

	rtc_period_irq_handler();               // Call ISR

	__nds__plic_complete_interrupt(IRQ_RTCPERIOD_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq2(void)
{
	IRQ_ENTER();

	rtc_alarm_irq_handler();                // Call ISR

	__nds__plic_complete_interrupt(IRQ_RTCALARM_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq3(void)
{
	IRQ_ENTER();

	pit_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_PIT_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq4(void)
{
	IRQ_ENTER();

	spi1_irq_handler();                    // Call ISR

	__nds__plic_complete_interrupt(IRQ_SPI1_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq5(void)
{
	IRQ_ENTER();

	spi2_irq_handler();                     // Call ISR

	__nds__plic_complete_interrupt(IRQ_SPI2_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq6(void)
{
	IRQ_ENTER();

	i2c_irq_handler();                     // Call ISR

	__nds__plic_complete_interrupt(IRQ_I2C_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq7(void)
{
	IRQ_ENTER();

	gpio_irq_handler();                    // Call ISR

	__nds__plic_complete_interrupt(IRQ_GPIO_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq8(void)
{
	IRQ_ENTER();

	uart1_irq_handler();                    // Call ISR

	__nds__plic_complete_interrupt(IRQ_UART1_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq9(void)
{
	IRQ_ENTER();

	uart2_irq_handler();                    // Call ISR

	__nds__plic_complete_interrupt(IRQ_UART2_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq10(void)
{
	IRQ_ENTER();

	dma_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_DMA_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq11(void)
{
	IRQ_ENTER();

	bmc_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_BMC_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq12(void)
{
	IRQ_ENTER();

	swint_irq_handler();                    // Call ISR

	__nds__plic_complete_interrupt(IRQ_SWINT_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq15(void)
{
	IRQ_ENTER();

	spi3_irq_handler();                    // Call ISR

	__nds__plic_complete_interrupt(IRQ_SPI3_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq16(void)
{
	IRQ_ENTER();

	spi4_irq_handler();                     // Call ISR

	__nds__plic_complete_interrupt(IRQ_SPI4_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq18(void)
{
	IRQ_ENTER();

	sdc_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_SDC_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq19(void)
{
	IRQ_ENTER();

	mac_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_MAC_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq26(void)
{
	IRQ_ENTER();

	standby_irq_handler();                  // Call ISR

	__nds__plic_complete_interrupt(IRQ_STANDBY_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq27(void)
{
	__asm volatile("addi sp, sp, -32*"REGSIZE);

	/* Save caller registers */
	__asm volatile(PUSH " x1, 0*"REGSIZE"(sp)");
	__asm volatile(PUSH " x4, 1*"REGSIZE"(sp)");
	__asm volatile(PUSH " x5, 2*"REGSIZE"(sp)");
	__asm volatile(PUSH " x6, 3*"REGSIZE"(sp)");
	__asm volatile(PUSH " x7, 4*"REGSIZE"(sp)");
	__asm volatile(PUSH " x10, 5*"REGSIZE"(sp)");
	__asm volatile(PUSH " x11, 6*"REGSIZE"(sp)");
	__asm volatile(PUSH " x12, 7*"REGSIZE"(sp)");
	__asm volatile(PUSH " x13, 8*"REGSIZE"(sp)");
	__asm volatile(PUSH " x14, 9*"REGSIZE"(sp)");
	__asm volatile(PUSH " x15, 10*"REGSIZE"(sp)");
#ifndef __riscv_32e
	__asm volatile(PUSH " x16, 11*"REGSIZE"(sp)");
	__asm volatile(PUSH " x17, 12*"REGSIZE"(sp)");
	__asm volatile(PUSH " x28, 13*"REGSIZE"(sp)");
	__asm volatile(PUSH " x29, 14*"REGSIZE"(sp)");
	__asm volatile(PUSH " x30, 15*"REGSIZE"(sp)");
	__asm volatile(PUSH " x31, 16*"REGSIZE"(sp)");
#endif

	wakeup_irq_handler();                   // Call ISR

	/* Restore caller registers */
	__asm volatile(POP " x1, 0*"REGSIZE"(sp)");
	__asm volatile(POP " x4, 1*"REGSIZE"(sp)");
	__asm volatile(POP " x5, 2*"REGSIZE"(sp)");
	__asm volatile(POP " x6, 3*"REGSIZE"(sp)");
	__asm volatile(POP " x7, 4*"REGSIZE"(sp)");
	__asm volatile(POP " x10, 5*"REGSIZE"(sp)");
	__asm volatile(POP " x11, 6*"REGSIZE"(sp)");
	__asm volatile(POP " x12, 7*"REGSIZE"(sp)");
	__asm volatile(POP " x13, 8*"REGSIZE"(sp)");
	__asm volatile(POP " x14, 9*"REGSIZE"(sp)");
	__asm volatile(POP " x15, 10*"REGSIZE"(sp)");
#ifndef __riscv_32e
	__asm volatile(POP " x16, 11*"REGSIZE"(sp)");
	__asm volatile(POP " x17, 12*"REGSIZE"(sp)");
	__asm volatile(POP " x28, 13*"REGSIZE"(sp)");
	__asm volatile(POP " x29, 14*"REGSIZE"(sp)");
	__asm volatile(POP " x30, 15*"REGSIZE"(sp)");
	__asm volatile(POP " x31, 16*"REGSIZE"(sp)");
#endif

	__asm volatile("addi sp, sp, 32*"REGSIZE);
	__asm volatile("mret");
}

__attribute__ (( naked )) void entry_irq29(void)
{
	IRQ_ENTER();

	pit2_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_PIT2_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq30(void)
{
	IRQ_ENTER();

	pit3_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_PIT3_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq31(void)
{
	IRQ_ENTER();

	pit4_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_PIT4_SOURCE);

	IRQ_EXIT();
}

__attribute__ (( naked )) void entry_irq32(void)
{
	IRQ_ENTER();

	pit5_irq_handler();                      // Call ISR

	__nds__plic_complete_interrupt(IRQ_PIT5_SOURCE);

	IRQ_EXIT();
}
