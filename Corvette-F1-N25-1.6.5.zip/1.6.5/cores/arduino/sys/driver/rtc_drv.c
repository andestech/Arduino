#include "rtc_drv.h"

/* RTC driver */
RTC_Driver RTC_DRV = {DEV_RTC, 0};

/* RTC driver functions */
void rtc_startcounting(RTC_Driver* drv) {

	// wait WRITEDONE status to make sure the RTC registers have been update successfully
	while ((drv->reg->STATUS & (0x1 << 16)) == 0);

	// enable RTC
	drv->reg->CTRL |= 0x1;
}

void rtc_settime(RTC_Driver* drv, uint32_t day, uint32_t hour, uint32_t min, uint32_t sec) {

	// wait WRITEDONE status to make sure the RTC registers have been update successfully
	while ((drv->reg->STATUS & (0x1 << 16)) == 0);

	drv->reg->CNTR = ((day & 0x3f) << 17) | ((hour & 0x1f) << 12) | ((min & 0x3f) << 6) | ((sec & 0x3f) << 0);
}

void rtc_setalarmtime(RTC_Driver* drv, uint32_t hour, uint32_t min, uint32_t sec) {

	// wait WRITEDONE status to make sure the RTC registers have been update successfully
	while ((drv->reg->STATUS & (0x1 << 16)) == 0);

	drv->reg->ALARM = ((hour & 0x1f) << 12) | ((min & 0x3f) << 6) | ((sec & 0x3f) << 0);
}

uint32_t rtc_getday(RTC_Driver* drv) {
	return ((drv->reg->CNTR >> 17) & 0x3f);
}

uint32_t rtc_gethours(RTC_Driver* drv) {
	return ((drv->reg->CNTR >> 12) & 0x1f);
}

uint32_t rtc_getminutes(RTC_Driver* drv) {
	return ((drv->reg->CNTR >> 6) & 0x3f);
}

uint32_t rtc_getseconds(RTC_Driver* drv) {
	return (drv->reg->CNTR & 0x3f);
}

void rtc_attachalarmint(RTC_Driver* drv) {

	__nds__plic_enable_interrupt(IRQ_RTCALARM_SOURCE);

	// wait WRITEDONE status to make sure the RTC registers have been update successfully
	while ((drv->reg->STATUS & (0x1 << 16)) == 0);

	drv->reg->CTRL |= (0x1 << 2);
}

void rtc_detachalarmint(RTC_Driver* drv) {

	__nds__plic_disable_interrupt(IRQ_RTCALARM_SOURCE);

	// wait WRITEDONE status to make sure the RTC registers have been update successfully
	while ((drv->reg->STATUS & (0x1 << 16)) == 0);

	drv->reg->CTRL &= ~(0x1 << 2);
}

void rtc_clearalarmst(RTC_Driver* drv) {

	// wait WRITEDONE status to make sure the RTC registers have been update successfully
	while ((drv->reg->STATUS & (0x1 << 16)) == 0);

	// clear alarm interrupt
	drv->reg->STATUS |= 0x1;
}
