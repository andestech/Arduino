/***********************************************************************************************
*	INCLUDES
************************************************************************************************/
#include "uart.h"
#include "int.h"
#include "ae250.h"

/***********************************************************************************************
*	MARCOS
************************************************************************************************/
#define GET_BAUDRATE_DIVISOR(baudrate)			(int)(((float)UCLKFREQ / (float)baudrate / 16)+0.5)
#define CHECK_UART_PORT(port)				((port == DEV_UART1) || (port == DEV_UART2))
#define CHECK_UART_PARITY(parity)			((parity==UART_DRV_PARITY_NONE) || (parity==UART_DRV_PARITY_ODD) || (parity==UART_DRV_PARITY_EVEN) || (parity==UART_DRV_PARITY_ONE) || (parity==UART_DRV_PARITY_ZERO))
#define CHECK_UART_DATABIT(databit)			((databit==UART_DRV_DATABITS_5) || (databit==UART_DRV_DATABITS_6) || (databit==UART_DRV_DATABITS_7) || (databit==UART_DRV_DATABITS_8))
#define CHECK_UART_RCVOPBIT(stopbit)			((stopbit==UART_DRV_STOPBITS_1) || (stopbit==UART_DRV_STOPBITS_1_5))

/***********************************************************************************************
*	GLOBAL VARIABLES
************************************************************************************************/
#define UART_MAX_BUF_SIZ    64

typedef struct _UART_RCV_SEND_QUEUE{
	UART_RegDef *gUartConsole;
	char uartRcvBuf[UART_MAX_BUF_SIZ];
	char uartSendBuf[UART_MAX_BUF_SIZ];
	volatile unsigned int uartRcvHead;
	volatile unsigned int uartRcvTail;
	volatile unsigned int uartSendHead;
	volatile unsigned int uartSendTail;
}UART_RCV_SEND_QUEUE;

static UART_RCV_SEND_QUEUE *pUartCh0, uartCh0={DEV_UART1,{0},{0},0,0};
static UART_RCV_SEND_QUEUE *pUartCh1, uartCh1={DEV_UART2,{0},{0},0,0};

/***********************************************************************************************
*	LOCAL FUNCTIONS
************************************************************************************************/

void uart1_irq_handler() {
#ifdef ARDUINO_PRE_1_0
	u32 u32Intsts;

	u32Intsts =	 DEV_UART1->LSR;

	if(u32Intsts & UART_LSR_DATA_READY)
	{
		unsigned int isFull = ((pUartCh0->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh0->uartRcvHead ? 1 : 0;

		if(!isFull) {
			pUartCh0->uartRcvBuf[pUartCh0->uartRcvTail++] = DEV_UART1->RBR;
			if(pUartCh0->uartRcvTail == UART_MAX_BUF_SIZ)
				pUartCh0->uartRcvTail = 0;
		}
	}
#else
	switch(DEV_UART1->IIR & 0xf) {

		case 4: {//Received data available interrupt handler

			unsigned int isFull = ((pUartCh0->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh0->uartRcvHead ? 1 : 0;

			if(!isFull) {

				pUartCh0->uartRcvBuf[pUartCh0->uartRcvTail++] = DEV_UART1->RBR;

				if(pUartCh0->uartRcvTail == UART_MAX_BUF_SIZ)
					pUartCh0->uartRcvTail = 0;

			}
			break;
		}

		case 2: {//Transmitter holding register empty interrupt handler
			DEV_UART1->IER &= ~UART_IER_THRE;

			if(pUartCh0->uartSendTail != pUartCh0->uartSendHead) {

				DEV_UART1->THR = pUartCh0->uartSendBuf[pUartCh0->uartSendHead++];

				if(pUartCh0->uartSendHead == UART_MAX_BUF_SIZ)
					pUartCh0->uartSendHead = 0;

			}

			if(pUartCh0->uartSendTail != pUartCh0->uartSendHead)
				DEV_UART1->IER |= UART_IER_THRE;

			break;
		}
	}
#endif

}

void uart2_irq_handler() {
#ifdef ARDUINO_PRE_1_0
	u32 u32Intsts;

	u32Intsts =	 DEV_UART2->LSR;

	if(u32Intsts & UART_LSR_DATA_READY)
	{
		unsigned int isFull = ((pUartCh1->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh1->uartRcvHead ? 1 : 0;

		if(!isFull) {
			// Read data to the queue
			pUartCh1->uartRcvBuf[pUartCh1->uartRcvTail++] = DEV_UART2->RBR;

			if(pUartCh1->uartRcvTail == UART_MAX_BUF_SIZ)
				pUartCh1->uartRcvTail = 0;
		}
	}
#else
	switch(DEV_UART2->IIR & 0xf) {

		case 4: {//Received data available interrupt handler

			unsigned int isFull = ((pUartCh1->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh1->uartRcvHead ? 1 : 0;

			if(!isFull) {

				pUartCh1->uartRcvBuf[pUartCh1->uartRcvTail++] = DEV_UART2->RBR;

				if(pUartCh1->uartRcvTail == UART_MAX_BUF_SIZ)
					pUartCh1->uartRcvTail = 0;

			}
			break;
		}

		case 2: {//Transmitter holding register empty interrupt handler
			DEV_UART2->IER &= ~UART_IER_THRE;

			if(pUartCh1->uartSendTail != pUartCh1->uartSendHead) {

				DEV_UART2->THR = pUartCh1->uartSendBuf[pUartCh1->uartSendHead++];

				if(pUartCh1->uartSendHead == UART_MAX_BUF_SIZ)
					pUartCh1->uartSendHead = 0;

			}

			if(pUartCh1->uartSendTail != pUartCh1->uartSendHead)
				DEV_UART2->IER |= UART_IER_THRE;

			break;
		}

	}



#endif
}

void uart_dequeue_send_buf(UART_RegDef *tUart) {

	UART_RCV_SEND_QUEUE *tUartCh;

	if(tUart == DEV_UART1)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	tUart->THR = tUartCh->uartSendBuf[tUartCh->uartSendHead++];

	if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
		tUartCh->uartSendHead = 0;

	return;
}

/***********************************************************************************************
*	GLOBAL FUNCTIONS
************************************************************************************************/

void UART_IsrInit(UART_RegDef *tUart) {

	if(tUart == DEV_UART1){
		pUartCh0=&uartCh0;

		/* Priority must be set > 0 to trigger the interrupt */
		__nds__plic_set_priority(IRQ_UART1_SOURCE, 1);

		/* Enable UART1 interrupt */
		__nds__plic_enable_interrupt(IRQ_UART1_SOURCE);
	}
	else if(tUart == DEV_UART2){
		pUartCh1=&uartCh1;

		/* Priority must be set > 0 to trigger the interrupt */
		__nds__plic_set_priority(IRQ_UART2_SOURCE, 1);

		/* Enable UART1 interrupt */
		__nds__plic_enable_interrupt(IRQ_UART2_SOURCE);
	}
}


/**********************************************************************************************
@brief:Initialize specified UART port
@para:
		-tUart: Specified UART port UART0/UART1
		-tParam.u32BaudRate : Baud rate(Hz)
			UART_DRV_BAUDRATE_38400
			UART_DRV_BAUDRATE_57600
			UART_DRV_BAUDRATE_115200
			UART_DRV_BAUDRATE_230400
			UART_DRV_BAUDRATE_460800
		  tParam.u8DataBits : Data bit setting
			UART_DRV_DATABITS_5
			UART_DRV_DATABITS_6
			UART_DRV_DATABITS_7
			UART_DRV_DATABITS_8
		  tParam.u8StopBits : Stop bit setting
			UART_DRV_STOPBITS_1
			UART_DRV_STOPBITS_1_5
		  tParam.u8Parity : Parity setting
			UART_DRV_PARITY_NONE
			UART_DRV_PARITY_ODD
			UART_DRV_PARITY_EVEN
			UART_DRV_PARITY_ONE
			UART_DRV_PARITY_ZERO
***********************************************************************************************/
void UART_Init(UART_RegDef *tUart,UART_DATA_t * tParam) {

	u32 div = 0;

	if( !(CHECK_UART_PORT(tUart) && CHECK_UART_PARITY(tParam->u8Parity) &&	\
		CHECK_UART_DATABIT(tParam->u8DataBits) && CHECK_UART_RCVOPBIT(tParam->u8StopBits)) )
			return;

	/* Set DLAB to 1 */
	tUart->LCR |= UART_LCR_DLAB;

	/*Get current UART clock source frequency */
	div = GET_BAUDRATE_DIVISOR(tParam->u32BaudRate);

	/* Set DLL and DLM */
	tUart->DLL = (div >> 0) & 0xff ;
	tUart->DLM = (div >> 8) & 0xff ;

	/* LCR: Set (1)Length 8, parity, stop bit. (2)DLAB = 0 */
	tUart->LCR = tParam->u8DataBits | (tParam->u8StopBits << 2) |(tParam->u8Parity << 3);

	/* FCR: Disable FIFO, reset TX and RX. */
	tUart->FCR = UART_FCR_RX_FIFO_RESET | UART_FCR_TX_FIFO_RESET;

	/* IER: Enable received data available interrupt */
	tUart->IER = UART_IER_RDA;
}

/***********************************************************************************************
@brief:Disable UART clock
@para:
		-tUart: Specified UART port UART0/UART1
***********************************************************************************************/
void UART_DeInit(UART_RegDef *tUart) {

	//Switch pins to digital IO if there is pinmux on platform
	//Add swtiching action here

	//Disable the UART interrupt
	tUart->IER = 0;

	if(tUart == DEV_UART1){
		__nds__plic_disable_interrupt(IRQ_UART1_SOURCE);
	}
	else if(tUart == DEV_UART2){
		__nds__plic_disable_interrupt(IRQ_UART2_SOURCE);
	}
}

/***********************************************************************************************
@brief:Write one byte data to Tx FIFO and transmit data by specified UART
@para:
		-tUart: Specified UART port UART0/UART1
		-u8Data: wirte data
***********************************************************************************************/
void UART_WriteByte(UART_RegDef *tUart,u8 u8Data) {
#if ARDUINO_PRE_1_0
	while(!(tUart->LSR & UART_LSR_THR_EMPTY));
	tUart->THR = u8Data;
#else
	UART_RCV_SEND_QUEUE *tUartCh;

        if(tUart == DEV_UART1)
                tUartCh=pUartCh0;
        else
                tUartCh=pUartCh1;

	// Disable the THRE interrupt to avoid race condition
	tUart->IER &= ~UART_IER_THRE;

	// If THR is empty, we write data to THR directly.
	if((tUartCh->uartSendTail == tUartCh->uartSendHead) && (tUart->LSR & UART_LSR_THR_EMPTY)) {
		tUart->THR = u8Data;
		return;
	}

	// If the transmission buffer is full, we have to consume an old data befor enqueue the new data
	while( ((tUartCh->uartSendTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartSendHead) {
		if(tUart->LSR & UART_LSR_THR_EMPTY)
			uart_dequeue_send_buf(tUart);
	}

	// Enqueue the new data
	tUartCh->uartSendBuf[tUartCh->uartSendTail++] = u8Data;

	if(tUartCh->uartSendTail == UART_MAX_BUF_SIZ)
		tUartCh->uartSendTail = 0;

	tUart->IER |= UART_IER_THRE;
	return;
#endif
}

/***********************************************************************************************
@brief:	Check if any data in received queue
@para:
		-tUart: Specified UART port UART1/UART2
@ret:
		-The number of bytes in the queue
***********************************************************************************************/
int UART_IsDataAvailable(UART_RegDef *tUart) {

	UART_RCV_SEND_QUEUE *tUartCh;

	if(tUart == DEV_UART1)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	return (tUartCh->uartRcvTail < tUartCh->uartRcvHead) ? ((tUartCh->uartRcvTail-tUartCh->uartRcvHead) + UART_MAX_BUF_SIZ)	\
		:(tUartCh->uartRcvTail - tUartCh->uartRcvHead) ;
}

/***********************************************************************************************
@brief: Check how many bytes in queue are available for write
@para:
                -tUart: Specified UART port UART1/UART2
@ret:
                -The number of bytes avaliable for write(Only 1 byte buffer if the port is not busy)
***********************************************************************************************/
int UART_BytesAvailableForWrite(UART_RegDef *tUart) {

	//return (tUart->LSR & UART_LSR_THR_EMPTY)?1:0;
	UART_RCV_SEND_QUEUE *tUartCh;
	unsigned int len;

	if(tUart == DEV_UART1)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	// Disable the THRE interrupt to avoid race condition
        tUart->IER &= ~UART_IER_THRE;

	len = (tUartCh->uartSendTail >= tUartCh->uartSendHead)?(tUartCh->uartSendTail-tUartCh->uartSendHead)	\
		:(tUartCh->uartSendTail-tUartCh->uartSendHead)+UART_MAX_BUF_SIZ;

	tUart->IER |= UART_IER_THRE;

	return len;
}




/***********************************************************************************************
@brief:	Read the first data in received queue.
@para:
	-tUart: Specified UART port UART1/UART2
@Ret:
	-The first character in received queue
***********************************************************************************************/
u8 UART_ReadByte(UART_RegDef *tUart) {

	volatile char ch = ' ';
	UART_RCV_SEND_QUEUE *tUartCh;

	if(tUart == DEV_UART1)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	ch=tUartCh->uartRcvBuf[tUartCh->uartRcvHead];

	if(++tUartCh->uartRcvHead == UART_MAX_BUF_SIZ)
		tUartCh->uartRcvHead = 0;

	return ch;
}

/***********************************************************************************************
@brief:	Peek the first data in received queue.
@para:
	-tUart: Specified UART port UART1/UART2
@Ret:
	-The first character in received queue
***********************************************************************************************/
u8 UART_PeekByte(UART_RegDef *tUart) {

	UART_RCV_SEND_QUEUE *tUartCh;

	if(tUart == DEV_UART1)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	return tUartCh->uartRcvBuf[tUartCh->uartRcvHead];
}

/***********************************************************************************************
@brief:	Read all data in received queue.
@para:
	-tUart: Specified UART port UART1/UART2
***********************************************************************************************/
void UART_Flush(UART_RegDef *tUart) {
#if ARDUINO_PRE_1_0

	UART_RCV_SEND_QUEUE *tUartCh;

	if(tUart == DEV_UART1)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	tUart->IER = 0x0;

	while(1)
	{
		if(UART_IsDataAvailable(tUart))
		{
			UART_ReadByte(tUart);
		}
		else
			break;
	}

	tUart->FCR = UART_FCR_FIFO_ENABLE |UART_FCR_RX_FIFO_RESET | UART_FCR_TX_FIFO_RESET;
	tUartCh->uartRcvHead = 0;
	tUartCh->uartRcvTail = 0;
	tUart->IER = 0x1;
#else

	UART_RCV_SEND_QUEUE *tUartCh;

        if(tUart == DEV_UART1)
                tUartCh=pUartCh0;
        else
                tUartCh=pUartCh1;

        tUart->IER &= ~UART_IER_THRE;

	u32 len = (tUartCh->uartSendTail >= tUartCh->uartSendHead)?(tUartCh->uartSendTail-tUartCh->uartSendHead)	\
		:(tUartCh->uartSendTail-tUartCh->uartSendHead)+UART_MAX_BUF_SIZ;

	while(len--) {
		while(!(tUart->LSR & UART_LSR_THR_EMPTY));
		tUart->THR = tUartCh->uartSendBuf[tUartCh->uartSendHead++];

		if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
			tUartCh->uartSendHead = 0;
	}

#endif
}

int outbyte(int c) {

	while(!(DEV_UART2->LSR & UART_LSR_THR_EMPTY));
		DEV_UART2->THR = c;
        if (c =='\n') {
		while(!(DEV_UART2->LSR & UART_LSR_THR_EMPTY));
        		DEV_UART2->THR = '\r';
	}

        return c;
}

#ifdef TESTING

void insertStrToRcvQueue(char* buffer, unsigned int len) {

	for(int i=0; i<len; i++) {
		pUartCh1->uartRcvBuf[pUartCh1->uartRcvTail++] = *buffer++;

		if(pUartCh1->uartRcvTail == UART_MAX_BUF_SIZ)
			pUartCh1->uartRcvTail = 0;
	}

}

void insertStrToSendQueue(char* buffer, unsigned int len) {

	pUartCh1->gUartConsole->IER &= ~UART_IER_THRE;

        for(int i=0; i<len; i++) {
                pUartCh1->uartSendBuf[pUartCh1->uartSendTail++] = *buffer++;

                if(pUartCh1->uartSendTail == UART_MAX_BUF_SIZ)
                        pUartCh1->uartSendTail = 0;
        }

	pUartCh1->gUartConsole->IER |= UART_IER_THRE;

}


#endif
