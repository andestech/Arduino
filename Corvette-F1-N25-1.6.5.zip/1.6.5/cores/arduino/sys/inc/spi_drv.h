#ifndef F1_AE250_SPI_H_
#define F1_AE250_SPI_H_

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

#include <stdbool.h>

#include "platform.h"
#include "ae250.h"
#include "typedef.h"

#define SPI_CLK 66000000
#define SPI_CLK_DIVIDER_MAX 510

#define SPI_DRV_CPOL0_CPHA0 0
#define SPI_DRV_CPOL0_CPHA1 1
#define SPI_DRV_CPOL1_CPHA0 2
#define SPI_DRV_CPOL1_CPHA1 3

typedef struct {
	uint8_t* tx_buf;
	uint8_t* rx_buf;
	uint8_t* tx_buf_limit;
	uint8_t txfifo_refill;
} SPI_TransData;

typedef struct {
	SPI_RegDef* reg;
	uint8_t ip_num;

	SPI_TransData xfer;
	uint8_t txfifo_size;
	bool transfer_busy;
} SPI_Driver;

extern SPI_Driver SPI_DRV1;
extern SPI_Driver SPI_DRV2;
extern SPI_Driver SPI_DRV3;
extern SPI_Driver SPI_DRV4;

void SPI_Init(SPI_Driver* drv);
void SPI_DeInit(SPI_Driver* drv);

void SPI_SetBitOrder(SPI_Driver* drv, bool msb_first);
void SPI_SetClockDivider(SPI_Driver* drv, uint32_t divider_ratio);
void SPI_SetDataMode(SPI_Driver* drv, uint8_t data_mode);

uint8_t SPI_TransferByte(SPI_Driver* drv, uint8_t data);
uint16_t SPI_Transfer2Bytes(SPI_Driver* drv, uint16_t data);
void SPI_Transfer(SPI_Driver* drv, uint8_t* data, uint32_t num);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif
