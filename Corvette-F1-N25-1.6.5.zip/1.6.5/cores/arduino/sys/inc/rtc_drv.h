#ifndef F1_AE250_RTC_H_
#define F1_AE250_RTC_H_

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "platform.h"
#include "ae250.h"
#include "typedef.h"

typedef struct {
	RTC_RegDef* reg;
	uint8_t ip_num;
} RTC_Driver;

extern RTC_Driver RTC_DRV;

void rtc_startcounting(RTC_Driver*);
void rtc_settime(RTC_Driver*, uint32_t, uint32_t, uint32_t, uint32_t);
void rtc_setalarmtime(RTC_Driver*, uint32_t, uint32_t, uint32_t);
uint32_t rtc_getday(RTC_Driver*);
uint32_t rtc_gethours(RTC_Driver*);
uint32_t rtc_getminutes(RTC_Driver*);
uint32_t rtc_getseconds(RTC_Driver*);
void rtc_attachalarmint(RTC_Driver*);
void rtc_detachalarmint(RTC_Driver*);
void rtc_clearalarmst(RTC_Driver*);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif
