#ifndef F1_AE250_GPIO_H
#define F1_AE250_GPIO_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "ae250.h"
#include "typedef.h"

/*    Interrupt mode	*/
#define GPIO_INTRMODE_NEGATIVE_EDGE     0x5
#define GPIO_INTRMODE_POSITIVE_EDGE     0x6
#define GPIO_INTRMODE_DUAL_EDGE         0x7

#define GPIO_NUM	32

/***********************************************************************************************
*   TYPEDEFS
************************************************************************************************/
typedef void (DRVGPIO_Callback)(u32);


typedef enum{
	GPIO_LOW,
	GPIO_HIGH
}GPIO_STATE;

typedef enum{
	GPIO_INPUT,
	GPIO_OUTPUT,
	GPIO_INPUT_PULLUP
}GPIO_TYPE;

typedef enum{
	GPIO_PULL_DOWN,
	GPIO_PULL_UP,
}GPIO_PULL_TYPE;

typedef enum{
	GPIO_TRIG_LEVEL,
	GPIO_TRIG_EDGE,
}GPIO_TRIGGER_TYPE;

typedef enum{
	GPIO_RISING_HIGH,
	GPIO_FALLING_LOW,
}GPIO_TRIGGERED_EDGE_TYPE;


void GPIO_SetDir(u8 u8Idx, GPIO_TYPE Dir);
void GPIO_SetInputType(u8 u8Idx, GPIO_PULL_TYPE type);
void GPIO_SetOutput(u8 u8Idx, GPIO_STATE Val);
u8 GPIO_GetBit(u8 u8Idx);

void GPIO_IsrInit(void);
void GPIO_EnableInt(u8 u8Idx,u8 u8Mode);
void GPIO_DisableInt(u8 u8Idx);
void GPIO_RegisterCallback(DRVGPIO_Callback *cb);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* F1_AE100_GPIO_H */
