#ifndef WIRING_SHIFT_H
#define WIRING_SHIFT_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "typedef.h"

typedef enum{
	LSBFIRST = 0,
	MSBFIRST
}BIT_ORDER;


uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder);
void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_SHIFT_H
