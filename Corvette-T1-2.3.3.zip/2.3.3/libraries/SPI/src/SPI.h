#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED

#include "Arduino.h"
#include "arduino_pin.h"
extern "C" {
#include "telink_spi.h"
}


#ifndef LSBFIRST
#define LSBFIRST            0
#endif
#ifndef MSBFIRST
#define MSBFIRST            1
#endif

#define SPI_CLOCK_DIV2      2
#define SPI_CLOCK_DIV4      4
#define SPI_CLOCK_DIV8      8
#define SPI_CLOCK_DIV16     16
#define SPI_CLOCK_DIV32     32
#define SPI_CLOCK_DIV64     64
#define SPI_CLOCK_DIV128    128

#define SPI_CLK             HCLKFREQ
#define HSPI_MODULE         1
#define CSN_PIN1            HSPI_CSN_PA1

class SPIClass;

class SPISettings {
private:
	const static uint8_t DEFAULT_DATA_MODE = SPI_MODE0;

	uint32_t spi_clock = SPI_CLK;
	uint8_t data_mode = DEFAULT_DATA_MODE;
	friend class SPIClass;

public:
	SPISettings(uint32_t clock = SPI_CLK, uint8_t bitOrder = MSBFIRST, uint8_t dataMode = DEFAULT_DATA_MODE) {
		/*
		 * SPI clock rate: If SPI_CLK == 66MHz, the accepted clock rate is between 132KHz to 66MHz
		 */
		this->spi_clock = clock;
		this->data_mode = dataMode;
	}
};

class SPIClass {
public:
	SPIClass() : interrupt_mode(0), interrupt_mask(0), interrupt_save(0) {}

	// Initialize the SPI library
	void begin();
	// Disable the SPI bus
	void end();

	// If SPI is used from within an interrupt, this function registers
	// that interrupt with the SPI library, so beginTransaction() can
	// prevent conflicts.  The input interruptNumber is the number used
	// with attachInterrupt.  If SPI is used from a different interrupt
	// (eg, a timer), interruptNumber should be 255.
	void usingInterrupt(uint8_t interruptNumber);
	// And this does the opposite.
	void notUsingInterrupt(uint8_t interruptNumber);
	// Note: the usingInterrupt and notUsingInterrupt functions should
	// not to be called from ISR context or inside a transaction.
	// For details see:
	// https://github.com/arduino/Arduino/pull/2381
	// https://github.com/arduino/Arduino/pull/2449

	// Before using SPI.transfer() or asserting chip select pins,
	// this function is used to gain exclusive access to the SPI bus
	// and configure the correct settings.
	void beginTransaction(SPISettings settings);
	// After performing a group of transfers and releasing the chip select
	// signal, this function allows others to access the SPI bus
	void endTransaction(void);
	// Write to the SPI bus (MOSI pin) and also receive (MISO pin)
	uint8_t transfer(uint8_t data);
	uint16_t transfer16(uint16_t data);
	void transfer(void *buf, size_t count);
	/* These functions (set*()) are deprecated.
	 * New applications should use beginTransaction() to configure SPI settings.
	 */
	void setBitOrder(uint8_t bitOrder);
	void setDataMode(uint8_t dataMode);
	void setClockDivider(uint8_t clockDiv);

private:
	uint8_t interrupt_mode; // 0=none, 1=mask, 2=global
	uint32_t interrupt_mask; // which interrupts to mask
	uint32_t interrupt_save; // temp storage, to restore state
};

extern SPIClass SPI;

#endif
