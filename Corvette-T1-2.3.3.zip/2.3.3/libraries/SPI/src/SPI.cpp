#include "SPI.h"

#define DISABLE_IRQSAVE()               read_csr(NDS_MSTATUS) & MSTATUS_MIE; 	clear_csr(NDS_MSTATUS, MSTATUS_MIE);
#define ENABLE_IRQRESTORE(flag)         do { if ((flag)) { set_csr(NDS_MSTATUS, MSTATUS_MIE); } } while(0);

#define GPIO_MASK_D2                    (1 << D2)
#define GPIO_MASK_D3                    (1 << D3)
#define GPIO_MASK_D4                    (1 << D4)

SPIClass SPI;

hspi_pin_config_t hspi_pin_config = {
	.hspi_clk_pin		= HSPI_CLK_PA2,
	.hspi_csn_pin 		= HSPI_CSN_PA1,
	.hspi_mosi_io0_pin  = HSPI_MOSI_IO0_PA4,
	.hspi_miso_io1_pin  = HSPI_MISO_IO1_PA3,//3line mode set none
	.hspi_wp_io2_pin    = HSPI_WP_IO2_PB1,//set quad mode otherwise set none
	.hspi_hold_io3_pin  = HSPI_HOLD_IO3_PB0,//set quad mode otherwise set none
};

static bool pinMuxCheckAndSet(uint8_t pin, PinFunction pin_function)
{
	int pin_usage = pinMuxCheckUsage(pin);

	if (pin_usage == PINMUX_FUNC_UNUSED) {
		int err = pinMuxSet(pin, pin_function);
		if (err)
			return false;
	}
	else if (pin_usage != pin_function) {
		// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
		return false;
	}

	return true;
}

static bool spiSetPinMux(uint8_t ip_num)
{
	SpiPins spi_pins = spiIpToPins(ip_num);

	if (pinSupportPinMux(spi_pins.sclk)) {
		if (!pinMuxCheckAndSet(spi_pins.sclk, PINMUX_FUNC_SPI)) {
			return false;
		}
	}
	if (pinSupportPinMux(spi_pins.mosi)) {
		if (!pinMuxCheckAndSet(spi_pins.mosi, PINMUX_FUNC_SPI)) {
			return false;
		}
	}
	if (pinSupportPinMux(spi_pins.miso)) {
		if (!pinMuxCheckAndSet(spi_pins.miso, PINMUX_FUNC_SPI)) {
			return false;
		}
	}

	return true;
}

void SPIClass::begin()
{
	// Set Pinmux
	bool pinsupport = spiSetPinMux(1);

	if (pinsupport) {
		spi_manager_init(static_cast<spi_sel_e>(HSPI_MODULE), (HCLKFREQ / (2 * (SPI_CLK)) - 1), static_cast<spi_mode_type_e>(SPISettings::DEFAULT_DATA_MODE));
		hspi_set_pin(&hspi_pin_config);
		spi_manager_config(static_cast<spi_sel_e>(HSPI_MODULE), SPI_NOMAL);
	}
	hspi_cs_pin_dis(CSN_PIN1);
}

void SPIClass::end()
{
	hspi_reset();

	SpiPins spi_pins = spiIpToPins(1);
	// Reset the software flag for the next pin application
	if (pinMuxCheckUsage(spi_pins.sclk) == PINMUX_FUNC_UNUSED)
		pinMuxReset(spi_pins.sclk, PINMUX_FUNC_SPI);
	if (pinMuxCheckUsage(spi_pins.mosi) == PINMUX_FUNC_UNUSED)
		pinMuxReset(spi_pins.mosi, PINMUX_FUNC_SPI);
	if (pinMuxCheckUsage(spi_pins.miso) == PINMUX_FUNC_UNUSED)
		pinMuxReset(spi_pins.miso, PINMUX_FUNC_SPI);
}

void SPIClass::usingInterrupt(uint8_t interruptNumber)
{
	unsigned long flag = DISABLE_IRQSAVE();

	// Retrict D2~D4 pin support GPIO interrupt,
	// D2->gpio_irq_handler, D3->gpio_risc0_irq_handler, D4->gpio_risc1_irq_handler
	if ((interruptNumber >= D2) && (interruptNumber <= D4)) {
		interrupt_mask |= (1 << interruptNumber);
	} else {
		interrupt_mode = 2;
	}

	if (!interrupt_mode)
		interrupt_mode = 1;

	ENABLE_IRQRESTORE(flag);
}

void SPIClass::notUsingInterrupt(uint8_t interruptNumber)
{
	// Once in mode 2 we can't go back to 0 without a proper reference count
	if (interrupt_mode == 2)
		return;

	unsigned long flag = DISABLE_IRQSAVE();

	// Retrict D2~D4 pin support GPIO interrupt,
	// D2->gpio_irq_handler, D3->gpio_risc0_irq_handler, D4->gpio_risc1_irq_handler
	if ((interruptNumber >= D2) && (interruptNumber <= D4)) {
		interrupt_mask &= ~(1 << interruptNumber);
	}

	if (!interrupt_mask) {
		interrupt_mode = 0;
	}

	ENABLE_IRQRESTORE(flag);
}

void SPIClass::beginTransaction(SPISettings settings) {
	if (interrupt_mode > 0) {
		unsigned long flag = DISABLE_IRQSAVE();

		if (interrupt_mode == 1) {
			if (interrupt_mask & GPIO_MASK_D2) gpio_irq_dis(arduinoPinToGpioPin(D2));
			if (interrupt_mask & GPIO_MASK_D3) gpio_irq_dis(arduinoPinToGpioPin(D3));
			if (interrupt_mask & GPIO_MASK_D4) gpio_irq_dis(arduinoPinToGpioPin(D4));
			ENABLE_IRQRESTORE(flag);
		} else {
			interrupt_save = flag;
		}
	}

	// Set pinmux success
	spi_manager_init(static_cast<spi_sel_e>(HSPI_MODULE), (HCLKFREQ/(2 * (settings.spi_clock)) - 1), static_cast<spi_mode_type_e>(settings.data_mode));
	hspi_set_pin(&hspi_pin_config);
	spi_manager_config(static_cast<spi_sel_e>(HSPI_MODULE), SPI_NOMAL);
	hspi_cs_pin_dis(CSN_PIN1);
}

// After performing a group of transfers and releasing the chip select
// signal, this function allows others to access the SPI bus
void SPIClass::endTransaction(void) {
	hspi_reset();

	SpiPins spi_pins = spiIpToPins(1);
	// Reset the software flag for the next pin application
	if (pinMuxCheckUsage(spi_pins.sclk) == PINMUX_FUNC_UNUSED)
		pinMuxReset(spi_pins.sclk, PINMUX_FUNC_SPI);
	if (pinMuxCheckUsage(spi_pins.mosi) == PINMUX_FUNC_UNUSED)
		pinMuxReset(spi_pins.mosi, PINMUX_FUNC_SPI);
	if (pinMuxCheckUsage(spi_pins.miso) == PINMUX_FUNC_UNUSED)
		pinMuxReset(spi_pins.miso, PINMUX_FUNC_SPI);

	if (interrupt_mode > 0) {
		unsigned long flag = DISABLE_IRQSAVE();

		if (interrupt_mode == 1) {
			if (interrupt_mask & GPIO_MASK_D2) gpio_irq_en(arduinoPinToGpioPin(D2));
			if (interrupt_mask & GPIO_MASK_D3) gpio_irq_en(arduinoPinToGpioPin(D3));
			if (interrupt_mask & GPIO_MASK_D4) gpio_irq_en(arduinoPinToGpioPin(D4));
			ENABLE_IRQRESTORE(flag);
		} else {
			ENABLE_IRQRESTORE(interrupt_save);
		}
	}
}

// Write to the SPI bus (MOSI pin) and also receive (MISO pin)
uint8_t SPIClass::transfer(uint8_t data) {
	uint8_t rx_data = 0;
	spi_manager_transfer(static_cast<spi_sel_e>(HSPI_MODULE), &data, &rx_data, 1);
	return rx_data;
}

uint16_t SPIClass::transfer16(uint16_t data) {
	uint8_t rx_data[2];
	spi_manager_transfer(static_cast<spi_sel_e>(HSPI_MODULE), (unsigned char*)&data, (unsigned char*)rx_data, 2);
	data = (((uint16_t)rx_data[0] << 8) | rx_data[1]);
	return data;
}

void SPIClass::transfer(void *buf, size_t count) {
	spi_manager_transfer(static_cast<spi_sel_e>(HSPI_MODULE), (unsigned char*)buf, (unsigned char*)buf, count);
}

/* These functions (set*()) are deprecated.
 * New applications should use beginTransaction() to configure SPI settings.
 */
void SPIClass::setBitOrder(uint8_t bitOrder) {
	// Corvette-T1 not support setting bit order
	;
}

void SPIClass::setDataMode(uint8_t dataMode) {
	reg_spi_mode0(static_cast<spi_sel_e>(HSPI_MODULE))	&= (~FLD_SPI_MODE_WORK_MODE); // clear spi working mode
	reg_spi_mode0(static_cast<spi_sel_e>(HSPI_MODULE)) |= (dataMode << 5);// select SPI mode, support four modes
}

void SPIClass::setClockDivider(uint8_t clockDiv) {
	reg_spi_mode1(static_cast<spi_sel_e>(HSPI_MODULE)) = (HCLKFREQ / (2 * (SPI_CLK/clockDiv)) - 1);
}
