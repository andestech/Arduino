/*
  Copyright (c) 2011-2012 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef WINTERRUPT_H
#define WINTERRUPT_H

#include "Arduino.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "gpio.h"

#define GPIO_ISR_NUM  3

struct gpio_struct
{
	uint8_t init;
	void (*interrupt_func)(void *);
	void *interrupt_param;
};

static struct gpio_struct gpio_table[GPIO_ISR_NUM];
static int signal_array[4] = {INTR_LOW_LEVEL, INTR_HIGH_LEVEL, INTR_FALLING_EDGE, INTR_RISING_EDGE};
static int gpio_irq_array[3] = {IRQ25_GPIO, IRQ26_GPIO2RISC0, IRQ27_GPIO2RISC1};

void attachInterrupt(pin_size_t pin, voidFuncPtr callback, PinStatus mode)
{
	attachInterruptParam(pin, (voidFuncPtrParam) callback, mode, NULL);
}

void attachInterruptParam(pin_size_t pin, voidFuncPtrParam callback, PinStatus mode, void* param)
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);
	uint8_t pinindex  = GpioPinToPinIndex(gpio_pin);
	uint8_t gpio_isr_index = pin - D2;

	// Retrict D2~D4 pin support GPIO interrupt,
	// D2->gpio_irq_handler, D3->gpio_risc0_irq_handler, D4->gpio_risc1_irq_handler
	if ((pin < D2) || (pin > D4)) {
		return;
	}

	// TLSR9518 not support CHANGE function
	if( mode > RISING ) {
		return;
	} else if (mode == CHANGE) {
		mode = FALLING;
	}

	// The pin has been initialize
	if (gpio_table[gpio_isr_index].init) {
		return;
	}

	if (pinSupportPinMux(pinindex)) {
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(pinindex, PINMUX_FUNC_GPIO);
			if (err)
				return;
		}
		else if (pin_usage != PINMUX_FUNC_GPIO) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}

	// Initialize the pin as input
	gpio_function_en(gpio_pin);
	gpio_output_dis(gpio_pin);
	gpio_input_en(gpio_pin);
	gpio_set_up_down_res(gpio_pin, GPIO_PIN_PULLUP_10K);

	/* Initialize and enable gpio isr signal */
	if (gpio_isr_index == 0) {
		gpio_set_irq(gpio_pin, signal_array[mode]);
		gpio_irq_en(gpio_pin);
	} else if (gpio_isr_index == 1) {
		gpio_set_gpio2risc0_irq(gpio_pin,signal_array[mode]);
		gpio_gpio2risc0_irq_en(gpio_pin);
	} else if (gpio_isr_index == 2) {
		gpio_set_gpio2risc1_irq(gpio_pin,signal_array[mode]);
		gpio_gpio2risc1_irq_en(gpio_pin);
	}

	plic_interrupt_enable(gpio_irq_array[gpio_isr_index]);

	/* Register Interrupt callback function */
	gpio_table[gpio_isr_index].interrupt_func = callback;
	gpio_table[gpio_isr_index].interrupt_param = param;

	// Indicate the pin has been initialized
	gpio_table[gpio_isr_index].init = 1;
}

void detachInterrupt(pin_size_t pin)
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);
	uint8_t gpio_isr_index = pin - D2;

	/* Disable Interrupt */
	gpio_irq_dis(gpio_pin);
	plic_interrupt_disable(gpio_irq_array[gpio_isr_index]);

	gpio_table[gpio_isr_index].interrupt_func = NULL;
	gpio_table[gpio_isr_index].interrupt_param = NULL;
	gpio_table[gpio_isr_index].init = 0;
}

void gpio_irq_handler(void)
{
	void (*int_func)(void *) = gpio_table[0].interrupt_func;
	void  *int_param         = gpio_table[0].interrupt_param;

	int_func(int_param);
	gpio_clr_irq_status(FLD_GPIO_IRQ_CLR);
}

void gpio_risc0_irq_handler(void)
{
	void (*int_func)(void *) = gpio_table[1].interrupt_func;
	void  *int_param         = gpio_table[1].interrupt_param;

	int_func(int_param);
	gpio_clr_irq_status(FLD_GPIO_IRQ_GPIO2RISC0_CLR);
}

void gpio_risc1_irq_handler(void)
{
	void (*int_func)(void *) = gpio_table[2].interrupt_func;
	void  *int_param         = gpio_table[2].interrupt_param;

	int_func(int_param);
	gpio_clr_irq_status(FLD_GPIO_IRQ_GPIO2RISC1_CLR);
}

#endif //WINTERRUPT_H
