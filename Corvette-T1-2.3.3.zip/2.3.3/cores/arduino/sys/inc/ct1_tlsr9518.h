/*
 * Copyright (c) 2012-2017 Andes Technology Corporation
 * All rights reserved.
 *
 */

#ifndef __AE250_H__
#define __AE250_H__

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
 * System clock
 ****************************************************************************/
#define KHz                     1000
#define MHz                     1000000

#define OSCFREQ                 (24 * MHz)
#define CPUFREQ                 (48 * MHz)
#define RTCFREQ                 (32768)
#define HCLKFREQ                (48 * MHz)
#define PCLKFREQ                (24 * MHz)
#define UCLKFREQ                (OSCFREQ)

#ifdef __cplusplus
}
#endif

#endif	/* __AE250_H__ */
