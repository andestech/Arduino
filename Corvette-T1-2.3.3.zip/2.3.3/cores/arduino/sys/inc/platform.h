/*
 * Copyright (c) 2012-2017 Andes Technology Corporation
 * All rights reserved.
 *
 */

#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "config.h"
#include "core_v5.h"
#include "ct1_tlsr9518.h"

#include "plic.h"

#ifdef __cplusplus
}
#endif

// Declare weak g_plic_preempt_en for telink plic.h,
// it will be overwrited if using telink plic.c
unsigned char __attribute__((weak))g_plic_preempt_en;

#endif	/* __PLATFORM_H__ */
