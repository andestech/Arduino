/*
  Arduino.h - Main include file for the Arduino SDK
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef Arduino_h
#define Arduino_h

#include "api/ArduinoAPI.h"

#ifdef __cplusplus

using namespace arduino;

extern "C" {
#endif

#include "platform.h"

#ifdef __cplusplus
}
#endif

/*	Data type conversion	*/
#define char(x)		((char) x)
#define byte(x)		((byte) x)
#define long(x)		((long) x)
#define float(x)	((float) x)

/* Interrupt */
#define interrupts() set_csr(NDS_MSTATUS, MSTATUS_MIE)
#define noInterrupts() clear_csr(NDS_MSTATUS, MSTATUS_MIE)

#define digitalPinToInterrupt(pin) (pin)

#ifdef __cplusplus

#include "Serial.h"

extern "C"{
#endif // __cplusplus

/* Reference voltage used for analog input */
typedef enum {
	DEFAULT = 0,
	EXTERNAL,
	INTERNAL,
	INTERNAL1V1,
	INTERNAL2V56
} VoltageRef;

#include "arduino_pin.h"

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif // Arduino_h
