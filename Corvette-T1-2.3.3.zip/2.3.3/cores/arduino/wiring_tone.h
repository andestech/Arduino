#ifndef WIRING_TONE_H
#define WIRING_TONE_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void toneTimerInit();
extern "C" void timer1_irq_handler(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_TONE_H
