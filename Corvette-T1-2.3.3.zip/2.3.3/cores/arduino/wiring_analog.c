#include "Arduino.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "pwm.h"
#include "adc.h"

/*
 * CF1-AE250's analogWrite() output 980Hz PWM wave instead of Arduino Uno's 490Hz,
 * because the clock rate of timer in this platform isn't suitable for 490Hz.
 * CT1 include PWM in tlsr9518 and support 480Hz PWM wave and 9600Hz sample rate for ADC
 */
#define PWM_FREQ_ANALOG_WRITE 490
#define DUTY_LENGTH           255

#define PWM_PCLK_SPEED      12000000 //pwm clock 12M.
#define PWM_MAX_PERIOD      (0xFFFF)

/* Analog Input */
// p.s. Analog Input needs HW ADC support.
int analogRead(pin_size_t pin)
{
	unsigned int value = 0;
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);
	uint8_t pinindex = GpioPinToPinIndex(gpio_pin);

	// 1. Config PinMux to ADC function.
	if (pinSupportPinMux(pinindex)) {
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(pinindex, PINMUX_FUNC_ADC);
			if (err) {
				return 0;
			}
		}
		else if (pin_usage != PINMUX_FUNC_ADC) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return 0;
		}
	}

	// This pin is used by ADC in PinMux, or this pin doesn't support PinMux.
	GpioPin GpioPin_array[6] = {GPIO_PB0, GPIO_PB1, GPIO_PB2, GPIO_PB3, GPIO_PB4, GPIO_PB5};
	adc_input_pin_def_e adc_input_array[6] = {ADC_GPIO_PB0, ADC_GPIO_PB1, ADC_GPIO_PB2, ADC_GPIO_PB3, ADC_GPIO_PB4, ADC_GPIO_PB5};
	adc_input_pin_def_e adc_input = adc_input_array[0];

	// Decide which ADC pin to be config
	for (int i=0; i<6; i++) {
		if (GpioPin_array[i] == gpio_pin) {
			adc_input = adc_input_array[i];
		}
	}

	adc_gpio_sample_init(adc_input, ADC_VREF_1P2V, ADC_PRESCALE_1F4, ADC_SAMPLE_FREQ_96K);
	adc_power_on();
	// move the "2 sample cycle" wait operation before adc_get_code(),
	// otherwise may have data lose due to no waiting when adc_power_on.
	// changed by chaofan.20201230.
	delayMicroseconds(21); //wait at least 2 sample cycle(f = 96K, T = 10.4us)
	value = adc_get_code();

	// Conver raw data to votage*1000, ex: 3.3v -> value~=3300
	value = adc_calculate_voltage(value);

	// tlsr9518 support 0~4.8v (1.2v * prescale 4), convert result to 0~983 (0~4.8v -> 0~983, 0~5v -> 0~1024)
	value = (value*983) / 4800;

	// Reset the ADC pin for next time analogRead
	adc_reset();

	return value;
}

static inline void analogWriteGPIO(pin_size_t pin, int value)
{
	/*
	 * Error handling for analogWrite() to the pins without PWM support.
	 * This handling method is borrowed from ArduinoCore-avr.
	 */
	if (value < 128) {
		digitalWrite(pin, LOW);
	}
	else {
		digitalWrite(pin, HIGH);
	}
}

/* PWM Output */
void analogWrite(pin_size_t pin, int value)
{
	uint32_t pwm_period, pwm_hi_cycle;
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);
	uint8_t pinindex = GpioPinToPinIndex(gpio_pin);

	// 1. Config PinMux to PWM function.
	if (pinSupportPinMux(pinindex)) {
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(pinindex, PINMUX_FUNC_PWM);
			if (err) {
				// This pin doesn't support PWM, output GPIO instead.
				analogWriteGPIO(pin, value);
				return;
			}
		}
		else if (pin_usage != PINMUX_FUNC_PWM) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}
	// This pin is used by PWM in PinMux, or this pin doesn't support PinMux.

	// Calculate pwm duty cycle (CT-1: 480M) and high level cycle
	pwm_period = PWM_PCLK_SPEED / PWM_FREQ_ANALOG_WRITE;
	// tlsr9518 pwm reg only support 16 bit
	if (pwm_period > PWM_MAX_PERIOD) {
		return;
	}
	pwm_hi_cycle = (pwm_period*value)/DUTY_LENGTH;

	pwm_id_e pwm_id = get_pwmid((pwm_pin_e)gpio_pin);

	// 2. Stop PWM first to config PWM
	pwm_stop(pwm_id);

	// 3. config PWM HW.
	pwm_set_pin(gpio_pin);
	pwm_set_clk((unsigned char) ((PCLKFREQ/PWM_PCLK_SPEED)-1));
	pwm_set_tcmp(pwm_id, pwm_hi_cycle);
	pwm_set_tmax(pwm_id, pwm_period);
	pwm_set_pwm0_mode(PWM_NORMAL_MODE);

	// 4. Start PWM
	pwm_start(pwm_id);
}

void analogReference(uint8_t mode)
{
}
