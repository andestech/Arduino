#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "Arduino.h"
#include "SPI.h"

#define SPI_DATA_LEN_8BITS     8
#define SPI_DATA_LEN_16BITS    16
#define SPI_DATA_LEN_32BITS    32

SPIClass SPI(SPI2);
SPISettings _oldSettings;

SPIClass::SPIClass(SPI_TypeDef *pSPIPort)
{
    SPIPort = pSPIPort;
}

void SPIClass::begin()
{
#if 1
    _oldSettings.clockDiv = 0;
    _oldSettings.spiBitOrder = 0;
    _oldSettings.spiDataMode = 0;
#endif
    SPI_Init_portonly(SPIPort);
    SPI_Settings(SPIPort, 7, 1); /* divisor = 7, SPI_MODE0 */
}

#if 0
void SPIClass::begin(uint8_t pin)
{
}
#endif

void SPIClass::end()
{
}

void SPIClass::beginTransaction(SPISettings settings)
{
    /*|------------------|
      |SPI_MODE|CPOL|CPHA|
      |------------------|
      |    0   |  0 |  0 |
      |------------------|
      |    1   |  0 |  1 |
      |------------------|
      |    2   |  1 |  0 |
      |------------------|
      |    3   |  1 |  1 |
      |------------------|*/

    transfer_bytes = tx_data = rx_data = 0;

    if(( settings.clockDiv != _oldSettings.clockDiv ) || \
       ( settings.spiBitOrder != _oldSettings.spiBitOrder ) || \
       ( settings.spiDataMode != _oldSettings.spiDataMode ) )
    {
        // do setting 
        _oldSettings.clockDiv = settings.clockDiv;
        _oldSettings.spiBitOrder = settings.spiBitOrder;
        _oldSettings.spiDataMode = settings.spiDataMode;

        SPI_Settings(SPIPort, settings.clockDiv, settings.spiDataMode);
    }
}

void SPIClass::endTransaction()
{
}

uint8_t SPIClass::transfer(uint8_t val)
{

    rx_data = SPI_Transfer(SPIPort, 1, val);
    transfer_bytes = 0;

    return ((uint8_t) rx_data);
}

#if 0
uint8_t SPIClass::transfer(uint8_t pin, uint8_t val)
{
}
#endif

uint8_t SPIClass::transfer(uint8_t pin, uint8_t val, SPITransferMode mode)
{
    if( mode == SPI_LAST )
    {
        tx_data |= val;
        transfer_bytes ++;
        rx_data = SPI_Transfer(SPIPort, transfer_bytes, tx_data);
        transfer_bytes = 0;
        return ((uint8_t) rx_data);
    }
    else
    {
        if ( transfer_bytes == 0 )
        {
            tx_data = rx_data = 0x0;
        }
        tx_data |= ( val << ((3 - transfer_bytes) * 8 ));
        transfer_bytes ++;
        return val;
    }
}

uint16_t SPIClass::transfer16(uint16_t val)
{
    return ((uint16_t) rx_data);
}

uint32_t SPIClass::transfer32(uint32_t val)
{
    return (rx_data);
}

void SPIClass::setBitOrder(uint8_t order)
{
    //do nothing, only MSB First
    return;
}

void SPIClass::setClockDivider(uint8_t div)
{
    SPI_SetClockFreq(SPIPort, div); /* however, ethernet library setting this value = 21, too slow */
}

void SPIClass::setDataMode(uint8_t mode)
{
    SPI_SetSPIDataMode(SPIPort, mode);
}
