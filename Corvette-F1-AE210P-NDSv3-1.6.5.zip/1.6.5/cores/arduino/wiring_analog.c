#include "wiring_analog.h"

#ifdef __cplusplus
 extern "C" {
#endif

#define SARADC_WAIT_US    (20)
#define SARADC_DELAY_US    (5)
#define SARADC_SAMPLE_CNT  (30)

uint32_t ResolutionRead = 10;
uint32_t PWMBit = 0;

#define MAX(a,b) ((a>b)?a:b)
#define DIFF(a,b) ((a>b)?(a-b):(b-a))
#define AVGSAMPLE 0
int analogRead(uint8_t pin)
{
	static int i = 0;
	i++;
	return 0;
}

void analogReadResolution(uint8_t bit)
{
}

void analogWrite(uint8_t pin, int val)
{
}

void analogReference(uint8_t mode)
{
    //The feature is not supported.
}

void analogWriteResolution(uint8_t bit)
{
}
#ifdef __cplusplus
}
#endif
