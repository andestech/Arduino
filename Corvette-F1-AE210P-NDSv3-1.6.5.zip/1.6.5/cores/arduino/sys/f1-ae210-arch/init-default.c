/*
 * Copyright (c) 2012-2015 Andes Technology Corporation
 * All rights reserved.
 *
 */
#include <nds32_intrinsic.h>
#include "config.h"
#include "assert_demos.h"

#ifdef CFG_GCOV
#include <stdio.h>
#include <stdlib.h>
#endif

#ifndef VECTOR_BASE
#define VECTOR_BASE	0x00000000
#endif

/* Arduino doesn't use bsp/nds32_defs.h currently, so we define registers manually */
#define MISC_CTL_offBTB		0	/* Disable Branch Target Buffer */
#define MISC_CTL_offRTP		1	/* Disable Return Target Predictor */

#define MISC_CTL_makBTB		( 0x1 << MISC_CTL_offBTB )
#define MISC_CTL_makRTP		( 0x1 << MISC_CTL_offRTP )

/* It will use Default_Handler if you don't have one */
#pragma weak tlb_exception_handler   = Default_Handler
#pragma weak error_exception_handler = Default_Handler
#pragma weak syscall_handler         = Default_Handler
#pragma weak HW0_ISR   = Default_Handler
#pragma weak HW1_ISR   = Default_Handler
#pragma weak HW2_ISR   = Default_Handler
#pragma weak HW3_ISR   = Default_Handler
#pragma weak HW4_ISR   = Default_Handler
#pragma weak HW5_ISR   = Default_Handler
#pragma weak HW6_ISR   = Default_Handler
#pragma weak HW7_ISR   = Default_Handler
#pragma weak HW8_ISR   = Default_Handler
#pragma weak HW9_ISR   = Default_Handler
#pragma weak HW10_ISR  = Default_Handler
#pragma weak HW11_ISR  = Default_Handler
#pragma weak HW12_ISR  = Default_Handler
#pragma weak HW13_ISR  = Default_Handler
#pragma weak HW14_ISR  = Default_Handler
#pragma weak HW15_ISR  = Default_Handler
#pragma weak HW16_ISR  = Default_Handler
#pragma weak HW17_ISR  = Default_Handler
#pragma weak HW18_ISR  = Default_Handler
#pragma weak HW19_ISR  = Default_Handler
#pragma weak HW20_ISR  = Default_Handler
#pragma weak HW21_ISR  = Default_Handler
#pragma weak HW22_ISR  = Default_Handler
#pragma weak HW23_ISR  = Default_Handler
#pragma weak HW24_ISR  = Default_Handler
#pragma weak HW25_ISR  = Default_Handler
#pragma weak HW26_ISR  = Default_Handler
#pragma weak HW27_ISR  = Default_Handler
#pragma weak HW28_ISR  = Default_Handler
#pragma weak HW29_ISR  = Default_Handler
#pragma weak HW30_ISR  = Default_Handler
#pragma weak HW31_ISR  = Default_Handler
#pragma weak SW0_ISR   = Default_Handler

extern int uart_puts(const char *);

__attribute__((unused))
static void Default_Handler()
{
	while (1) ;
}

void __null_function()
{;
}

void __c_init()
{
/* Use compiler builtin memcpy and memset */
#define MEMCPY(des, src, n) __builtin_memcpy ((des), (src), (n))
#define MEMSET(s, c, n) __builtin_memset ((s), (c), (n))

	extern char _end;
	extern char __bss_start;
	int size;

	/* data section will be copied to data local memory.*/
	extern char __data_lmastart;
	extern char __data_start;
	extern char _edata;
	/* Copy data section to RAM */
	size = &_edata - &__data_start;
	MEMCPY(&__data_start, &__data_lmastart, size);


	/* Clear bss section */
	size = &_end - &__bss_start;
	MEMSET(&__bss_start, 0, size);
	return;
}

void __cpu_init()
{
	unsigned int tmp;

	/* Enable BTB & RTP since the default setting is disabled. */
	tmp = __nds32__mfsr(NDS32_SR_MISC_CTL) & ~(MISC_CTL_makBTB | MISC_CTL_makRTP);
	__nds32__mtsr(tmp, NDS32_SR_MISC_CTL);

	/* disable all hardware interrupts */
	__nds32__mtsr(0x0, NDS32_SR_INT_MASK);
	/* INT_MASK2 only exists when IVB.IVIC_VER=1 */
	if (__nds32__mfsr(NDS32_SR_IVB) & (0x1 << 11))
		__nds32__mtsr(0x0, NDS32_SR_INT_MASK2);

#if defined(USE_C_EXT)
	/* If we use v3/v3m toolchain and want to use
	 * C extension please use USE_C_EXT in CFLAGS
	 */
#ifdef __NDS32_ISA_V3__
	/* set IVIC, vector size: 4 bytes, base: VECTOR_BASE */
	__nds32__mtsr(VECTOR_BASE, NDS32_SR_IVB);
#else
	/* set IVIC, vector size: 16 bytes, base: VECTOR_BASE */
	__nds32__mtsr(VECTOR_BASE | 0x1<<14, NDS32_SR_IVB);
#endif

#else
	/* set IVIC, vector size: 4 bytes, base: VECTOR_BASE
	 * If we use v3/v3m toolchain and want to use
	 * assembly version please don't use USE_C_EXT
	 * in CFLAGS */
	__nds32__mtsr(VECTOR_BASE, NDS32_SR_IVB);
#endif

	/* Set PSW INTL to 0 */
	tmp = __nds32__mfsr(NDS32_SR_PSW);
	tmp = tmp & 0xfffffff9;
	/* Set PSW CPL to 7 to allow any priority */
	tmp = tmp | 0x70008;
#ifdef __NDS32_ISA_V3__
#ifdef CFG_HWZOL
	/* Enable PSW AEN */
	tmp = tmp | 0x2000;
#endif
#endif
	__nds32__mtsr_dsb(tmp, NDS32_SR_PSW);

	/* Check interrupt priority programmable*
	* IVB.PROG_PRI_LVL
	*      0: Fixed priority       -- no exist ir18 1r19
	*      1: Programmable priority
	*/
	if (__nds32__mfsr(NDS32_SR_IVB) & 0x01) {
		/* Set PPL2FIX_EN to 0 to enable Programmable
	 	* Priority Level */
		__nds32__mtsr(0x0, NDS32_SR_INT_CTRL);

		/* set priority HW9: 0, HW13: 1, HW19: 2,
		* HW#-: default 0 */
		__nds32__mtsr(0x04000000, NDS32_SR_INT_PRI);
		__nds32__mtsr(0x00000080, NDS32_SR_INT_PRI2);

	}

	return;
}

void __soc_init();

void __init()
{
/*----------------------------------------------------------
   !!  Users should NOT add any code before this comment  !!
------------------------------------------------------------*/
	__cpu_init();
	__c_init();     //copy data section, clean bss

	__soc_init();

	/* Double check ZOL supporting */
	/*
	 * Check whether the CPU configured with ZOL supported.
	 * The MSC_CFG.MSC_EXT($cr4) indicates MSC_CFG2 register exist
	 * and MSC_CFG2($cr7) bit 5 indicates ZOL supporting.
	 */
#ifdef CFG_HWZOL
	if (!((__nds32__mfsr(NDS32_SR_MSC_CFG) & (3 << 30))
	    && (__nds32__mfsr(NDS32_SR_MSC_CFG2) & (1 << 5)))) {
		/* CPU doesn't support ZOL, but build with ZOL supporting. */
		//uart_puts("CPU doesn't support ZOL, but build with ZOL supporting !!\n");
#ifdef CFG_GCOV
		exit(1);
#else
		while(1);
#endif
	}
#endif
}

#ifdef CFG_GCOV
void abort(void)
{
	fflush(stdout);
	exit(1);
}
#endif
