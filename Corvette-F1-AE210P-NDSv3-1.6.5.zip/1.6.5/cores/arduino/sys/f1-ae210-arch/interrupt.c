/*
 * Copyright (c) 2012-2015 Andes Technology Corporation
 * All rights reserved.
 *
 */
#include <nds32_intrinsic.h>
#include "config.h"
#include "f1_ae210.h"
#include "f1_ae210_int.h"
#include "f1_ae210_timer.h"

#ifdef CFG_GCOV
#include <stdlib.h>
#endif


inline void GIE_ENABLE()
{
	__nds32__setgie_en();
}

inline void GIE_DISABLE()
{
	__nds32__setgie_dis();
	__nds32__dsb();
}

 /* this function generates a s/w interrupt */
void gen_swi()
{
	unsigned int int_pend;

	int_pend = __nds32__mfsr(NDS32_SR_INT_PEND);
	int_pend |= 0x10000;
	__nds32__mtsr(int_pend, NDS32_SR_INT_PEND);
	__nds32__dsb();
}

/* Set the corresponding IRQ source to be routed to HW vector. */
void setIRQ_ivic(unsigned int vector, int hw)
{
}

void enableIntr(unsigned int mask, int edge, int neg)
{
}

void enableFiqIntr(unsigned int mask, int edge, int neg)
{
}

void Tmr_TickInit()
{
}

void intc_reset()
{
}

void initIntr()
{
	/* Init GPIO */
	HAL_GPIO_INITIALIZE(GPIO_USED_MASK);

	/* Init timer */
	//Tmr_TickInit();

	/* 32 IVIC initialization */

	/* set TIMER1 priority to lowest */
	__nds32__set_int_priority(NDS32_HWINT(IRQ_PIT), 3);

	/* enable HW# (timer1, GPIO & SWI) */
	__nds32__enable_int(NDS32_HWINT(IRQ_PIT));
	__nds32__enable_int(NDS32_HWINT(IRQ_GPIO));
	__nds32__enable_int(NDS32_HWINT(IRQ_SWI));

	/* Interrupt pending register, write 1 to clear */
	__nds32__mtsr(0xFFFFFFFF, NDS32_SR_INT_PEND2);
}

void initIntr_standby()
{
	/* Init GPIO */
	HAL_GPIO_INITIALIZE(GPIO_USED_MASK);

	/* 32 IVIC initialization */

	/* enable HW (GPIO) */
	__nds32__enable_int(NDS32_HWINT(IRQ_GPIO));
	/* Interrupt pending register, write 1 to clear */
	__nds32__mtsr(0xFFFFFFFF, NDS32_SR_INT_PEND2);
}

void clear_swi()
{
	/*
	 * Since INT_PEND is the RO register except bit:16 (SWI),
	 * set zero value to it directly to clear bit:16.
	 */
	__nds32__clr_pending_swint();
}

void SW0_ISR()
{
	clear_swi();
}

/* SW, GPIO and Timer hardware interrupt will only occur on IVIC version (IVB.IVIC_VER) = 1. */
void SWI_ISR()
{
	SW0_ISR();
}

#if 0
void GPIO_ISR()
{
}
#endif

void TIMER_ISR()
{
	GIE_ENABLE();

	if(gTIMER1Callback)
		gTIMER1Callback();
}


/***************************************************************************

****************************************************************************/
int ISR_InsertCb(int intType,int intNum,IRQ_Callback cb)
{
	return 0;
}

