#ifndef F1_AE100_TIMER_H_
#define F1_AE100_TIMER_H_

#include "f1_ae210.h"
#include "typedef.h"
/***********************************************************************************************
*   MARCOS
************************************************************************************************/
#define TIMER_CLK_SRC_EXT   (0)
#define TIMER_CLK_SRC_APB   (1)

#define TIMER1          0
#define TIMER2          1
#define TIMER3          2
#define TIMER4          3

/***********************************************************************************************
*   SOC Timer definition
************************************************************************************************/

/********************* Bit definition of Timer interrupt enable register **********************/
#define PIT_IER_CH0INT0EN		(0x1 << 0)
#define PIT_IER_CH0INT1EN		(0x1 << 1)
#define PIT_IER_CH0INT2EN		(0x1 << 2)
#define PIT_IER_CH0INT3EN		(0x1 << 3)
#define PIT_IER_CH1INT0EN		(0x1 << 4)
#define PIT_IER_CH1INT1EN		(0x1 << 5)
#define PIT_IER_CH1INT2EN		(0x1 << 6)
#define PIT_IER_CH1INT3EN		(0x1 << 7)
#define PIT_IER_CH2INT0EN		(0x1 << 8)
#define PIT_IER_CH2INT1EN		(0x1 << 9)
#define PIT_IER_CH2INT2EN		(0x1 << 10)
#define PIT_IER_CH2INT3EN		(0x1 << 11)
#define PIT_IER_CH3INT0EN             (0x1 << 12)
#define PIT_IER_CH3INT1EN             (0x1 << 13)
#define PIT_IER_CH3INT2EN             (0x1 << 14)
#define PIT_IER_CH3INT3EN             (0x1 << 15)


/********************* Bit definition of Timer interrupt status register **********************/
#define PIT_ISR_CH0INT0ST             (0x1 << 0)
#define PIT_ISR_CH0INT1ST             (0x1 << 1)
#define PIT_ISR_CH0INT2ST             (0x1 << 2)
#define PIT_ISR_CH0INT3ST             (0x1 << 3)
#define PIT_ISR_CH1INT0ST             (0x1 << 4)
#define PIT_ISR_CH1INT1ST             (0x1 << 5)
#define PIT_ISR_CH1INT2ST             (0x1 << 6)
#define PIT_ISR_CH1INT3ST             (0x1 << 7)
#define PIT_ISR_CH2INT0ST             (0x1 << 8)
#define PIT_ISR_CH2INT1ST             (0x1 << 9)
#define PIT_ISR_CH2INT2ST             (0x1 << 10)
#define PIT_ISR_CH2INT3ST             (0x1 << 11)
#define PIT_ISR_CH3INT0ST             (0x1 << 12)
#define PIT_ISR_CH3INT1ST             (0x1 << 13)
#define PIT_ISR_CH3INT2ST             (0x1 << 14)
#define PIT_ISR_CH3INT3ST             (0x1 << 15)

/********************* Bit definition of Timer channel enable register **********************/
#define PIT_CER_CH0TMR0EN               (0x1 << 0)
#define PIT_CER_CH0TMR1EN               (0x1 << 1)
#define PIT_CER_CH0TMR2EN               (0x1 << 2)
#define PIT_CER_CH0TMR3EN               (0x1 << 3)
#define PIT_CER_CH1TMR0EN               (0x1 << 4)
#define PIT_CER_CH1TMR1EN               (0x1 << 5)
#define PIT_CER_CH1TMR2EN               (0x1 << 6)
#define PIT_CER_CH1TMR3EN               (0x1 << 7)
#define PIT_CER_CH2TMR0EN               (0x1 << 8)
#define PIT_CER_CH2TMR1EN               (0x1 << 9)
#define PIT_CER_CH2TMR2EN               (0x1 << 10)
#define PIT_CER_CH2TMR3EN               (0x1 << 11)
#define PIT_CER_CH3TMR0EN             (0x1 << 12)
#define PIT_CER_CH3TMR1EN             (0x1 << 13)
#define PIT_CER_CH3TMR2EN             (0x1 << 14)
#define PIT_CER_CH3TMR3EN             (0x1 << 15)

/********************* Bit definition of Timer channel control register **********************/
#define PIT_CCR_CH_MODE			(0x7)
#define PIT_CCR_CH_CLK			(0x1 << 3)
#define PIT_CCR_PWM_PARK		(0x1 << 4)


#define TIMER1_INT_CLEAR()	( PIT->INTST = 0xF )
/**************************************************************************************************
 *   GLOBAL PROTOTYPES
 *************************************************************************************************/

typedef void (DRVTIMER_Callback)(void);

extern DRVTIMER_Callback *gTIMER1Callback;
extern DRVTIMER_Callback *gTIMER2Callback;
extern DRVTIMER_Callback *gTIMER3Callback;
extern DRVTIMER_Callback *gTIMER4Callback;

void TIMER_RegisterCallback(u8 u8TimerIdx,DRVTIMER_Callback cb);
void TIMER_Init(u8 u8Ch,u8 u8Mode,u8 u8TimerIdx,u8 u8ClkSrc,u32 u32LoadCnt);
void TIMER_DeInit(u8 u8Ch,u8 u8TimerIdx);
void TIMER_Start(u8 u8Ch,u8 u8TimerIdx);
void TIMER_Stop(u8 u8Ch,u8 u8TimerIdx);
void TIMER_SetMatchValue(u8 u8Ch,u8 u8TimerIdx,u32 u32Match1,u32 u32Match2);
void TIMER_EnableInt(u8 u8Ch,u8 u8TimerIdx);
void TIMER_DisableInt(u8 u8Ch,u8 u8TimerIdx);
void TIMER_SetCpupllDivider(u8 u8TimerIdx,u8 u8Divider);
u32 TIMER_GetCounter(u8 u8Ch,u8 u8TimerIdx);

#endif /* F1_AE100_TIMER_H_ */
