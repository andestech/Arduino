#ifndef WINTERRUPTS_H
#define WINTERRUPTS_H

#include <inttypes.h>
#include "f1_ae210_gpio.h"

void GPIO_Callback(u32 int_status_bit);
void attachInterrupt(uint32_t pin_m, void (*callback)(void), uint32_t mode);
void detachInterrupt(uint32_t pin_m);

#endif //WINTERRUPTS_H

