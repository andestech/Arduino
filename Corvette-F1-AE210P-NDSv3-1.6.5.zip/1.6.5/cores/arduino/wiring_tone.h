#ifndef WIRING_TONE_H
#define WIRING_TONE_H

#include "typedef.h"


#ifdef __cplusplus
extern "C" {
#endif

void tone(uint8_t pin, unsigned int frequency, unsigned long duration = 0);

#ifdef __cplusplus
}
#endif


void noTone(uint8_t pin);

#endif //WIRING_TONE_H
