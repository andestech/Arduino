/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "wiring_digital.h"
int pinMap[PIN_NUM] = {
	0,//D0 :uart2_rxd
	0,//D1 :uart2_txd
	18,//D2
	19,//D3
	20,//D4
	21,//D5
	22,//D6
	23,//D7
	24,//D8
	25,//D9
	26,//D10
	0,//D11 :spi2_mosi
	0,//D12	:spi2_miso
	0,//D13 :spi2_clk
	0,//D14 :i2c_sda
	0,//D15 :i2c_scl
	1,//BTN1
	2,//BTN2
	3,//BTN3
	4,//BTN4
	5,//LED1
	6,//LED2
	7,//LED3
	8//LED4
};

void pinMode( int pin, IO_TYPE mode )
{
	int io_ch = pinMap[pin];

	if (mode == INPUT)
	{
		GPIO_SetDir(io_ch, GPIO_INPUT);
	}
    	else if (mode == INPUT_PULLUP)
	{
		GPIO_SetDir(io_ch, GPIO_INPUT);
		GPIO_SetInputType(io_ch, GPIO_PULL_UP);
	}
	else if (mode == OUTPUT)
	{
		GPIO_SetDir(io_ch, GPIO_OUTPUT);
	}
}

void digitalWrite( int pin, int value )
{
	int io_ch = pinMap[pin];

	if(value == HIGH)
		GPIO_SetOutput(io_ch, GPIO_HIGH);
	else
		GPIO_SetOutput(io_ch, GPIO_LOW);
}

int digitalRead( int pin )
{
	int io_ch = pinMap[pin];

	if(!GPIO_GetBit(io_ch))
		return LOW;
	else
		return HIGH;
}


