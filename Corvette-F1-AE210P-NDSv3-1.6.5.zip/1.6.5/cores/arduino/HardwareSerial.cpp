//#include "Arduino.h"
#include "HardwareSerial.h"

HardwareSerial::HardwareSerial(UART_RegDef *pUartConsole) {
	UartConsole = pUartConsole;
}

void HardwareSerial::begin(uint32_t baud)
{
	begin(baud, SERIAL_8N1);
}

void HardwareSerial::begin(uint32_t baud,uint32_t config)
{
	u8 UART_DRV_DATABITS = (u8) ((config >> 8) & 0xf);
	u8 UART_DRV_STOPBITS = (u8) (config & 0xf);
	u8 UART_DRV_PARITY = (u8) ((config >> 4) & 0xf);
	UART_DATA_t tUartData ={baud, \
		UART_DRV_DATABITS,UART_DRV_STOPBITS,UART_DRV_PARITY};
	UART_Init(UartConsole,&tUartData);
	UART_IsrInit(UartConsole);
}

void HardwareSerial::end()
{
	UART_DeInit(UartConsole);
}

int HardwareSerial::available(void)
{
	return UART_IsDataAvailable(UartConsole);
}

int HardwareSerial::read(void)
{
	if(available())
		return (int)UART_ReadByte(UartConsole);
	else
		return -1;
}

size_t HardwareSerial::write(uint8_t c)
{
	UART_WriteByte(UartConsole,c);
	return 1;
}
int HardwareSerial::peek(void)
{
	if(available())
		return (int)UART_PeekByte(UartConsole);
	else
		return -1;
}
void HardwareSerial::flush()
{
	UART_Flush(UartConsole);
}

int HardwareSerial::availableForWrite() {
	return UART_BytesAvailableForWrite(UartConsole);
}

#ifdef TESTING

void HardwareSerial::insertRcvData(char* buffer, unsigned int len) {
	insertStrToRcvQueue(buffer, len);
}

void HardwareSerial::insertSendData(char* buffer, unsigned int len) {
	insertStrToSendQueue(buffer, len);
}

#endif

HardwareSerial Serial(UART1);
HardwareSerial Serial1(UART0);
