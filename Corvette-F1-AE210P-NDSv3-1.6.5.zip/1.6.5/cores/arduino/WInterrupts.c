/*
  Copyright (c) 2011-2012 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef WINTERRUPT_H
#define WINTERRUPT_H

#include "WInterrupts.h"
#include "wiring_digital.h"


static int first_attach_func =0;

struct gpio_struct
{
	void (*interrupt_func)(void);
};

struct gpio_struct gpio_table[GPIO_NUM];

void GPIO_Callback(u32 int_status_bit)
{
	uint32_t int_pin;
	int i;
	void (*int_func)(void);
	int_pin = 0xFF;

	for ( i = 0; i < GPIO_NUM ; i++) {
		if (((int_status_bit >> i) & 0x1) == 1) {
			int_pin = i;
			break;
		}
	}

	if (int_pin < 32) {
		/* Execute interrupt function */
		int_func = gpio_table[int_pin].interrupt_func;
		int_func();
	}
}

void attachInterrupt(uint32_t pin, void (*callback)(void), uint32_t mode)
{
	uint32_t int_ch = pinMap[pin];

	/* Setup callback function at first time */
	if (first_attach_func == 0){
		GPIO_RegisterCallback(GPIO_Callback);
		GPIO_IsrInit();
		first_attach_func += 1;
	}

	/* Register Interrupt callback function */
	gpio_table[int_ch].interrupt_func = callback;

	/* Enable GPIO interrupt */
	GPIO_EnableInt(int_ch,mode);
}

void detachInterrupt(uint32_t pin)
{
	uint32_t int_ch = pinMap[pin];
	/* Disable Interrupt */
	GPIO_DisableInt(int_ch);
}

#endif //WINTERRUPT_H
