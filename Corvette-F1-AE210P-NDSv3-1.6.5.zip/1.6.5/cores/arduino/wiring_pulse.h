#include "typedef.h"

unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout = 1000000L);
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout);
