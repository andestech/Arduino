/**************************************************************************************************
 *   INCLUDES
 *************************************************************************************************/
#include <stdio.h>
#include <string.h>
#include <nds32_intrinsic.h>
#include "typedef.h"
#include "f1_ae100.h"
#include "f1_ae100_int.h"

/**************************************************************************************************
 *   MACROS
 *************************************************************************************************/

/**************************************************************************************************
 *   CONSTANTS AND DEFINES
 *************************************************************************************************/

/**************************************************************************************************
 *   TYPEDEFS
 *************************************************************************************************/

/**************************************************************************************************
 *   GLOBAL VARIABLES
 *************************************************************************************************/

/**************************************************************************************************
 *   GLOBAL FUNCTIONS
 *************************************************************************************************/


void INT_IrqEn(unsigned int mask, int edge, int neg)//void enableIntr(unsigned int mask, int edge, int neg)
{
	u32 val;

	// Clear and Enable IRQ
      	__nds32__mtsr(mask, NDS32_SR_INT_PEND2);

      	val = __nds32__mfsr(NDS32_SR_INT_MASK2);
     	__nds32__mtsr(val | mask, NDS32_SR_INT_MASK2);

      	// Enable GIE
      	__nds32__setgie_en();
}

void INT_IrqDis(unsigned int mask)
{
	u32 val;

	// Clear and Disable IRQ
	__nds32__mtsr(mask, NDS32_SR_INT_PEND2);

	val = __nds32__mfsr(NDS32_SR_INT_MASK2);
	__nds32__mtsr(val & (~mask), NDS32_SR_INT_MASK2);

	// Enable GIE
	__nds32__setgie_en();
}

void INT_IrqStsClr(unsigned int mask)
{
}

void INT_FiqEn(unsigned int mask, int edge, int neg)
{
}

void INT_FiqDis(unsigned int mask)
{
}

void INT_FiqStsClr(unsigned int mask)
{
}

void INT_GblIsrEn(void)
{
    GIE_ENABLE();
}

void INT_GblIsrDis(void)
{
    GIE_DISABLE();
}


void INT_IntReset(void)
{
}



