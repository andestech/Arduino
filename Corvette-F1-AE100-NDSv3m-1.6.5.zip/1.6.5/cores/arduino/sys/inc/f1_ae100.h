#ifndef _F1_AE100_H
#define _F1_AE100_H

#ifndef __ASSEMBLER__
#include <nds32_intrinsic.h>
#include "typedef.h"
#endif

/*****************************************************************************
 * System clock
 ****************************************************************************/
#define KHz                     1000
#define MHz                     1000000

#define MB_OSCCLK               (20 * MHz)
#define MB_UCLK                 (MB_OSCCLK)

/*****************************************************************************
 * Interrupts vector base
 ****************************************************************************/
#define VECTOR_BASE             0x00000000

/******************************************************************************
 *  IRQ number
 *****************************************************************************/
#define IRQ_RESERVED0           0
#define IRQ_RESERVED1           1
#define IRQ_PIT                 2
#define IRQ_SPI                 3
#define IRQ_RESERVED2           4
#define IRQ_RESERVED3           5
#define IRQ_GPIO                6
#define IRQ_UART1               7
#define IRQ_UART2               8
#define IRQ_RESERVED4           9
#define IRQ_RESERVED5           10
#define IRQ_SWI                 11
#define IRQ_RESERVED6           12
#define IRQ_RESERVED7           13
#define IRQ_RESERVED8           14
#define IRQ_RESERVED9           15

/************************************
 *  HAL Level : Interrupt           *
 ************************************/
#define NDS32_HWINT_ID(hw)      NDS32_INT_H##hw
#define NDS32_HWINT(hw)         NDS32_HWINT_ID(hw)

#define HW_ISR(n)               HW##n##_ISR
#define SET_HWISR(hw)           HW_ISR(hw)

// ISR function name for PIT/GPIO/SWI */
#define TIMER_ISR               SET_HWISR(IRQ_PIT)
#define GPIO_ISR                SET_HWISR(IRQ_GPIO)
#define SWI_ISR                 SET_HWISR(IRQ_SWI)
#define UART0_ISR               SET_HWISR(IRQ_UART1)
#define UART1_ISR               SET_HWISR(IRQ_UART2)

#ifdef __ASSEMBLER__
/************************************
 *  HAL : AE100 defined vectors    *
 ************************************/
.macro  hal_hw_vectors
	vector Interrupt_UNDEF   //  (9) Interrupt HW0
	vector Interrupt_UNDEF   // (10) Interrupt HW1
	vector Interrupt_HW2     // (11) Interrupt HW2 (PIT)
	vector Interrupt_UNDEF   // (12) Interrupt HW3
	vector Interrupt_UNDEF   // (13) Interrupt HW4
	vector Interrupt_UNDEF   // (14) Interrupt HW5
	vector Interrupt_HW6     // (15) Interrupt HW6 (GPIO)
	vector Interrupt_HW7     // (16) Interrupt HW7 (UART1)
	vector Interrupt_HW8     // (17) Interrupt HW8 (UART2)
	vector Interrupt_UNDEF   // (18) Interrupt HW9
	vector Interrupt_UNDEF   // (19) Interrupt HW10
	vector Interrupt_HW11    // (20) Interrupt HW11 (SWI)
	vector Interrupt_UNDEF   // (21) Interrupt HW12
	vector Interrupt_UNDEF   // (22) Interrupt HW13
	vector Interrupt_UNDEF   // (23) Interrupt HW14
	vector Interrupt_UNDEF   // (24) Interrupt HW15
	vector Interrupt_UNDEF   // (25) Interrupt HW16
	vector Interrupt_UNDEF   // (26) Interrupt HW17
	vector Interrupt_UNDEF   // (27) Interrupt HW18
	vector Interrupt_UNDEF   // (28) Interrupt HW19
	vector Interrupt_UNDEF   // (29) Interrupt HW20
	vector Interrupt_UNDEF   // (30) Interrupt HW21
	vector Interrupt_UNDEF   // (31) Interrupt HW22
	vector Interrupt_UNDEF   // (32) Interrupt HW23
	vector Interrupt_UNDEF   // (33) Interrupt HW24
	vector Interrupt_UNDEF   // (34) Interrupt HW25
	vector Interrupt_UNDEF   // (35) Interrupt HW26
	vector Interrupt_UNDEF   // (36) Interrupt HW27
	vector Interrupt_UNDEF   // (37) Interrupt HW28
	vector Interrupt_UNDEF   // (38) Interrupt HW29
	vector Interrupt_UNDEF   // (39) Interrupt HW30
	vector Interrupt_UNDEF   // (40) Interrupt HW31
.endm

.macro  hal_hw_ISR
	Os_Trap_Interrupt_HW	IRQ_PIT,1       // Nested
	Os_Trap_Interrupt_HW	IRQ_GPIO,0      // Non-Nested
	Os_Trap_Interrupt_HW	IRQ_SWI,1       // Nested
	Os_Trap_Interrupt_HW	IRQ_UART1,0
	Os_Trap_Interrupt_HW	IRQ_UART2,0
.endm


.macro  hal_set_led, val
.endm
#endif  /* __ASSEMBLER__ */


/* Low-level port I/O */
#define inw(reg)        (*((volatile unsigned int *) (reg)))
#define outw(reg, data) ((*((volatile unsigned int *)(reg)))=(unsigned int)(data))


/************************************
 *  HAL :F1 AE100 GPIO    *
 ************************************/

#define HAL_GPIO_INITIALIZE(_pin_)		\
do {						\
        GPIO->CHANNELDIR &= ~_pin_;		\
        GPIO->DOUTCLEAR = -1;			\
        GPIO->INTRMODE0 = 0x55555555;		\
        GPIO->INTRMODE1 = 0x55555555;		\
        GPIO->INTRMODE2 = 0x55555555;		\
        GPIO->INTRMODE3 = 0x55555555;		\
        GPIO->DEBOUNCECTRL = 0x800000FF;	\
        GPIO->DEBOUNCEEN = _pin_;		\
        GPIO->INTRSTATUS = -1;			\
        GPIO->INTREN =  _pin_;			\
} while(0)

#define GPIO_USED_GCOV          0x02    /* Which GPIO to do GCOV */
#define GPIO_USED_MASK          0x7F    /* Which GPIOs to use */


#ifndef __ASSEMBLER__

/******************************************************************************
 *  Memory map
 *****************************************************************************/

typedef struct
{
	__R  unsigned int IDREV;	/* 0x00		ID and Revision register */
	     unsigned int RESERVED0[3];	/* 0x04~0x0C 	Reserved */
	__RW unsigned int CONFIG;	/* 0x10		Configuration register */
	     unsigned int RESERVED1[3];	/* 0x14~0x1C	Reserved */
	__R  unsigned int DATAIN;	/* 0x20		Data-In register */
	__W  unsigned int DATAOUT;	/* 0x24		Data-out register */
	__RW unsigned int CHANNELDIR;	/* 0x28		Channel direction register */
	__W  unsigned int DOUTCLEAR;	/* 0x2C		Channel data-out register */
	__W  unsigned int DOUTSET;	/* 0x30		Channel data-out set register */
	     unsigned int RESERVED2[3];	/* 0x34~0x3C	Reserved */
	__RW unsigned int PULLEN;	/* 0x40		Pull enable register */
	__RW unsigned int PULLTYPE;	/* 0x44		Pull type register */
	     unsigned int RESERVED3[2];	/* 0x48~0x4C	Reserved */
	__RW unsigned int INTREN;	/* 0x50		Interrupt enable register */
	__RW unsigned int INTRMODE0;	/* 0x54		Interrupt mode register[0~7] */
	__RW unsigned int INTRMODE1;	/* 0x58		Interrupt mode register[8~15] */
	__RW unsigned int INTRMODE2;	/* 0x5C		Interrupt mode register[16~23] */
	__RW unsigned int INTRMODE3;	/* 0x60		Interrupt mode register[24~31] */
	__RW unsigned int INTRSTATUS;	/* 0x64		Interrupt status register */
	     unsigned int RESERVED4[2];	/* 0x68~0x6C	Reserved */
	__RW unsigned int DEBOUNCEEN;	/* 0x70		De-bounce enable register */
	__RW unsigned int DEBOUNCECTRL;	/* 0x74		De-bounce control register */
	     unsigned int RESERVED5[2];	/* 0x78~0x7C	Reserved */

}GPIO_TypeDef;

typedef struct {
        __R  unsigned int IDREV;                /* 0x00 ID and Revision Register */
             unsigned int RESERVED0[3];         /* 0x04 ~ 0x0C Reserved */
        __R  unsigned int CFG;                  /* 0x10 Hardware Configure Register */
        __RW unsigned int OSCR;                 /* 0x14 Over Sample Control Register */
             unsigned int RESERVED1[2];         /* 0x18 ~ 0x1C Reserved */
        union {
                __RW unsigned int RBR;          /* 0x20 Receiver Buffer Register */
                __W  unsigned int THR;          /* 0x20 Transmitter Holding Register */
                __RW unsigned int DLL;          /* 0x20 Divisor Latch LSB */
        };
        union {
                __RW unsigned int IER;          /* 0x24 Interrupt Enable Register */
                __RW unsigned int DLM;          /* 0x24 Divisor Latch MSB */
        };
        union {
                __RW unsigned int IIR;          /* 0x28 Interrupt Identification Register */
                __W  unsigned int FCR;          /* 0x28 FIFO Control Register */
        };
        __RW unsigned int LCR;                  /* 0x2C Line Control Register */
        __RW unsigned int MCR;                  /* 0x30 Modem Control Register */
        __RW unsigned int LSR;                  /* 0x34 Line Status Register */
        __RW unsigned int MSR;                  /* 0x38 Modem Status Register */
        __RW unsigned int SCR;                  /* 0x3C Scratch Register */
}UART_RegDef;


typedef struct {
        __RW unsigned int  CTRL;                 // PIT Channel Control Register
        __RW unsigned int  RELOAD;               // PIT Channel Reload Register
        __RW unsigned int  COUNTER;              // PIT Channel Counter Register
        __RW unsigned int  RESERVED[1];
}PIT_CHANNEL_REG;

typedef struct {
        __R  unsigned int IDREV;                /* 0x00 ID and Revision Register */
             unsigned int RESERVED[3];          /* 0x04 ~ 0x0C Reserved */
        __R  unsigned int CFG;                  /* 0x10 Configuration Register */
        __RW unsigned int INTEN;                /* 0x14 Interrupt Enable Register */
        __RW unsigned int INTST;                /* 0x18 Interrupt Status Register */
        __RW unsigned int CHNEN;                /* 0x1C Channel Enable Register */
        PIT_CHANNEL_REG   CHANNEL[4];           /* 0x20 ~ 0x50 Channel #n Registers */
}PIT_RegDef;

typedef struct {
	__R  unsigned int SYSVER;		/* 0x00 System ID and revision */
	     unsigned int RESERVED0[3];		/* 0x04 ~ 0x0C Reserved */
	__R  unsigned int BID;			/* 0x10 Board ID */
	__RW unsigned int RSR;			/* 0x14 Reset status */
	     unsigned int RESERVED1;		/* 0x18 Reserved */
	__RW unsigned int CMDR;			/* 0x1C System command */
	__R  unsigned int ITT;			/* 0x20 Interrupt trigger type */
	__RW unsigned int IVB;			/* 0x24 Interruption vector base */
}SMU_RegDef;


/**************************************************

		Memory map

**************************************************/
/*
#define	MEM1_BASE		(0x00000000)
#define	MEM2_BASE		(0x00020000)
#define	SPI_MEM_BASE		(0x00800000)
#define	AHB_DEC_BASE		(0x00E00000)
#define	APB_BRG_BASE		(0x00F00000)
*/
#define	SMU_BASE		(0x00F01000)

#define UART0_BASE		(0x00F02000)
#define	UART1_BASE		(0x00F03000)

#define	PIT_BASE		(0x00F04000)
//#define	WDT_BASE		(0x00F05000)

#define GPIO_BASE		(0x00F07000)

//#define	SPI_REG_BASE		(0x00F0B000)

#define GPIO	((GPIO_TypeDef*)GPIO_BASE)
#define UART0   ((UART_RegDef *)UART0_BASE)
#define UART1   ((UART_RegDef *)UART1_BASE)
#define PIT	((PIT_RegDef *) PIT_BASE)
#define SMU	((SMU_RegDef *)	SMU_BASE)

#endif	/*__ASSEMBLER__*/

#endif /* _F1_AE100_H */



