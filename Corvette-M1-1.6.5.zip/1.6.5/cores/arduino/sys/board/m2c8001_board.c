/*!
 **************************************************************************************************
 *  \copyright
 *    Copyright (c) 2012-2013 M-Square Comm.
 *    This software is the proprietary information of M2C Comm.
 *    All Right Reserved.
 **************************************************************************************************
 *  \file m2c8001_board.c
 *  \brief M2C8001 init function
 *  $Date: 2014-04-14
 *
 *
 * ------------------------------------------------------------------------------------------------
 */


/***********************************************************************************************
*   INCLUDES
************************************************************************************************/
#include "m2c8001_int.h"
#include "m2c8001_gpio.h"
#include "m2c8001_timer.h"
#include "m2c8001_sys.h"
#include "m2c8001_pmu.h"

/***********************************************************************************************
*   GLOBAL VARIABLES
************************************************************************************************/


/***********************************************************************************************
*   LOCAL FUNCTIONS
************************************************************************************************/
static void IsrInit(void)
{
    extern void initIntr();
    //extern void GIE_ENABLE();
    /* Initialize interrupt */
    initIntr();
    GIE_ENABLE();
    GPIO_IsrInit();
    TIMER_IsrInit(TIMER1);
}


/***********************************************************************************************
*   GLOBAL FUNCTIONS
************************************************************************************************/

/***********************************************************************************************
@brief:System Init function of SOC m2c8001
***********************************************************************************************/
void System_init(void)
{
    /*Init ISR function*/
    IsrInit();
    /*Default CPUPLL is disable,turn on when system init*/
/* 1. SW_CFG.SW_CPUPLL_EN (0xF18000[5])= 0x1 */
    PMU->SWCFG |= PMU_SW_CPUPLL_EN;
    outw(0xD0002C,inw(0xD0002C) | 0x80000); // RF, CPU PLL enable
/* 2.	CLKS.SEL_APB_CLK(0xF19014[3:2])= 0x0 */
    CGU->DIPCLKSEL = (CGU->DIPCLKSEL &~DIP_CLK_SEL_APB_MASK) | DIP_CLK_SEL_APB_XO;

/* 3. PMU_CFG.STOP_EN (0xF18008[3])= 0x1 */
    PMU->PWRMODE |= PMU_PWRMODE_STOP_EN;

/* 4. __nds32__standby_wait_done */
    __nds32__standby_wait_done();

/* 5. Reconfigure CPUPLL setting */
    SYS_SetCpupllFreq(CPUPLL_FREQ_60M);

/* 6. CLKS.SEL_APB_CLK(0xF19014[3:2])= 0x1 */
    CGU->DIPCLKSEL = (CGU->DIPCLKSEL &~DIP_CLK_SEL_APB_MASK) | DIP_CLK_SEL_APB_CPUPLL;

/* 7.	PMU_CFG.STOP_EN (0xF18008[3])= 0x1 */
    PMU->PWRMODE |= PMU_PWRMODE_STOP_EN;

/* 8. ssue STANDBY(2) instruction or function call standby_wait_done() */
    __nds32__standby_wait_done();
}

