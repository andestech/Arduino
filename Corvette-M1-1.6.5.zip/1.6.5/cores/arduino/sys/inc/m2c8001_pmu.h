#ifndef M2C8001_PMU_H_
#define M2C8001_PMU_H_

#include "m2c8001.h"

#define PMU_SW_CPUPLL_EN     (0x1 << 5) /*Enable CPUPLL*/



#define PMU_PWRMODE_STOP_EN        (0x1 << 3) /*Stop CPU*/


#endif /* M2C8001_PMU_H_ */
