#include <inttypes.h>

#include "pinmux.h"
#include "ae250.h"

/*
 * Define a short alias of PinFunction which is only used in this C file,
 * because writing the origin name in the PinMux Table is too long.
 */
#define UNUSED PINMUX_FUNC_UNUSED
#define GPIO   PINMUX_FUNC_GPIO
#define PWM    PINMUX_FUNC_PWM
#define UART   PINMUX_FUNC_UART
#define I2C    PINMUX_FUNC_I2C
#define SPI    PINMUX_FUNC_SPI

static const PinMuxSource* pinSourceOfFunction(const PinMuxInfo* pin_info, PinFunction pin_function)
{
	for (int i = 0; i < pin_info->source_num; ++i) {
		if (pin_info->source_list[i].function == pin_function) {
			return &(pin_info->source_list[i]);
		}
	}

	// pin mux doesn't support this function.
	return NULL;
}

const _PinMuxInfoList PinMuxInfoList = {{
	/* source_num = 0 means that this pin doesn't support pin mux. */
	/*  GPIO0 */ { 0 },
	/*  GPIO1 */ { 0 },
	/*  GPIO2 */ { 0 },
	/*  GPIO3 */ { 0 },
	/*  GPIO4 */ { 0 },
	/*  GPIO5 */ { 0 },
	/*  GPIO6 */ { 0 },
	/*  GPIO7 */ { 0 },
	/*  GPIO8 */ { 0 },
	/*  GPIO9 */ { 0 },
	/* GPIO10 */ { 0 },
	/* GPIO11 */ { 0 },
	/* GPIO12 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO13 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO14 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO15 */ { 2, {{GPIO, 0}, {PWM, 1}} },

	/* GPIO16 */ { 3, {{UART, 0}, {PWM, 1}, {GPIO, 2}} },
	/* GPIO17 */ { 3, {{UART, 0}, {PWM, 1}, {GPIO, 2}} },
	/* GPIO18 */ { 3, {{GPIO, 0}, {PWM, 1}, {UART, 2}} },
	/* GPIO19 */ { 3, {{GPIO, 0}, {PWM, 1}, {UART, 2}} },
	/* GPIO20 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO21 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO22 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO23 */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/* GPIO24 */ { 3, {{GPIO, 0}, {PWM, 1}, {I2C, 2}} },
	/* GPIO25 */ { 3, {{GPIO, 0}, {PWM, 1}, {I2C, 2}} },
	/* GPIO26 */ { 3, {{SPI, 0}, {PWM, 1}, {GPIO, 2}} },
	/* GPIO27 */ { 3, {{SPI, 0}, {PWM, 1}, {GPIO, 2}} },
	/* GPIO28 */ { 2, {{SPI, 0}, {GPIO, 2}} },
	/* GPIO29 */ { 2, {{SPI, 0}, {GPIO, 2}} },
	/* GPIO30 */ { 2, {{I2C, 0}, {GPIO, 2}} },
	/* GPIO31 */ { 2, {{I2C, 0}, {GPIO, 2}} },
}};

_PinMuxUsageStat PinMuxUsageStat = {{
	// GPIO0 ~ GPIO15
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
	// GPIO16 ~ GPIO31
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
}};

int pinMuxSet(GpioPin pin, PinFunction pin_function)
{
	if (!pinSupportPinMux(pin))
		return PINMUX_UNSUPPORTED_PIN;

	const PinMuxInfo* pin_info = &(PinMuxInfoList.pins[pin]);
	const PinMuxSource* source_pin = pinSourceOfFunction(pin_info, pin_function);

	if (source_pin == NULL)
		return PINMUX_UNSUPPORTED_PIN_FUNCTION;

	// This pin is supported, then config pinmux to the pin function
	PinMuxUsageStat.pins[pin] = pin_function;
	if (PINCTRL_REG(pin) == 0) {
		AE250_SMU->PINMUX_CTRL0 &= ~(0x3 << PINCTRL_BIT(pin));
		AE250_SMU->PINMUX_CTRL0 |= (source_pin->source_id << PINCTRL_BIT(pin));
	}
	else if (PINCTRL_REG(pin) == 1) {
		AE250_SMU->PINMUX_CTRL1 &= ~(0x3 << PINCTRL_BIT(pin));
		AE250_SMU->PINMUX_CTRL1 |= (source_pin->source_id << PINCTRL_BIT(pin));
	}

	return 0;
}

// Only reset the software flag in PinMuxUsageStat, setting the hardware at next pinMuxSet
int pinMuxReset(uint8_t pinindex, PinFunction pin_function)
{
	if (!pinSupportPinMux(pinindex))
		return PINMUX_UNSUPPORTED_PIN;

	const PinMuxInfo* pin_info = &(PinMuxInfoList.pins[pinindex]);
	const PinMuxSource* source_pin = pinSourceOfFunction(pin_info, pin_function);

	if (source_pin == NULL)
		return PINMUX_UNSUPPORTED_PIN_FUNCTION;

	// This pin is supported, then config pinmux to the pin function
	PinMuxUsageStat.pins[pinindex] = UNUSED;

	return 0;
}

/* Mapping between peripheral and pins */
/* PWM */
PwmIpCh pin_to_pwm[GPIO_PIN_NUM] = {
	// GPIO0 ~ GPIO11
	{NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP},
	{NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP},
	{NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP},

	// GPIO12 ~ GPIO15
	{2, 0}, {2, 1}, {2, 2}, {2, 3},
	// GPIO16 ~ GPIO31
	{3, 0}, {3, 1}, {3, 2}, {3, 3},
	{4, 0}, {4, 1}, {4, 2}, {4, 3},
	{5, 0}, {5, 1}, {5, 2}, {5, 3},
	{NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP}, {NO_PWM_IP},
};

GpioPin pwm_to_pin[PWM_IP_NUM+1][PWM_IP_CHANNEL_NUM] = {
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
	{12, 13, 14, 15}, /* PWM2 */
	{16, 17, 18, 19}, /* PWM3 */
	{20, 21, 22, 23}, /* PWM4 */
	{24, 25, 26, 27}, /* PWM5 */
};

PwmIpCh pinToPwmChannel(GpioPin pin){
	if (pin >= GPIO_PIN_NUM){
		PwmIpCh pwm = {NO_PWM_IP};
		return pwm;
	}

	return pin_to_pwm[pin];
}

GpioPin pwmChannelToPin(uint8_t ip_num, uint8_t ch_num){
	if ((ip_num == 0) || (ip_num > PWM_IP_NUM)) // 1 ~ PWM_IP_NUM
		return NOT_GPIO_PIN;
	if (ch_num >= PWM_IP_CHANNEL_NUM) // 0 ~ PWM_IP_CHANNEL_NUM - 1
		return NOT_GPIO_PIN;

	return pwm_to_pin[ip_num][ch_num];
}

/* SPI */
SpiPins spi_to_pin[SPI_IP_NUM+1] = {
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
	{26, 29, 27, 28}, /* SPI3 */
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
};

SpiPins spiIpToPins(uint8_t ip_num) {
	if ((ip_num > SPI_IP_NUM) || (ip_num == 0)) {
		SpiPins no_spi = {NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN};
		return no_spi;
	}

	return spi_to_pin[ip_num];
}

/* I2C */
I2cPins i2c_to_pin[I2C_IP_NUM+1] = {
	{NOT_GPIO_PIN, NOT_GPIO_PIN},
	{30, 31}, /* I2C1 */
	{24, 25}, /* I2C2 */
};

I2cPins i2cIpToPins(uint8_t ip_num) {
	if ((ip_num > I2C_IP_NUM) || (ip_num == 0)) {
		I2cPins no_i2c = {NOT_GPIO_PIN, NOT_GPIO_PIN};
		return no_i2c;
	}

	return i2c_to_pin[ip_num];
}
