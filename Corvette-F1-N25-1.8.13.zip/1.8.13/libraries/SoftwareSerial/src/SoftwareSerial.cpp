/*

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

The latest version of this library can always be found at
http://arduiniana.org.
*/

//
// Includes
//
#include "ae250.h"
#include <Arduino.h>
#include <SoftwareSerial.h>

//
// Statics
//
SoftwareSerial *SoftwareSerial::active_object = 0;
uint8_t SoftwareSerial::_receive_buffer[_SS_MAX_RX_BUFF];
volatile uint8_t SoftwareSerial::_receive_buffer_tail = 0;
volatile uint8_t SoftwareSerial::_receive_buffer_head = 0;

//
// Private methods
//

/* static */
// There approximately 30 cycles for tunedDelay instructions
// tunedDelay only work if delay_cycle larger than 30 cycles
inline void SoftwareSerial::tunedDelay(uint32_t delay_cycle) {
  if (delay_cycle > 30) {
    uint64_t timeout = AE250_PLMT->MTIME + delay_cycle - 30;
    while(AE250_PLMT->MTIME < timeout) {;}
  }
}

// This function sets the current object as the "listening"
// one and returns true if it replaces another
bool SoftwareSerial::listen()
{
  if (!_rx_delay_stopbit)
    return false;

  if (active_object != this)
  {
    if (active_object)
      active_object->stopListening();

    _buffer_overflow = false;
    _receive_buffer_head = _receive_buffer_tail = 0;
    active_object = this;

    setRxIntMsk(true);
    return true;
  }

  return false;
}

// Stop listening. Returns true if we were actually listening.
bool SoftwareSerial::stopListening()
{
  if (active_object == this)
  {
    setRxIntMsk(false);
    active_object = NULL;
    return true;
  }
  return false;
}

//
// The receive routine called by the interrupt handler
//
void SoftwareSerial::recv()
{
  uint8_t d = 0;
  volatile uint64_t sample_time, now_time;
  // If RX line is high, then we don't see any start bit
  // so interrupt is probably not for us
  if (_inverse_logic ? rx_pin_read() : !rx_pin_read())
  {
    // Disable further interrupts during reception, this prevents
    // triggering another interrupt directly after we return, which can
    // cause problems at higher baudrates.
    setRxIntMsk(false);
    // Wait approximately 1/2 of a bit width to "center" the sample
    tunedDelay(_rx_delay_centering);
    now_time = AE250_PLMT->MTIME;
    sample_time = now_time + _rx_delay;

    // Read each of the 8 bits
    for (uint8_t i=0; i < 8; i++)
    {
      now_time = AE250_PLMT->MTIME;
      _rx_delay_intrabit = subtract_cap(sample_time, (0xCE + now_time));
      tunedDelay(_rx_delay_intrabit);
      sample_time = sample_time + _rx_delay;
      d >>= 1;

      if (rx_pin_read()){
        d |= 0x80;
      }
    }

    if (_inverse_logic)
      d = ~d;

    // if buffer full, set the overflow flag and return
    uint8_t next = (_receive_buffer_tail + 1) % _SS_MAX_RX_BUFF;
    if (next != _receive_buffer_head)
    {
      // save new data in buffer: tail points to where byte goes
      _receive_buffer[_receive_buffer_tail] = d; // save new byte
      _receive_buffer_tail = next;
    }
    else
    {
      _buffer_overflow = true;
    }

    // skip the stop bit
    now_time = AE250_PLMT->MTIME;
    _rx_delay_stopbit = subtract_cap(sample_time, (0xDE + now_time));
    tunedDelay(_rx_delay_stopbit);
    // Re-enable interrupts when we're sure to be inside the stop bit
    setRxIntMsk(true);
  }
}

uint8_t SoftwareSerial::rx_pin_read()
{
  return digitalRead(_receivePin);
}

//
// Interrupt handling
//

/* static */
inline void SoftwareSerial::handle_interrupt()
{
  if (active_object)
  {
    active_object->recv();
  }
}

//
// Constructor
//
SoftwareSerial::SoftwareSerial(uint8_t receivePin, uint8_t transmitPin, bool inverse_logic /* = false */) :
  _rx_delay_centering(0),
  _rx_delay_intrabit(0),
  _rx_delay_stopbit(0),
  _tx_delay(0),
  _buffer_overflow(false),
  _inverse_logic(inverse_logic)
{
  setTX(transmitPin);
  setRX(receivePin);
}

//
// Destructor
//
SoftwareSerial::~SoftwareSerial()
{
  end();
}

void SoftwareSerial::setTX(uint8_t tx)
{
  // First write, then set output. If we do this the other way around,
  // the pin would be output low for a short while before switching to
  // output high. Now, it is input with pullup for a short while, which
  // is fine. With inverse logic, either order is fine.
  pinMode(tx, OUTPUT);
  digitalWrite(tx, _inverse_logic ? LOW : HIGH);
  _transmitPin = tx;
}

void SoftwareSerial::setRX(uint8_t rx)
{
  pinMode(rx, INPUT);
  if (!_inverse_logic)
    digitalWrite(rx, HIGH);  // pullup for normal logic!
  _receivePin = rx;
}

uint32_t SoftwareSerial::subtract_cap(uint32_t num, uint32_t sub) {
  if (num > sub)
    return num - sub;
  else
    return 1;
}

//
// Public methods
//

void SoftwareSerial::begin(long speed)
{
  _rx_delay_centering = _rx_delay_intrabit = _rx_delay_stopbit = _tx_delay = 0;

  uint32_t bit_delay = (CPUFREQ / speed);

  // When the start bit occurs, there are approximately 570 (0x23A) cycles
  // before disable GPIO ISR in non vector mode ( 11 cycles HW IRQ & other instruction latency )
  // there are approximately 490 (0x1EA) cycles in vector mode

  // There are approximately 206 cycles in each loop iteration

  // There are approximately 222 cycles from the last bit read to the middle of
  // stopbit delay and enable GPIO ISR

  _tx_delay = bit_delay;
  _rx_delay = bit_delay;
  _rx_delay_centering = subtract_cap(bit_delay/2, 0x23A);
  _rx_delay_intrabit = bit_delay;
  _rx_delay_stopbit = bit_delay;

  attachInterrupt(_receivePin, handle_interrupt, CHANGE);

  tunedDelay(_tx_delay); // if we were low this establishes the end

  listen();
}

void SoftwareSerial::setRxIntMsk(bool enable)
{
    if (enable)
      attachInterrupt(_receivePin, handle_interrupt, CHANGE);
    else
      detachInterrupt(_receivePin);
}

void SoftwareSerial::end()
{
  stopListening();
}


// Read data from buffer
int SoftwareSerial::read()
{
  if (!isListening())
    return -1;

  // Empty buffer?
  if (_receive_buffer_head == _receive_buffer_tail)
    return -1;

  // Read from "head"
  uint8_t d = _receive_buffer[_receive_buffer_head]; // grab next byte
  _receive_buffer_head = (_receive_buffer_head + 1) % _SS_MAX_RX_BUFF;
  return d;
}

int SoftwareSerial::available()
{
  if (!isListening())
    return 0;

  return (_receive_buffer_tail + _SS_MAX_RX_BUFF - _receive_buffer_head) % _SS_MAX_RX_BUFF;
}

size_t SoftwareSerial::write(uint8_t b)
{
  // there are approximately 175 cycles to Output digital pins each time
  // 275 cycles to turn interrupts on after set stop bit
  uint32_t start_delay = subtract_cap(_tx_delay, 0xAF);
  uint32_t  data_delay = subtract_cap(_tx_delay, 0xAF);
  uint32_t  stop_delay = subtract_cap(_tx_delay, 0X113);

  if (_tx_delay == 0) {
    setWriteError();
    return 0;
  }

  // By declaring these as local variables, the compiler will put them
  // in registers _before_ disabling interrupts and entering the
  // critical timing sections below, which makes it a lot easier to
  // verify the cycle timings
  bool inv = _inverse_logic;

  if (inv)
    b = ~b;

  detachInterrupt(_receivePin);  // turn off interrupts for a clean txmit

  // Write the start bit
  if (inv)
    digitalWrite(_transmitPin, HIGH);
  else
    digitalWrite(_transmitPin, LOW);
  tunedDelay(start_delay);

  // Write each of the 8 bits
  for (uint8_t i = 8; i > 0; --i)
  {
    if (b & 1) // choose bit
      digitalWrite(_transmitPin, HIGH);
    else
      digitalWrite(_transmitPin, LOW);
    tunedDelay(data_delay);
    b >>= 1;
  }

  // restore pin to natural state
  if (inv)
    digitalWrite(_transmitPin, LOW);
  else
    digitalWrite(_transmitPin, HIGH);

  attachInterrupt(_receivePin, handle_interrupt, CHANGE); // turn interrupts back on
  tunedDelay(stop_delay);

  return 1;
}

void SoftwareSerial::flush()
{
  // There is no tx buffering, simply return
}

int SoftwareSerial::peek()
{
  if (!isListening())
    return -1;

  // Empty buffer?
  if (_receive_buffer_head == _receive_buffer_tail)
    return -1;

  // Read from "head"
  return _receive_buffer[_receive_buffer_head];
}
