#ifndef _RTC_H_INCLUDED
#define _RTC_H_INCLUDED

#include "Arduino.h"
#include "rtc_drv.h"
#include "arduino_pin.h"

class RTCClass;

class RTCClass {
	private:
		RTC_Driver* rtc;

	public:
		RTCClass(RTC_Driver* rtc_drv) {
			this->rtc = rtc_drv;
		}

		// Initializes the RTC
		void setalarmcallbackfunc(void (*f)());
		void startcounting();
		void settime(uint32_t, uint32_t, uint32_t, uint32_t);
		void setalarmtime(uint32_t, uint32_t, uint32_t);
		uint32_t getday();
		uint32_t gethours();
		uint32_t getminutes();
		uint32_t getseconds();
		void attachalarmint();
		void detachalarmint();
		void clearalarmst();
};

extern RTCClass RTC;

#endif
