
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "int.h"
#include "RTC.h"
#include "platform.h"

RTCClass RTC(&RTC_DRV);

void (*callback)();

extern "C" {
	void rtc_alarm_irq_handler() {
		void (*intr)();
		intr = callback;
		intr();
	}
}

void RTCClass::setalarmcallbackfunc(void (*func)())
{
	callback = func;
}

void RTCClass::startcounting()
{
	rtc_startcounting(rtc);
}

void RTCClass::settime(uint32_t day, uint32_t hour, uint32_t min, uint32_t sec)
{
	rtc_settime(rtc, day, hour, min, sec);
}

void RTCClass::setalarmtime(uint32_t hour, uint32_t min, uint32_t sec)
{
	rtc_setalarmtime(rtc, hour, min, sec);
}

uint32_t RTCClass::getday()
{
	return rtc_getday(rtc);
}

uint32_t RTCClass::gethours()
{
	return rtc_gethours(rtc);
}

uint32_t RTCClass::getminutes()
{
	return rtc_getminutes(rtc);
}

uint32_t RTCClass::getseconds()
{
	return rtc_getseconds(rtc);
}

void RTCClass::attachalarmint()
{
	rtc_attachalarmint(rtc);
}

void RTCClass::detachalarmint()
{
	rtc_detachalarmint(rtc);
}

void RTCClass::clearalarmst()
{
	rtc_clearalarmst(rtc);
}
