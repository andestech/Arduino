#include "SPI.h"

#include "gpio.h"

// SPIClass SPI(&SPI_DRV2, true);
SPIClass SPI(&SPI_DRV3, false);
SPIClass SPI4(&SPI_DRV4, false);

static bool pinMuxCheckAndSet(GpioPin pin, PinFunction pin_function)
{
	int pin_usage = pinMuxCheckUsage(pin);

	if (pin_usage == PINMUX_FUNC_UNUSED) {
		int err = pinMuxSet(pin, pin_function);
		if (err)
			return false;
	}
	else if (pin_usage != pin_function) {
		// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
		return false;
	}

	return true;
}

static bool spiSetPinMux(SPI_Driver* spi)
{
	SpiPins spi_pins = spiIpToPins(spi->ip_num);

	if (pinSupportPinMux(spi_pins.sclk)) {
		if (!pinMuxCheckAndSet(spi_pins.sclk, PINMUX_FUNC_SPI)) {
			return false;
		}
	}
	if (pinSupportPinMux(spi_pins.mosi)) {
		if (!pinMuxCheckAndSet(spi_pins.mosi, PINMUX_FUNC_SPI)) {
			return false;
		}
	}
	if (pinSupportPinMux(spi_pins.miso)) {
		if (!pinMuxCheckAndSet(spi_pins.miso, PINMUX_FUNC_SPI)) {
			return false;
		}
	}

	return true;
}

void SPIClass::begin()
{
	// Set Pinmux
	if (this->may_need_pinmux) {
		spiSetPinMux(spi);
	}

	// Set GPIO pull-up resistor to SPI CS pin. (this behavior is copied from ArduinoCore-avr)
	GPIO_SetInputType(arduinoPinToGpioPin(SS), GPIO_PULL_UP);

	SPI_Init(spi);

	// SPI use default config if SPI library user doesn't call beginTransaction().
	SPI_SetBitOrder(spi, SPISettings::DEFAULT_BIT_ORDER);
	SPI_SetClockDivider(spi, SPISettings::clockToDivider(SPISettings::DEFAULT_CLK_RATE));
	SPI_SetDataMode(spi, SPISettings::DEFAULT_DATA_MODE);
}

void SPIClass::end()
{
	SPI_DeInit(spi);
}
