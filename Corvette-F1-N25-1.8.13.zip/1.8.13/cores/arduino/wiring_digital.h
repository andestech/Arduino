#ifndef WIRING_DIGITAL_H
#define WIRING_DIGITAL_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#define HIGH    1
#define LOW     0

typedef enum{
	INPUT,
	OUTPUT,
	INPUT_PULLUP
}IO_TYPE;

/* Digital I/O */
void pinMode( int pin, IO_TYPE mode );
void digitalWrite( int pin, int value );
int digitalRead(int pin);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_DIGITAL_H
