/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "wiring_pulse.h"
#include "wiring.h"
#include "wiring_digital.h"
#include "arduino_pin.h"

#include "pinmux.h"

/* It's a dummy function.
 *
 * There are some problems in this implementation of pulseIn(), please use pulseInLong() instead of it.
 * Just leave it for backward-compatibility.
 */
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout)
{
    uint8_t status = 0;
    uint8_t value = 0;
    uint32_t timeout_tick = 0;
    uint32_t start_tick = 0;
    
    if(state)
        status = 1;
    else
        status = 0;

    timeout_tick = micros();
    while(1)
    {
        value = digitalRead(pin);
        if(value == status)
        {
            start_tick = micros();
            break;
        }

        if((micros() - timeout_tick) > timeout)
            return 0;
    }
    
    while(1)
    {
        value = digitalRead(pin);
        if(value != status)
            return (micros() - start_tick);

        if((micros() - timeout_tick) > timeout)
            return 0;
    }
}

/* Measures the length (in microseconds) of a pulse on the pin; state is HIGH
 * or LOW, the type of pulse to measure.  Works on pulses from 2-3 microseconds
 * to 3 minutes in length, but must be called at least a few dozen microseconds
 * before the start of the pulse.
 *
 * ATTENTION:
 * this function relies on micros() so cannot be used in noInterrupt() context
 */
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout)
{
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);

	if (pinSupportPinMux(gpio_pin))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(gpio_pin, PINMUX_FUNC_GPIO);
			if (err)
				return 0; // pulseInLong() doesn't have error code for pinmux, so reuse timeout error currently.
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return 0; // pulseInLong() doesn't have error code for pinmux, so reuse timeout error currently.
		}
	}

	// This pin is used by GPIO in PinMux, or this pin doesn't support PinMux.
	unsigned long start_micros = micros();

	// wait for any previous pulse to end
	while (digitalRead(pin) == state)
	{
		if (micros() - start_micros > timeout)
			return 0;
	}

	// wait for the pulse to start
	while (digitalRead(pin) != state)
	{
		if (micros() - start_micros > timeout)
			return 0;
	}

	unsigned long start = micros();
	// wait for the pulse to stop
	while (digitalRead(pin) == state)
	{
		if (micros() - start_micros > timeout)
			return 0;
	}
	return micros() - start;
}
