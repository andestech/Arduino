/*
  Copyright (c) 2011-2012 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef WINTERRUPT_H
#define WINTERRUPT_H

#include "WInterrupts.h"
#include "wiring_digital.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "gpio.h"

static int first_attach_func =0;

struct gpio_struct
{
	void (*interrupt_func)(void);
};

struct gpio_struct gpio_table[GPIO_NUM];

void GPIO_Callback(u32 int_status_bit)
{
	uint32_t int_pin;
	int i;
	void (*int_func)(void);
	int_pin = 0xFF;

	for ( i = 0; i < GPIO_NUM ; i++) {
		if (((int_status_bit >> i) & 0x1) == 1) {
			int_pin = i;
			break;
		}
	}

	if (int_pin < 32) {
		/* Execute interrupt function */
		int_func = gpio_table[int_pin].interrupt_func;
		int_func();
	}
}

void attachInterrupt(uint32_t pin, void (*callback)(void), uint32_t mode)
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);

	if (pinSupportPinMux(gpio_pin))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(gpio_pin, PINMUX_FUNC_GPIO);
			if (err)
				return;
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}
	// This pin is used by GPIO in pin mux, or this pin doesn't support pin mux.

	/* Setup callback function at first time */
	if (first_attach_func == 0){
		GPIO_RegisterCallback(GPIO_Callback);
		GPIO_IsrInit();
		first_attach_func += 1;
	}

	/* Register Interrupt callback function */
	gpio_table[gpio_pin].interrupt_func = callback;

	/* Enable GPIO interrupt */
	if (mode == FALLING) {
		GPIO_EnableInt(gpio_pin,GPIO_INTRMODE_NEGATIVE_EDGE);
	} else if (mode == RISING) {
		GPIO_EnableInt(gpio_pin,GPIO_INTRMODE_POSITIVE_EDGE);
	} else if (mode == CHANGE) {
		GPIO_EnableInt(gpio_pin,GPIO_INTRMODE_DUAL_EDGE);
	}
}

void detachInterrupt(uint32_t pin)
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);
	/* Disable Interrupt */
	GPIO_DisableInt(gpio_pin);
}

#endif //WINTERRUPT_H
