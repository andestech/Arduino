#include "HardwareSerial.h"
#include "arduino_pin.h"
#include "pinmux.h"

// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
void serialEvent() __attribute__((weak));
void serialEvent1() __attribute__((weak));

HardwareSerial::HardwareSerial(UART_RegDef *pUartConsole) {
	UartConsole = pUartConsole;
}

void HardwareSerial::begin(uint32_t baud)
{
	begin(baud, SERIAL_8N1);
}

void HardwareSerial::begin(uint32_t baud,uint32_t config)
{
	u8 UART_DRV_DATABITS = (u8) ((config >> 8) & 0xf);
	u8 UART_DRV_STOPBITS = (u8) (config & 0xf);
	u8 UART_DRV_PARITY = (u8) ((config >> 4) & 0xf);
	UART_DATA_t tUartData ={baud, \
		UART_DRV_DATABITS,UART_DRV_STOPBITS,UART_DRV_PARITY};
	UART_Init(UartConsole,&tUartData);
	UART_IsrInit(UartConsole);

	// PinMux config
	if (UartConsole == DEV_UART1) {
		GpioPin rx_pin = arduinoPinToGpioPin(D2);
		GpioPin tx_pin = arduinoPinToGpioPin(D3);

		if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UNUSED)
			pinMuxSet(rx_pin, PINMUX_FUNC_UART);
		if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UNUSED)
			pinMuxSet(tx_pin, PINMUX_FUNC_UART);
	}
	else if (UartConsole == DEV_UART2) {
		GpioPin rx_pin = arduinoPinToGpioPin(D0);
		GpioPin tx_pin = arduinoPinToGpioPin(D1);

		if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UNUSED)
			pinMuxSet(rx_pin, PINMUX_FUNC_UART);
		if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UNUSED)
			pinMuxSet(tx_pin, PINMUX_FUNC_UART);
	}

	begin_flag = 1;
}

void HardwareSerial::end()
{
	if(!begin_flag)
		return;

	begin_flag = 0;

	UART_DeInit(UartConsole);

	GpioPin rx_pin = arduinoPinToGpioPin(D0);
	GpioPin tx_pin = arduinoPinToGpioPin(D1);

	// Reset the software flag for the next pin application
	if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UART)
		pinMuxReset(rx_pin, PINMUX_FUNC_UART);
	if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UART)
		pinMuxReset(tx_pin, PINMUX_FUNC_UART);
}

int HardwareSerial::available(void)
{
	if(!begin_flag)
		return 0;

	return UART_IsDataAvailable(UartConsole);
}

int HardwareSerial::read(void)
{
	if(!begin_flag)
		return -1;

	if(available())
		return (int)UART_ReadByte(UartConsole);
	else
		return -1;
}

size_t HardwareSerial::write(uint8_t c)
{
	if(!begin_flag)
		return 1;

	UART_WriteByte(UartConsole,c);
	return 1;
}

size_t HardwareSerial::write(const char *buffer, size_t size) {

	size_t len = size;

	if(!begin_flag)
		return size;

	while(len--)
		UART_WriteByte(UartConsole,*buffer++);

	return size;
}

int HardwareSerial::peek(void)
{
	if(!begin_flag)
		return -1;

	if(available())
		return (int)UART_PeekByte(UartConsole);
	else
		return -1;
}
void HardwareSerial::flush()
{
	if(!begin_flag)
		return;

	UART_Flush(UartConsole);
}

int HardwareSerial::availableForWrite() {

	if(!begin_flag)
		return 0;

	return UART_BytesAvailableForWrite(UartConsole);
}

void serialEventRun(void)
{
	if (Serial && serialEvent && Serial.available()) serialEvent();
	if (Serial1 && serialEvent1 && Serial1.available()) serialEvent1();
}

void HardwareSerial::insertRcvData(char* buffer, unsigned int len) {
	insertStrToRcvQueue(buffer, len);
}

void HardwareSerial::insertSendData(char* buffer, unsigned int len) {
	insertStrToSendQueue(buffer, len);
}

HardwareSerial Serial(DEV_UART2);
HardwareSerial Serial1(DEV_UART1);
