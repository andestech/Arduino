#ifndef WINTERRUPTS_H
#define WINTERRUPTS_H

#include <inttypes.h>

/* Interrupt mode */
#define FALLING 0
#define RISING  1
#define CHANGE  2

void attachInterrupt(uint32_t pin, void (*callback)(void), uint32_t mode);
void detachInterrupt(uint32_t pin);

#endif //WINTERRUPTS_H

