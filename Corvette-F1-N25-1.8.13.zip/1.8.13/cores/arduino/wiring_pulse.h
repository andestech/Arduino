#ifndef WIRING_PULSE_H
#define WIRING_PULSE_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "typedef.h"

// 1. C/C++ shared declarations

#ifdef __cplusplus
// 2. C++ only declarations
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout = 1000000L); // not implemented yet.
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout = 1000000L);

#else
// 3. C only declarations
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout); // not implemented yet.
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout);

#endif // __cplusplus

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_PULSE_H
