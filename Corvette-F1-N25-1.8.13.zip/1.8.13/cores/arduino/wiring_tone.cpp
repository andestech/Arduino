#include "Arduino.h"
#include "wiring.h"
#include "wiring_tone.h"
#include "wiring_digital.h"
#include "arduino_pin.h"

#include "pwm.h"
#include "pinmux.h"

void toneTimerInit()
{
	TIMER_Init(TIMER2, TIMER_32, 0, 0);
	TIMER_EnableInt(TIMER2);
}

#define MAX_TONE_CONCURRENT 16

typedef struct {
	GpioPin pin;
	uint32_t timer_overflow;
	uint32_t tick;
} ToneReq;

struct _ToneReqList {
	int request_num;
	int pend_request_num;
	ToneReq requests[MAX_TONE_CONCURRENT];
	ToneReq pend_requests[MAX_TONE_CONCURRENT]; // Pending Requests: requests occur after timer overflow.
	bool pin_has_request[GPIO_PIN_NUM];

	_ToneReqList() {
		this->request_num = 0;
		this->pend_request_num = 0;
		for (int i = 0; i < GPIO_PIN_NUM; ++i) {
			pin_has_request[i] = false;
		}
	}
};

struct _ToneReqList ToneReqList;

static void toneReqDel(GpioPin pin);

/*
 * Note: toneReq{Add*|Del*|Remove*}() functions should be called when disabling IRQ.
 */

static void toneReqAdd(GpioPin pin, uint32_t tick)
{
	if (ToneReqList.request_num >= MAX_TONE_CONCURRENT)
		return;

	if (ToneReqList.pin_has_request[pin]) {
		toneReqDel(pin);
		ToneReqList.pin_has_request[pin] = false;
	}

	int num = ToneReqList.request_num;

	ToneReqList.requests[num].pin = pin;
	ToneReqList.requests[num].timer_overflow = 0;
	ToneReqList.requests[num].tick = tick;
	ToneReqList.request_num++;
	ToneReqList.pin_has_request[pin] = true;
}

static void tonePendReqAdd(GpioPin pin, uint32_t timer_overflow, uint32_t tick)
{
	if (ToneReqList.pend_request_num >= MAX_TONE_CONCURRENT)
		return;

	if (ToneReqList.pin_has_request[pin]) {
		toneReqDel(pin);
	}

	int num = ToneReqList.pend_request_num;

	ToneReqList.pend_requests[num].pin = pin;
	ToneReqList.pend_requests[num].timer_overflow = timer_overflow;
	ToneReqList.pend_requests[num].tick = tick;
	ToneReqList.pend_request_num++;
	ToneReqList.pin_has_request[pin] = true;
}

static void toneReqRemoveIndex(int index)
{
	int pin = ToneReqList.requests[index].pin;

	for (int i = index; i < (ToneReqList.request_num-1); ++i) {
		ToneReqList.requests[i] = ToneReqList.requests[i+1];
	}
	ToneReqList.request_num--;
	ToneReqList.pin_has_request[pin] = false;
}

static void tonePendReqRemoveIndex(int index)
{
	int pin = ToneReqList.pend_requests[index].pin;

	for (int i = index; i < (ToneReqList.request_num-1); ++i) {
		ToneReqList.pend_requests[i] = ToneReqList.pend_requests[i+1];
	}
	ToneReqList.pend_request_num--;
	ToneReqList.pin_has_request[pin] = false;
}

/*
 * toneRelDel(): Delete request or pending request with this pin
 */
static void toneReqDel(GpioPin pin)
{
	if (ToneReqList.request_num == 0)
		return;

	if (!ToneReqList.pin_has_request[pin])
		return;

	bool req_deleted = false;

	for (int i = 0; i < ToneReqList.request_num; ++i) {
		if (ToneReqList.requests[i].pin == pin) {
			toneReqRemoveIndex(i);

			req_deleted = true;
			break;
		}
	}

	if (!req_deleted) {
		for (int i = 0; i < ToneReqList.pend_request_num; ++i) {
			if (ToneReqList.pend_requests[i].pin == pin) {
				tonePendReqRemoveIndex(i);

				break;
			}
		}
	}

}

/*
 * toneReqDelAll(): Delete all request (not including pending request)
 */
static void toneReqDelAll()
{
	for (int i = 0; i < ToneReqList.request_num; ++i) {
		GpioPin pin = ToneReqList.requests[i].pin;
		ToneReqList.pin_has_request[pin] = false;
	}

	ToneReqList.request_num = 0;
}

/*
 * Note:
 *   Timer1 and Timer2 ISR doesn't need to disable IRQ for critical sections, because they use same HW Interrupt.
 *   It means that Timer1/Timer2 ISR couldn't preempt each other.
 *
 *   If we modify Timer's HW support, we may need to add the protection to critical sections.
 */

void toneTimer1Overflow()
{
	if (ToneReqList.request_num != 0) {
		// Invalid condition, there should be no request if Timer1 occurs overflow.
		// Clear all requests.
		TIMER_Stop(TIMER2);

		for (int i = 0; i < ToneReqList.request_num; ++i) {
			PwmIpCh pwm = pinToPwmChannel(ToneReqList.requests[i].pin);
			PWM_Stop(pwm.ip_num, pwm.ch_num);
		}

		toneReqDelAll();
	}

	if (ToneReqList.pend_request_num != 0) {
		// Decrements all pending request's timer_overflow, and move requests before next timer_overflow to non-pending request.
		for (int i = 0; i < ToneReqList.pend_request_num; ++i) {
			ToneReqList.pend_requests[i].timer_overflow--;

			if (ToneReqList.pend_requests[i].timer_overflow == 0) {
				ToneReq request = ToneReqList.pend_requests[i];

				toneReqDel(ToneReqList.pend_requests[i].pin);
				toneReqAdd(request.pin, request.tick);
			}
		}
	}

	// update timer2
	if (ToneReqList.request_num != 0) {
		ToneReq next_req = ToneReqList.requests[0];
		uint32_t current_tick = TIMER_Read(TIMER1);

		TIMER_Stop(TIMER2);
		if ((next_req.tick - current_tick) < 0) {
			TIMER_SetPeriod(TIMER2, 1);
		}
		else {
			TIMER_SetPeriod(TIMER2, next_req.tick - current_tick);
		}
		TIMER_Start(TIMER2);
	}
}

void timer2_irq_handler()
{
	// Disable timer by default.
	TIMER_Stop(TIMER2);

	// No request.
	if (ToneReqList.request_num == 0)
		return;

	ToneReq timeout_req = ToneReqList.requests[0];

	// disable tone()'s PWM.
	PwmIpCh pwm = pinToPwmChannel(timeout_req.pin);
	PWM_Stop(pwm.ip_num, pwm.ch_num);

	// remove from request list
	toneReqDel(timeout_req.pin);

	// For each timeout requests, disable PWM + remove from request list
	while (ToneReqList.request_num != 0) {
		ToneReq next_req = ToneReqList.requests[0];
		uint32_t current_tick = TIMER_Read(TIMER1);

		if (next_req.tick < current_tick) {
			PwmIpCh pwm = pinToPwmChannel(next_req.pin);
			PWM_Stop(pwm.ip_num, pwm.ch_num);

			toneReqDel(next_req.pin);
		}
		else {
			// No timeout requests.
			break;
		}
	}

	// update timer2
	if (ToneReqList.request_num != 0) {
		ToneReq next_req = ToneReqList.requests[0];
		uint32_t current_tick = TIMER_Read(TIMER1);

		if (next_req.tick < current_tick) {
			TIMER_SetPeriod(TIMER2, 1);
		}
		else {
			TIMER_SetPeriod(TIMER2, next_req.tick - current_tick);
		}
		TIMER_Start(TIMER2);
	}
}

static void addToneReqDuration(GpioPin pin, unsigned long duration)
{
	uint32_t current_tick = TIMER_Read(TIMER1);

	uint64_t duration_tick = ((uint64_t)duration) * PCLKFREQ / 1000 + current_tick;
	uint32_t timer_overflow = duration_tick / TIMER_OVERFLOW_TICK;
	duration_tick = duration_tick % TIMER_OVERFLOW_TICK;

	if (timer_overflow != 0) {
		// tone() is disabled after next PIT1 overflow
		noInterrupts();
		tonePendReqAdd(pin, timer_overflow, duration_tick);
		interrupts();
		return;
	}

	// tone() is disabled before PIT1 overflow
	noInterrupts();

	if (ToneReqList.request_num == 0) {
		toneReqAdd(pin, duration_tick);

		TIMER_SetPeriod(TIMER2, duration_tick - current_tick);
		TIMER_Start(TIMER2);

		interrupts();
		return;
	}

	ToneReq next_req = ToneReqList.requests[0];

	if (duration_tick < next_req.tick) {
		toneReqAdd(pin, duration_tick);

		TIMER_Stop(TIMER2);
		TIMER_SetPeriod(TIMER2, duration_tick - current_tick);
		TIMER_Start(TIMER2);
	}
	else {
		toneReqAdd(pin, duration_tick);
	}

	interrupts();
}

void tone(uint8_t pin, unsigned int frequency, unsigned long duration)
{
	/* Supported frequency range: 1Hz ~ 20MHz(PCLKFREQ/2).
	 *
	 * Arduino Uno's guaranteed frequency range is 31Hz ~ 4MHz.
	 * ref: https://github.com/bhagman/Tone#ugly-details
	 */
	if (frequency == 0)
		return;

	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);

	if (pinSupportPinMux(gpio_pin)) {
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(gpio_pin, PINMUX_FUNC_PWM);
			if (err)
				return;
		}
		else if (pin_usage != PINMUX_FUNC_PWM) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}

	PwmIpCh pwm = pinToPwmChannel(gpio_pin);

	// This pin doesn't support PWM.
	if (pwm.ip_num == NO_PWM_IP)
		return;

	if (!is_pwm_channel_init[pwm.ip_num][pwm.ch_num]) {
		is_pwm_channel_init[pwm.ip_num][pwm.ch_num] = true;
		PWM_Init(pwm.ip_num, pwm.ch_num);
	}

	PWM_Stop(pwm.ip_num, pwm.ch_num);

	uint32_t pwm_period = PCLKFREQ / frequency;
	if (pwm_period > PWM_MAX_PERIOD) {
		pwm_period = RTCFREQ / frequency;

		if (pwm_period > PWM_MAX_PERIOD) {
			// PWM can't supports this frequency.
			// RTCFREQ is larger than PWM_MAX_PERIOD currently, so it doesn't occur.
			return;
		}

		// set PWM clock src = EXT
		if (PWM_GetClockSrc(pwm.ip_num, pwm.ch_num) != PIT_CLKSRC_EXT) {
			PWM_SetClockSrc(pwm.ip_num, pwm.ch_num, PIT_CLKSRC_EXT);
		}
	}
	else {
		// set PWM clock src = APB
		if (PWM_GetClockSrc(pwm.ip_num, pwm.ch_num) != PIT_CLKSRC_APB) {
			PWM_SetClockSrc(pwm.ip_num, pwm.ch_num, PIT_CLKSRC_APB);
		}
	}

	// The precise PWM period is hi_cycle * 2
	// Duty cycle must be 50% accurately.
	uint16_t hi_cycle = pwm_period / 2;
	uint16_t lo_cycle = hi_cycle;
	PWM_SetPeriod(pwm.ip_num, pwm.ch_num, hi_cycle, lo_cycle);

	PWM_Start(pwm.ip_num, pwm.ch_num);

	if (duration != 0) {
		// Turn off PWM in Timer ISR triggered after duration ms.
		addToneReqDuration(gpio_pin, duration);
	}
}

void noTone(uint8_t pin)
{
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);

	if (pinSupportPinMux(gpio_pin)) {
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage != PINMUX_FUNC_PWM)
			return;
	}

	PwmIpCh pwm = pinToPwmChannel(gpio_pin);

	// This pin doesn't support PWM.
	if (pwm.ip_num == NO_PWM_IP)
		return;

	PWM_Stop(pwm.ip_num, pwm.ch_num);

	noInterrupts();

	if (ToneReqList.pin_has_request[pin]) {
		toneReqDel(pin);
	}

	interrupts();
}
