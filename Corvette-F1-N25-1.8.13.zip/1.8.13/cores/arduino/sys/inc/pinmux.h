#ifndef PINMUX_H
#define PINMUX_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include <stdbool.h>
#include "typedef.h"

/* PinMux structure */

/* In F1-AE250, GPIO pin is from 0 to 31 */
typedef uint8_t GpioPin;
#define GPIO_PIN_NUM 32
#define NOT_GPIO_PIN 33

static inline int PINCTRL_REG(GpioPin pin) { return pin / 16; }
static inline int PINCTRL_BIT(GpioPin pin) { return (pin % 16) * 2; }

typedef enum {
	PINMUX_FUNC_UNUSED,
	PINMUX_FUNC_GPIO,
	PINMUX_FUNC_PWM,
	PINMUX_FUNC_UART,
	PINMUX_FUNC_I2C,
	PINMUX_FUNC_SPI
} PinFunction;

typedef struct {
	PinFunction function;
	uint8_t source_id;
} PinMuxSource;

#define PINMUX_MAX_SOURCE 4

typedef struct {
	uint8_t source_num;
	PinMuxSource source_list[PINMUX_MAX_SOURCE];
} PinMuxInfo;

typedef struct {
	PinMuxInfo pins[GPIO_PIN_NUM];
} _PinMuxInfoList;

extern const _PinMuxInfoList PinMuxInfoList;

typedef struct {
	PinFunction pins[GPIO_PIN_NUM];
} _PinMuxUsageStat;

extern _PinMuxUsageStat PinMuxUsageStat;

/* PinMux Error Code */
#define PINMUX_UNSUPPORTED_PIN          -1  /* This pin doesn't support Pin Mux */
#define PINMUX_UNSUPPORTED_PIN_FUNCTION -2  /* Pin Mux of the pin doesn't have this pin function */

/* PinMux APIs */
static inline bool pinSupportPinMux(GpioPin pin)
{
	if (pin >= GPIO_PIN_NUM) return false;

	return PinMuxInfoList.pins[pin].source_num != 0;
}

/*
 * int pinMuxCheckUsage(pin)
 *
 * checking Pin Mux current usage of pin.
 * return: PinFunction or error code
 */
static inline int pinMuxCheckUsage(GpioPin pin)
{
	if (!pinSupportPinMux(pin))
		return PINMUX_UNSUPPORTED_PIN;

	return PinMuxUsageStat.pins[pin];
}

/*
 * int pinMuxSet(pin, pin_function)
 *
 * set Pin Mux function of pin to pin_function
 * return: 0 or error code.
 *
 * Note: Only call this function if this pin isn't used before. (pinMuxCheckUsage())
 */
int pinMuxSet(GpioPin pin, PinFunction pin_function);

/* PinMux APIs (Mapping between peripheral and pins) */

/* PWM */
typedef struct {
	uint8_t ip_num;
	uint8_t ch_num;
} PwmIpCh;
#define NO_PWM_IP 0

#define PWM_IP_NUM 5
#define PWM_IP_CHANNEL_NUM 4

extern PwmIpCh pin_to_pwm[GPIO_PIN_NUM];
extern GpioPin pwm_to_pin[PWM_IP_NUM+1][PWM_IP_CHANNEL_NUM];

PwmIpCh pinToPwmChannel(GpioPin pin);
GpioPin pwmChannelToPin(uint8_t ip_num, uint8_t ch_num);

/* SPI */

typedef struct {
	GpioPin cs;
	GpioPin sclk;
	GpioPin mosi;
	GpioPin miso;
} SpiPins;
#define SPI_IP_NUM 4

extern SpiPins spi_to_pin[SPI_IP_NUM+1];

SpiPins spiIpToPins(uint8_t ip_num);

/* I2C */
typedef struct {
	GpioPin sda;
	GpioPin scl;
} I2cPins;

#define I2C_IP_NUM 2

extern I2cPins i2c_to_pin[I2C_IP_NUM+1];

I2cPins i2cIpToPins(uint8_t ip_num);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //PINMUX_H
