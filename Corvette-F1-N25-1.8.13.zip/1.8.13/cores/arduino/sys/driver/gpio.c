
#include "int.h"
#include "gpio.h"
#include "platform.h"

/***********************************************************************************************
 *   GLOBAL VARIABLES
 ************************************************************************************************/
DRVGPIO_Callback *gGpioCallback;


/***********************************************************************************************
 *   LOCAL FUNCTIONS
 ************************************************************************************************/
//void GPIO_ISR(int unused)
void gpio_irq_handler()
{
	/*Read the GPIO masked interrupt status  to check the gpio pin. */
	int status = DEV_GPIO->INTRSTATUS;

	/*Clear GPIO interrupt status*/
	DEV_GPIO->INTRSTATUS = status;

	if (gGpioCallback)
		gGpioCallback(status);
}

/***********************************************************************************************
 *   GLOBAL FUNCTIONS
 ************************************************************************************************/
void GPIO_IsrInit(void)
{
	INT_IrqEn(IRQ_GPIO_SOURCE, 1);
}

/***********************************************************************************************
 @brief:Set GPIO specified port direction
 @para:
 -u8Idx: Specified GPIO port
 -Dir: GPIO_INPUT/GPIO_OUTPUT
 ***********************************************************************************************/
void GPIO_SetDir(u8 u8Idx, GPIO_TYPE Dir)
{
	if (Dir == GPIO_OUTPUT)
		DEV_GPIO->CHANNELDIR |=(1 << u8Idx);
	else
		DEV_GPIO->CHANNELDIR &=~(1 << u8Idx);
}



void GPIO_SetInputType(u8 u8Idx, GPIO_PULL_TYPE type)
{
	/* Input as pullup mode. */
	if (type == GPIO_PULL_UP){
		DEV_GPIO->PULLEN |=(1 <<u8Idx);
		DEV_GPIO->PULLTYPE &=~(1 <<u8Idx);
	}
}



/***********************************************************************************************
 @brief:Set GPIO specified port output value
 @para:
 -u8Idx: Specified GPIO port
 -Val: HIGH/LOW
 ***********************************************************************************************/
void GPIO_SetOutput(u8 u8Idx, GPIO_STATE Val)
{
	if(Val == GPIO_HIGH)
		//DEV_GPIO->DATAOUT |=(1 <<u8Idx);
		DEV_GPIO->DOUTSET |= (1 <<u8Idx);
	else
		//DEV_GPIO->DATAOUT &= ~(1 <<u8Idx);
		DEV_GPIO->DOUTCLEAR |= (1 <<u8Idx);
}

/***********************************************************************************************
 @brief:Get the pin value from the specified input GPIO pin.
 @para:
 -u8Idx: Specified GPIO port
 @ret:
 -Bit value
 ***********************************************************************************************/
u8 GPIO_GetBit(u8 u8Idx)
{
	return ((DEV_GPIO->DATAIN >> u8Idx) & 0x1);
}


/***********************************************************************************************
 @brief:Enable GPIO specified PIN interrupt
 @para:
 -u8Idx: Specified GPIO port
 -u8Type:Trigger type(GPIO_TRIG_LEVEL/GPIO_TRIG_EDGE)
 -u8Mode:GPIO_FALLING_LOW/GPIO_RISING_HIGH
 ***********************************************************************************************/
void GPIO_EnableInt(u8 u8Idx,u8 u8Mode)
{
	/*	Set interrupt mode	*/
	if(u8Idx < 8){
		DEV_GPIO->INTRMODE0 &= ~(0xf << (u8Idx * 4));
		DEV_GPIO->INTRMODE0 |= u8Mode << (u8Idx * 4);
	}else if(u8Idx < 16){
		DEV_GPIO->INTRMODE1 &= ~(0xf << ((u8Idx-8) * 4));
		DEV_GPIO->INTRMODE1 |= u8Mode << ((u8Idx-8) * 4);
	}else if(u8Idx < 24){
		DEV_GPIO->INTRMODE2 &= ~(0xf << ((u8Idx-16) * 4));
		DEV_GPIO->INTRMODE2 |= u8Mode << ((u8Idx-16) * 4);
	}else{
		DEV_GPIO->INTRMODE3 &= ~(0xf << ((u8Idx-24) * 4));
		DEV_GPIO->INTRMODE3 |= u8Mode << ((u8Idx-24) * 4);
	}
	/*	Enable GPIO interrupt	*/
	DEV_GPIO->INTREN |= (1 << u8Idx);

	/*	Set input mode	*/
	DEV_GPIO->CHANNELDIR &=~(1 << u8Idx);
}

/***********************************************************************************************
 @brief:Disable interrupt function of GPIO specified PIN
 @para:
 -u8Idx: Specified GPIO port
 ***********************************************************************************************/
void GPIO_DisableInt(u8 u8Idx)
{
	DEV_GPIO->INTREN &= ~(1 << u8Idx);
}

/***********************************************************************************************
 @brief:Register GPIPO interrupt callback function
 @para:
 -cb: GPIO callback function
 ***********************************************************************************************/
void GPIO_RegisterCallback(DRVGPIO_Callback *cb)
{
	gGpioCallback = cb;
}
