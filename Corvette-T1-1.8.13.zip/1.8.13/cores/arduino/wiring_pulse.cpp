/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "wiring_pulse.h"
#include "wiring.h"
#include "wiring_digital.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "platform.h"
#include "Arduino.h"

/*extern "C" {
extern unsigned long countPulseASM(volatile uint8_t *port, uint8_t bit, uint8_t stateMask, unsigned long maxloops);
}*/

/* It's a dummy function.
 *
 * There are some problems in this implementation of pulseIn(), please use pulseInLong() instead of it.
 * Just leave it for backward-compatibility.
 */
/*unsigned long pulseIn(int pin, int state, unsigned long timeout)
{
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);
	uint8_t pinindex = GpioPinToPinIndex(gpio_pin);

	if (pinSupportPinMux(pinindex)) {
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(pinindex, PINMUX_FUNC_GPIO);
			if (err)
				return 0; // pulseInLong() doesn't have error code for pinmux, so reuse timeout error currently.
		}
		else if (pin_usage != PINMUX_FUNC_GPIO) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return 0; // pulseInLong() doesn't have error code for pinmux, so reuse timeout error currently.
		}
	}

	// cache the port and bit of the pin in order to speed up the
	// pulse width measuring loop and achieve finer resolution.  calling
	// digitalRead() instead yields much coarser resolution.
	uint8_t bit = ((uint8_t)gpio_pin & 0xff);
	uint8_t* port = (uint8_t*)(&(reg_gpio_in(gpio_pin)));
	uint8_t stateMask = (state ? bit : 0);

	// convert the timeout from microseconds to a number of times through
	// the initial loop; it takes approximately 14 clock cycles per iteration
	unsigned long maxloops = (timeout*(CPUFREQ/MHz))/14;
	unsigned long width = countPulseASM(port, bit, stateMask, maxloops);

	// prevent clockCyclesToMicroseconds to return bogus values if countPulseASM timed out
	if (width)
		return (((width*14)* MHz)/CPUFREQ);
	else
		return 0;
}
*/

unsigned long pulseIn(int pin, int state, unsigned long timeout) {
	return pulseInLong(pin, state, timeout);
}

/* Measures the length (in microseconds) of a pulse on the pin; state is HIGH
 * or LOW, the type of pulse to measure.  Works on pulses from 2-3 microseconds
 * to 3 minutes in length, but must be called at least a few dozen microseconds
 * before the start of the pulse.
 *
 * ATTENTION:
 * this function relies on micros() so cannot be used in noInterrupt() context
 */
unsigned long pulseInLong(int pin, int state, unsigned long timeout)
{

	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);
	uint8_t pinindex = GpioPinToPinIndex(gpio_pin);

	if (pinSupportPinMux(pinindex))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(pinindex, PINMUX_FUNC_GPIO);
			if (err)
				return 0; // pulseInLong() doesn't have error code for pinmux, so reuse timeout error currently.
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return 0; // pulseInLong() doesn't have error code for pinmux, so reuse timeout error currently.
		}
	}

	// This pin is used by GPIO in PinMux, or this pin doesn't support PinMux.
	unsigned long start_micros = micros();

	// wait for any previous pulse to end
	while (digitalRead(pin) == state)
	{
		if (micros() - start_micros > timeout)
			return 0;
	}

	// wait for the pulse to start
	while (digitalRead(pin) != state)
	{
		if (micros() - start_micros > timeout)
			return 0;
	}

	unsigned long start = micros();
	// wait for the pulse to stop
	while (digitalRead(pin) == state)
	{
		if (micros() - start_micros > timeout)
			return 0;
	}
	return micros() - start;
}
