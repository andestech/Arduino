#ifndef WIRING_ANALOG_H
#define WIRING_ANALOG_H

#include "typedef.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef enum{
	DEFAULT = 0,
	EXTERNAL,
	INTERNAL,
	INTERNAL1V1,
	INTERNAL2V56
}VoltageRef;


void analogReference(uint8_t mode);
int analogRead(uint8_t pin);
void analogWrite(uint8_t pin, int val);
void analogReadResolution(uint8_t bit);
void analogWriteResolution(uint8_t bit);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_ANALOG_H
