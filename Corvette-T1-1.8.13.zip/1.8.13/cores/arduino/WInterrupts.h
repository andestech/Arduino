#ifndef WINTERRUPTS_H
#define WINTERRUPTS_H

#include <inttypes.h>

#define digitalPinToInterrupt(pin) (pin)

void attachInterrupt(int pin, void (*callback)(void), uint32_t mode);
void detachInterrupt(int pin);

#endif //WINTERRUPTS_H
