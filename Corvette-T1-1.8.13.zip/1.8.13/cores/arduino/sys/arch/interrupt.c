/*
 * Copyright (c) 2012-2017 Andes Technology Corporation
 * All rights reserved.
 *
 */

#include <stdio.h>
#include "platform.h"

typedef void (*isr_func)(void);

void default_irq_handler(void)
{
}

void stimer_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void analog_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void timer1_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void timer0_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void dma_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void bmc_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_ctrl_ep_setup_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_ctrl_ep_data_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_ctrl_ep_status_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_ctrl_ep_setinf_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_endpoint_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void rf_dm_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void rf_ble_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void rf_bt_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void rf_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pwm_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pke_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void uart1_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void uart0_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void audio_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void i2c_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void hspi_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pspi_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_pwdn_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void gpio_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void gpio_risc0_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void gpio_risc1_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void soft_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus0_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus1_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus2_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus3_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus4_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_250us_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void usb_reset_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus7_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus8_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus9_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus10_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus11_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus12_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus13_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus14_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus15_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus16_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus17_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus18_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus19_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus20_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus21_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus22_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus23_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus24_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus25_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus26_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus27_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus28_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus29_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus30_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_bus31_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void npe_comb_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void pm_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));
void eoc_irq_handler(void) __attribute__((weak, alias("default_irq_handler")));

const isr_func irq_handler[] = {
	default_irq_handler,
	stimer_irq_handler,
	analog_irq_handler,
	timer1_irq_handler,
	timer0_irq_handler,
	dma_irq_handler,
	bmc_irq_handler,
	usb_ctrl_ep_setup_irq_handler,
	usb_ctrl_ep_data_irq_handler,
	usb_ctrl_ep_status_irq_handler,
	usb_ctrl_ep_setinf_irq_handler,
	usb_endpoint_irq_handler,
	rf_dm_irq_handler,
	rf_ble_irq_handler,
	rf_bt_irq_handler,
	rf_irq_handler,
	pwm_irq_handler,
	pke_irq_handler,
	uart1_irq_handler,
	uart0_irq_handler,
	audio_irq_handler,
	i2c_irq_handler,
	hspi_irq_handler,
	pspi_irq_handler,
	usb_pwdn_irq_handler,
	gpio_irq_handler,
	gpio_risc0_irq_handler,
	gpio_risc1_irq_handler,
	soft_irq_handler,
	npe_bus0_irq_handler,
	npe_bus1_irq_handler,
	npe_bus2_irq_handler,
	npe_bus3_irq_handler,
	npe_bus4_irq_handler,
	usb_250us_irq_handler,
	usb_reset_irq_handler,
	npe_bus7_irq_handler,
	npe_bus8_irq_handler,
	npe_bus9_irq_handler,
	npe_bus10_irq_handler,
	npe_bus11_irq_handler,
	npe_bus12_irq_handler,
	npe_bus13_irq_handler,
	npe_bus14_irq_handler,
	npe_bus15_irq_handler,
	npe_bus16_irq_handler,
	npe_bus17_irq_handler,
	npe_bus18_irq_handler,
	npe_bus19_irq_handler,
	npe_bus20_irq_handler,
	npe_bus21_irq_handler,
	npe_bus22_irq_handler,
	npe_bus23_irq_handler,
	npe_bus24_irq_handler,
	npe_bus25_irq_handler,
	npe_bus26_irq_handler,
	npe_bus27_irq_handler,
	npe_bus28_irq_handler,
	npe_bus29_irq_handler,
	npe_bus30_irq_handler,
	npe_bus31_irq_handler,
	npe_comb_irq_handler,
	pm_irq_handler,
	eoc_irq_handler
};

void mext_interrupt(unsigned int irq_source)
{
	/* Enable interrupts in general to allow nested */
	set_csr(NDS_MSTATUS, MSTATUS_MIE);

	/* Do interrupt handler */
	irq_handler[irq_source]();

	plic_interrupt_complete(irq_source);

	/* Disable interrupt in general to restore context */
	clear_csr(NDS_MSTATUS, MSTATUS_MIE);
}
