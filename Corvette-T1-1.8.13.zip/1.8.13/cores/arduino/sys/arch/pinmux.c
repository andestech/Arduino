#include <inttypes.h>

#include "pinmux.h"
#include "ct1_tlsr9518.h"

/*
 * Define a short alias of PinFunction which is only used in this C file,
 * because writing the origin name in the PinMux Table is too long.
 */
#define UNUSED PINMUX_FUNC_UNUSED
#define GPIO   PINMUX_FUNC_GPIO
#define PWM    PINMUX_FUNC_PWM
#define UART   PINMUX_FUNC_UART
#define I2C    PINMUX_FUNC_I2C
#define SPI    PINMUX_FUNC_SPI
#define ADC    PINMUX_FUNC_ADC

static const PinMuxSource* pinSourceOfFunction(const PinMuxInfo* pin_info, PinFunction pin_function)
{
	for (int i = 0; i < pin_info->source_num; ++i) {
		if (pin_info->source_list[i].function == pin_function) {
			return &(pin_info->source_list[i]);
		}
	}

	// pin mux doesn't support this function.
	return NULL;
}

const _PinMuxInfoList PinMuxInfoList = {{
	/* source_num = 0 means that this pin doesn't support pin mux. */
	/*  PA[0] */ { 0 },
	/*  PA[1] */ { 2, {{GPIO, 0}, {SPI, 1}} },
	/*  PA[2] */ { 2, {{GPIO, 0}, {SPI, 1}} },
	/*  PA[3] */ { 2, {{GPIO, 0}, {SPI, 1}} },
	/*  PA[4] */ { 2, {{GPIO, 0}, {SPI, 1}} },
	/*  PA[5] */ { 0 },
	/*  PA[6] */ { 0 },
	/*  PA[7] */ { 0 },

	/*  PB[0] */ { 2, {{GPIO, 0}, {ADC, 1}} },
	/*  PB[1] */ { 2, {{GPIO, 0}, {ADC, 1}} },
	/*  PB[2] */ { 2, {{GPIO, 0}, {ADC, 1}} },
	/*  PB[3] */ { 2, {{GPIO, 0}, {ADC, 1}} },
	/*  PB[4] */ { 2, {{GPIO, 0}, {ADC, 1}} },
	/*  PB[5] */ { 2, {{GPIO, 0}, {ADC, 1}} },
	/*  PB[6] */ { 1, {{GPIO, 0}} },
	/*  PB[7] */ { 0 },

	/*  PC[0] */ { 0 },
	/*  PC[1] */ { 2, {{GPIO, 0}, {I2C, 1}} },
	/*  PC[2] */ { 2, {{GPIO, 0}, {I2C, 1}} },
	/*  PC[3] */ { 1, {{GPIO, 0}} },
	/*  PC[4] */ { 1, {{GPIO, 0}} },
	/*  PC[5] */ { 0 },
	/*  PC[6] */ { 2, {{GPIO, 0}, {UART, 1}} },
	/*  PC[7] */ { 2, {{GPIO, 0}, {UART, 1}} },

	/*  PD[0] */ { 0 },
	/*  PD[1] */ { 0 },
	/*  PD[2] */ { 1, {{GPIO, 0}} },
	/*  PD[3] */ { 0 },
	/*  PD[4] */ { 0 },
	/*  PD[5] */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/*  PD[6] */ { 0 },
	/*  PD[7] */ { 2, {{GPIO, 0}, {PWM, 1}} },

	/*  PE[0] */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/*  PE[1] */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/*  PE[2] */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/*  PE[3] */ { 2, {{GPIO, 0}, {PWM, 1}} },
	/*  PE[4] */ { 0 },
	/*  PE[5] */ { 0 },
	/*  PE[6] */ { 0 },
	/*  PE[7] */ { 0 },

}};

_PinMuxUsageStat PinMuxUsageStat = {{
	// PA[0] ~ PA[7]
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
	// PB[0] ~ PB[7]
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
	// PC[0] ~ PC[7]
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
	// PD[0] ~ PD[7]
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
	// PE[0] ~ PE[7]
	UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED,
}};

int pinMuxSet(uint8_t pinindex, PinFunction pin_function)
{
	if (!pinSupportPinMux(pinindex))
		return PINMUX_UNSUPPORTED_PIN;

	const PinMuxInfo* pin_info = &(PinMuxInfoList.pins[pinindex]);
	const PinMuxSource* source_pin = pinSourceOfFunction(pin_info, pin_function);

	if (source_pin == NULL)
		return PINMUX_UNSUPPORTED_PIN_FUNCTION;

	// This pin is supported, then config pinmux to the pin function
	PinMuxUsageStat.pins[pinindex] = UNUSED;

	return 0;
}

// Only reset the software flag in PinMuxUsageStat, setting the hardware at next pinMuxSet
int pinMuxReset(uint8_t pinindex, PinFunction pin_function)
{
	if (!pinSupportPinMux(pinindex))
		return PINMUX_UNSUPPORTED_PIN;

	const PinMuxInfo* pin_info = &(PinMuxInfoList.pins[pinindex]);
	const PinMuxSource* source_pin = pinSourceOfFunction(pin_info, pin_function);

	if (source_pin == NULL)
		return PINMUX_UNSUPPORTED_PIN_FUNCTION;

	// This pin is supported, then config pinmux to the pin function
	PinMuxUsageStat.pins[pinindex] = UNUSED;

	return 0;
}

/* SPI */
SpiPins spi_to_pin[SPI_IP_NUM+1] = {
	{NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN},
	{1, 2, 3, 4}, /* HSPI PA1, PA2, PA3, PA4 */
};

SpiPins spiIpToPins(uint8_t ip_num) {
	if ((ip_num > SPI_IP_NUM) || (ip_num == 0)) {
		SpiPins no_spi = {NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN, NOT_GPIO_PIN};
		return no_spi;
	}

	return spi_to_pin[ip_num];
}

/* I2C */
I2cPins i2c_to_pin[I2C_IP_NUM+1] = {
	{NOT_GPIO_PIN, NOT_GPIO_PIN},
	{17, 18}, /* I2C PC1, PC2 */
};

I2cPins i2cIpToPins(uint8_t ip_num) {
	if ((ip_num > I2C_IP_NUM) || (ip_num == 0)) {
		I2cPins no_i2c = {NOT_GPIO_PIN, NOT_GPIO_PIN};
		return no_i2c;
	}

	return i2c_to_pin[ip_num];
}
