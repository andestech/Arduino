#ifndef WIRING_DIGITAL_H
#define WIRING_DIGITAL_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#define CHANGE  4
#define RISING  3
#define FALLING 2
#define HIGH    1
#define LOW     0

#define INPUT_PULLUP 0x2
#define OUTPUT    0x1
#define INPUT     0x0

/* Digital I/O */
void pinMode( int pin, unsigned int mode );
void digitalWrite( int pin, int value );
int digitalRead(int pin);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_DIGITAL_H
