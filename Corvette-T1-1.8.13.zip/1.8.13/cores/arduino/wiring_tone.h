#ifndef WIRING_TONE_H
#define WIRING_TONE_H

#include "typedef.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


// 1. C/C++ shared declarations
void toneTimerInit();
extern "C" void timer1_irq_handler(void);

void noTone(int pin);

#ifndef __cplusplus
// 2. C only declarations
void tone(int pin, unsigned int frequency, unsigned long duration);

#else
// 3. C++ only declarations
void tone(int pin, unsigned int frequency, unsigned long duration = 0);

#endif


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_TONE_H
