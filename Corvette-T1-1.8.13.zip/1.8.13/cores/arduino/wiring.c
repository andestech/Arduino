/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "wiring.h"

volatile static uint32_t us_time = 0;
volatile static uint32_t ms_time = 0;
volatile static unsigned int start_time = 0;

_attribute_ram_code_sec_ void stimer_irq_handler()
{
	uint32_t us_time_unit;
	uint32_t ms_time_unit;

	if(stimer_get_irq_status(FLD_SYSTEM_IRQ))
	{
		stimer_clr_irq_status(FLD_SYSTEM_IRQ);            //clr irq
		stimer_set_irq_capture(start_time-1);

		/* Timer overflow, add time period to global timer counter */
		us_time_unit = SYSTEM_TIMER_TICK_1S / 1000000;
		us_time += TIMER_OVERFLOW_TICK / us_time_unit;

		ms_time_unit = SYSTEM_TIMER_TICK_1S / 1000;
		ms_time += TIMER_OVERFLOW_TICK / ms_time_unit;
	}
}

void wiringTimerInit(void) {

	ms_time = 0;
	us_time = 0;
	plic_interrupt_enable(IRQ1_SYSTIMER);
	start_time = stimer_get_tick();
	stimer_set_irq_capture(start_time-1); //set capture tick
	stimer_set_irq_mask(FLD_SYSTEM_IRQ);		//irq enable

}

static uint32_t us_ticker_read(void) {

	uint32_t tm1_cntr, read_cntr;
	uint32_t us_time_unit;
	unsigned int read_time = stimer_get_tick();
	read_cntr = (uint32_t)((read_time > start_time) ? (read_time-start_time): ((TIMER_OVERFLOW_TICK-start_time)+read_time));
	us_time_unit = SYSTEM_TIMER_TICK_1S / 1000000;
	tm1_cntr = read_cntr / us_time_unit;

	return tm1_cntr;
}

void delay(uint32_t ms) {

	volatile uint32_t start;
	start = millis();
	while ((millis() - start) < ms);

}

uint32_t millis( void ) {

	uint32_t ms_time_tmp;
	ms_time_tmp = (uint32_t) us_ticker_read() / 1000;
	return ms_time + ms_time_tmp;

}

uint32_t micros( void ) {

	uint32_t us_time_tmp;
	us_time_tmp = (uint32_t) us_ticker_read();
	return us_time + us_time_tmp;

}

void delayMicroseconds(uint32_t usec) {

	volatile uint32_t start;
	start = micros();
	while ((micros() - start) < usec);

}
