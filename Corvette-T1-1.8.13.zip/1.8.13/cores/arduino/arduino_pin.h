#ifndef ARDUINO_PIN_H
#define ARDUINO_PIN_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "gpio.h"
#include "pinmux.h"

/* Arduino pin names of Corvette-F1 */

#define BT1   D2
#define BT2   D3
#define BT3   D4
#define BT4   D5

#define LED1  D6
#define LED2  D7
#define LED3  D8
#define LED4  D9

#define LED_BUILTIN 13

typedef enum {
	D0 = 0, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D13, /* 0 ~ 13 */
	A0, A1, A2, A3, A4, A5,
	D14, D15,
	INT_APDS, VDD_ENV,
	PIN_NUM,
	NOT_PIN
} ArduinoPin;

extern const GpioPin arduino_pin_to_GPIO_pin[];

#define PIN_SPI_SS    (10)
#define PIN_SPI_MOSI  (11)
#define PIN_SPI_MISO  (12)
#define PIN_SPI_SCK   (13)

static const ArduinoPin SS   = (ArduinoPin)PIN_SPI_SS;
static const ArduinoPin MOSI = (ArduinoPin)PIN_SPI_MOSI;
static const ArduinoPin MISO = (ArduinoPin)PIN_SPI_MISO;
static const ArduinoPin SCK  = (ArduinoPin)PIN_SPI_SCK;

#ifdef ARDUINO_MAIN
// Only define data in wiring_digital.c to avoid duplicate symbol.
// This hack is borrowed from ArduinoCore-avr (pins_arduino.h)

const GpioPin arduino_pin_to_GPIO_pin[PIN_NUM] = {
	// D0 ~ D13
	GPIO_PC7, GPIO_PC6, GPIO_PE3, GPIO_PE1, GPIO_PE2, GPIO_PE0, GPIO_PD7,
	GPIO_PD5, GPIO_PC3, GPIO_PC4, GPIO_PA1, GPIO_PA4, GPIO_PA3, GPIO_PA2,
	// A0 ~ A5
	GPIO_PB0, GPIO_PB1, GPIO_PB4, GPIO_PB5,	GPIO_PB3, GPIO_PB2,
	// D14 ~ D15
	GPIO_PC2, GPIO_PC1,
	// INT_APDS ~ VDD_ENV
	GPIO_PC2, GPIO_PC1,
};

#endif

static inline GpioPin arduinoPinToGpioPin(ArduinoPin pin){
	if (pin >= PIN_NUM)
		return (GpioPin)NOT_GPIO_PIN;

	return arduino_pin_to_GPIO_pin[pin];
}

static inline uint8_t GpioPinToPinIndex(GpioPin gpiopin){
	// Corvette-T1 with tlsr9518, the gpio ip with A~E group and each group with 0~7 pin
	// The first eight bit means group (0x00~0x04), the last eight bit means each pin
	// Ex: A0: 0x0001, A1: 0x0002, A2: 0x0004, A3: 0x0008, A4: 0x0010, A5: 0x0020, A6: 0x0040, A7: 0x0080
	//     B0: 0x0101, B1: 0x0102, B2: 0x0104, B3: 0x0108, B4: 0x0110, B5: 0x0120, B6: 0x0140, B7: 0x0180
	//     C0: 0x0201, C1: 0x0202, C2: 0x0204, C3: 0x0208, C4: 0x0210, C5: 0x0220, C6: 0x0240, C7: 0x0280
	//     D0: 0x0301, D1: 0x0302, D2: 0x0304, D3: 0x0308, D4: 0x0310, D5: 0x0320, D6: 0x0340, D7: 0x0380
	//     E0: 0x0401, E1: 0x0402, E2: 0x0404, E3: 0x0408, E4: 0x0410, E5: 0x0420, E6: 0x0440, E7: 0x0480
	// This function GpioPinToPinIndex() conver GPIO pin to pin index in pinmux.c
	uint8_t group = (gpiopin >> 8)*8;
	uint8_t bit = (gpiopin & 0xFFU);
	while (bit) {
		group++;
		bit >>= 1;
	}
	group -= 1;
	return group;
}

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //ARDUINO_PIN_H
