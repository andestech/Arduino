/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#define ARDUINO_MAIN
// [ARDUINO_MAIN] arduino_pin.h's variable definition is only defined in this C file.

#include "wiring_digital.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "ct1_tlsr9518.h"
#include "gpio.h"
#include "pwm.h"

/*
 * CF1-AE250's analogWrite() output 980Hz PWM wave instead of Arduino Uno's 490Hz,
 * because the clock rate of timer in this platform isn't suitable for 490Hz.
 * CT1 support PWM in core and support 480Hz PWM wave
 */
#define PWM_FREQ_ANALOG_WRITE 490
#define PWM_PCLK_SPEED      12000000 //pwm clock 12M.

void pinMode( int pin, IO_TYPE mode )
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);

	if (mode == INPUT)
	{
		gpio_function_en(gpio_pin);
		gpio_output_dis(gpio_pin);
		gpio_input_en(gpio_pin);
		gpio_set_up_down_res(gpio_pin, GPIO_PIN_UP_DOWN_FLOAT);
	}
	else if (mode == INPUT_PULLUP)
	{
		gpio_function_en(gpio_pin);
		gpio_output_dis(gpio_pin);
		gpio_input_en(gpio_pin);
		gpio_set_up_down_res(gpio_pin, GPIO_PIN_PULLUP_10K);
	}
	else if (mode == OUTPUT)
	{
		gpio_function_en(gpio_pin);
		gpio_output_en(gpio_pin);
	}
}

void digitalWrite( int pin, int value )
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);
	uint8_t gpio_pin_index = GpioPinToPinIndex(gpio_pin);
	if (pinSupportPinMux(gpio_pin_index))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(gpio_pin_index);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(gpio_pin_index, PINMUX_FUNC_GPIO);
			if (err)
				return;
		}
		else if (pin_usage == PINMUX_FUNC_PWM) {
			// use PWM Park to emulate GPIO output.

			// Always pull high or low by pwm, the period is not important
			uint32_t pwm_period = PWM_PCLK_SPEED / PWM_FREQ_ANALOG_WRITE;
			pwm_id_e pwm_id = get_pwmid((pwm_pin_e)gpio_pin);
			pwm_stop(pwm_id);
			pwm_set_pin(gpio_pin);
			pwm_set_clk((unsigned char) (PCLKFREQ/PWM_PCLK_SPEED-1));
			pwm_set_pwm0_mode(PWM_NORMAL_MODE);
			pwm_set_tmax(pwm_id,pwm_period);

			if (value == HIGH) {
				pwm_set_tcmp(pwm_id, pwm_period);
			} else {
				pwm_set_tcmp(pwm_id,0);
			}

			pwm_start(pwm_id);

			return;
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}
	// This pin is used by GPIO in pin mux, or this pin doesn't support pin mux.

	if(value == HIGH)
		gpio_set_high_level(gpio_pin);
	else
		gpio_set_low_level(gpio_pin);
}

int digitalRead( int pin )
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);
	uint8_t gpio_pin_index = GpioPinToPinIndex(gpio_pin);

	if (pinSupportPinMux(gpio_pin_index))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(gpio_pin_index);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(gpio_pin_index, PINMUX_FUNC_GPIO);
			if (err)
				return LOW; // digitalRead() doesn't have error code to return, so return LOW for error currently.
		}
		else if (pin_usage == PINMUX_FUNC_PWM) {
			// digitalRead() turn off analogWrite() (PWM).
			pwm_id_e pwm_id = (pwm_id_e)(get_pwmid((pwm_pin_e)gpio_pin));
			pwm_set_tcmp(pwm_id,0);
			pwm_stop(pwm_id);

			return LOW;
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return LOW;     // digitalRead() doesn't have error code to return, so return LOW for error currently.
		}
	}

	// This pin is used by GPIO in PinMux, or this pin doesn't support PinMux.
	if(!gpio_get_level(gpio_pin))
		return LOW;
	else
		return HIGH;
}
