#include "HardwareSerial.h"
#include "arduino_pin.h"
#include "pinmux.h"

static UART_RCV_SEND_QUEUE *pUartCh0, uartCh0={{0}, {0}, 0, 0, 0, 0};

// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
void serialEvent() __attribute__((weak));

HardwareSerial::HardwareSerial()
{
	;
}

void HardwareSerial::begin(uint32_t baud)
{
	begin(baud, SERIAL_8N1);
}

void HardwareSerial::begin(uint32_t baud,uint32_t config)
{
	unsigned short div;
	unsigned char bwpc;

	u8 UART_DRV_STOPBITS = (u8) (config & 0xf);
	u8 UART_DRV_PARITY = (u8) ((config >> 4) & 0xf);

	uart_parity_e parity_arrar[4] = {UART_PARITY_NONE, UART_PARITY_ODD, UART_PARITY_NONE, UART_PARITY_EVEN};
	uart_stop_bit_e stopbit_array[2] = {UART_STOP_BIT_ONE, UART_STOP_BIT_TWO};

	uartCh0 = {{0}, {0}, 0, 0, 0, 0};

	uart_set_pin(UART1_TX_PC6,UART1_RX_PC7);
	uart_reset(UART1);
	uart_clr_tx_index(UART1);
	uart_cal_div_and_bwpc(baud, PCLKFREQ, &div, &bwpc);
	uart_init(UART1, div, bwpc, parity_arrar[UART_DRV_PARITY], stopbit_array[UART_DRV_STOPBITS]);
	uart_tx_irq_trig_level(UART1, 0);
	uart_rx_irq_trig_level(UART1, 1);

	uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_RX_IRQ_MASK|UART_ERR_IRQ_MASK));
	plic_interrupt_enable(IRQ18_UART1); //if you want to use UART1,the parameter is - IRQ18_UART1

	// PinMux config
	uint8_t rx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D0));
	uint8_t tx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D1));

	if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UART)
		pinMuxSet(rx_pin, PINMUX_FUNC_UART);
	if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UART)
		pinMuxSet(tx_pin, PINMUX_FUNC_UART);

	pUartCh0 = &uartCh0;

	begin_flag = 1;
}

void HardwareSerial::end()
{
	if(!begin_flag)
		return;

	begin_flag = 0;

	uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK|UART_RX_IRQ_MASK|UART_ERR_IRQ_MASK));
	plic_interrupt_disable(IRQ18_UART1); //if you want to use UART1,the parameter is - IRQ18_UART1
	uart_reset(UART1);
	uart_clr_tx_index(UART1);
	uint8_t rx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D0));
	uint8_t tx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D1));

	// Reset the software flag for the next pin application
	if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UNUSED)
		pinMuxReset(rx_pin, PINMUX_FUNC_UART);
	if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UNUSED)
		pinMuxReset(tx_pin, PINMUX_FUNC_UART);
}

int HardwareSerial::available(void)
{
	UART_RCV_SEND_QUEUE *tUartCh = pUartCh0;

	if(!begin_flag)
		return 0;

	return (tUartCh->uartRcvTail < tUartCh->uartRcvHead) ? ((tUartCh->uartRcvTail-tUartCh->uartRcvHead) + UART_MAX_BUF_SIZ)	\
		:(tUartCh->uartRcvTail - tUartCh->uartRcvHead) ;
}

int HardwareSerial::read(void)
{
	if(!begin_flag)
		return -1;

	if(available()) {
		volatile char ch = ' ';
		UART_RCV_SEND_QUEUE *tUartCh;
		tUartCh=pUartCh0;
		ch=tUartCh->uartRcvBuf[tUartCh->uartRcvHead];

		if(++tUartCh->uartRcvHead == UART_MAX_BUF_SIZ)
			tUartCh->uartRcvHead = 0;

		return (int)ch;
	}
	else
		return -1;
}

size_t HardwareSerial::write(uint8_t c)
{
	UART_RCV_SEND_QUEUE *tUartCh = pUartCh0;

	if(!begin_flag)
		return 1;

	// If THR is empty, we write data to THR directly.
	if((tUartCh->uartSendTail == tUartCh->uartSendHead) && (!uart_tx_is_busy(UART1))) {
		uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		uart_send_byte(UART1, c);
	} else {
		// If the transmission buffer is full, we have to consume an old data befor enqueue the new data
		while( ((tUartCh->uartSendTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartSendHead) {
			uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
			while (uart_tx_is_busy(UART1));
			uart_send_byte(UART1, tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
			uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
			if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
				tUartCh->uartSendHead = 0;
		}
		// Enqueue the new data
		tUartCh->uartSendBuf[tUartCh->uartSendTail++] = c;

		if(tUartCh->uartSendTail == UART_MAX_BUF_SIZ)
			tUartCh->uartSendTail = 0;

		uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
	}

	return 1;
}

size_t HardwareSerial::write(const char *buffer, size_t size)
{
	size_t len = size;

	if(!begin_flag)
		return size;

	while (len--) {
		UART_RCV_SEND_QUEUE *tUartCh = pUartCh0;

		// If THR is empty, we write data to THR directly.
		if((tUartCh->uartSendTail == tUartCh->uartSendHead) && (!uart_tx_is_busy(UART1))){
			uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
			uart_send_byte(UART1, *buffer);
		} else {
			// If the transmission buffer is full, we have to consume an old data befor enqueue the new data
			while( ((tUartCh->uartSendTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartSendHead) {
				uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
				while (uart_tx_is_busy(UART1));
				uart_send_byte(UART1, tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
				uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
				if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
					tUartCh->uartSendHead = 0;
			}
			// Enqueue the new data
			tUartCh->uartSendBuf[tUartCh->uartSendTail++] = *buffer;

			if(tUartCh->uartSendTail == UART_MAX_BUF_SIZ)
				tUartCh->uartSendTail = 0;

			uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		}
		buffer++;
	}

	return size;
}

int HardwareSerial::peek(void)
{
	if(!begin_flag)
		return -1;

	if(available()) {
		UART_RCV_SEND_QUEUE *tUartCh = pUartCh0;
		return (int)(tUartCh->uartRcvBuf[tUartCh->uartRcvHead]);
	}
	else
		return -1;
}

void HardwareSerial::flush()
{
	UART_RCV_SEND_QUEUE *tUartCh = pUartCh0;

	if(!begin_flag)
		return;

	uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
	u32 len = (tUartCh->uartSendTail >= tUartCh->uartSendHead)?(tUartCh->uartSendTail-tUartCh->uartSendHead)	\
		:(tUartCh->uartSendTail-tUartCh->uartSendHead)+UART_MAX_BUF_SIZ;

	while(len) {
		while (uart_tx_is_busy(UART1));
		uart_send_byte(UART1, tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
		len--;
		if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
			tUartCh->uartSendHead = 0;
	}
	while (uart_tx_is_busy(UART1));
}

int HardwareSerial::availableForWrite() {

	UART_RCV_SEND_QUEUE *tUartCh = pUartCh0;
	unsigned int len;

	if(!begin_flag)
		return 0;

	uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
	len = (tUartCh->uartSendTail >= tUartCh->uartSendHead)?(tUartCh->uartSendTail-tUartCh->uartSendHead)	\
		:(tUartCh->uartSendTail-tUartCh->uartSendHead)+UART_MAX_BUF_SIZ;

	if (len)
		uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));

	return len;
}

void serialEventRun(void)
{
	if (Serial && serialEvent && Serial.available()) serialEvent();
}

void HardwareSerial::insertRcvData(char* buffer, unsigned int len) {
	for(unsigned int i=0; i<len; i++) {
		pUartCh0->uartRcvBuf[pUartCh0->uartRcvTail++] = *buffer++;

		if(pUartCh0->uartRcvTail == UART_MAX_BUF_SIZ)
			pUartCh0->uartRcvTail = 0;
	}
}

void HardwareSerial::insertSendData(char* buffer, unsigned int len) {
	uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));

	for(unsigned int i=0; i<len; i++) {
		pUartCh0->uartSendBuf[pUartCh0->uartSendTail++] = *buffer++;

		if(pUartCh0->uartSendTail == UART_MAX_BUF_SIZ)
			pUartCh0->uartSendTail = 0;
	}

	uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
}

void uart1_irq_handler(void)// if you want to use UART1,the function is - uart1_irq_handler()
{
	if(uart_get_irq_status(UART1, UART_RX_ERR)) {
		uart_clr_irq_status(UART1,UART_CLR_RX);// it will clear rx_fifo and rx_err_irq ,rx_buff_irq,so it won't enter rx_buff interrupt.
		uart_reset(UART1); //clear hardware pointer
		uart_clr_rx_index(UART1); //clear software pointer
	}
	if(uart_get_irq_status(UART1, UART_RXBUF_IRQ_STATUS)) {
		unsigned int isFull = ((pUartCh0->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh0->uartRcvHead ? 1 : 0;
		if(!isFull) {
			pUartCh0->uartRcvBuf[pUartCh0->uartRcvTail++] = uart_read_byte(UART1);
			if(pUartCh0->uartRcvTail == UART_MAX_BUF_SIZ)
				pUartCh0->uartRcvTail = 0;
		}
		else {
			uart_read_byte(UART1);
		}
	}
	if(uart_get_irq_status(UART1, UART_TXBUF_IRQ_STATUS)) {
		uart_clr_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		if(pUartCh0->uartSendTail != pUartCh0->uartSendHead) {
			uart_send_byte(UART1, pUartCh0->uartSendBuf[pUartCh0->uartSendHead++]);
			if(pUartCh0->uartSendHead == UART_MAX_BUF_SIZ)
				pUartCh0->uartSendHead = 0;
		}
		if(pUartCh0->uartSendTail != pUartCh0->uartSendHead) {
			uart_set_irq_mask(UART1, static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		}
	}
}

HardwareSerial Serial;
