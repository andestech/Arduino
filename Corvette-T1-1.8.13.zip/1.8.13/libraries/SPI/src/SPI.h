#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED

#include "Arduino.h"
#include "arduino_pin.h"
extern "C" {
#include "telink_spi.h"
}


#ifndef LSBFIRST
#define LSBFIRST            0
#endif
#ifndef MSBFIRST
#define MSBFIRST            1
#endif

#define SPI_CLOCK_DIV2      2
#define SPI_CLOCK_DIV4      4
#define SPI_CLOCK_DIV8      8
#define SPI_CLOCK_DIV16     16
#define SPI_CLOCK_DIV32     32
#define SPI_CLOCK_DIV64     64
#define SPI_CLOCK_DIV128    128

#define SPI_CLK             HCLKFREQ
#define HSPI_MODULE         1
#define CSN_PIN1            HSPI_CSN_PA1

class SPIClass;

class SPISettings {
private:
	const static uint8_t DEFAULT_DATA_MODE = SPI_MODE0;

	uint32_t spi_clock = SPI_CLK;
	uint8_t data_mode = DEFAULT_DATA_MODE;
	friend class SPIClass;

public:
	SPISettings(uint32_t clock = SPI_CLK, uint8_t bitOrder = MSBFIRST, uint8_t dataMode = DEFAULT_DATA_MODE) {
		/*
		 * SPI clock rate: If SPI_CLK == 66MHz, the accepted clock rate is between 132KHz to 66MHz
		 */
		this->spi_clock = clock;
		this->data_mode = dataMode;
	}
};

class SPIClass {
	public:
	// Initialize the SPI library
	void begin();
	// Disable the SPI bus
	void end();
	void beginTransaction(SPISettings settings);
	// After performing a group of transfers and releasing the chip select
	// signal, this function allows others to access the SPI bus
	void endTransaction(void);
	// Write to the SPI bus (MOSI pin) and also receive (MISO pin)
	uint8_t transfer(uint8_t data);
	uint16_t transfer16(uint16_t data);
	void transfer(void *buf, size_t count);
	/* These functions (set*()) are deprecated.
	 * New applications should use beginTransaction() to configure SPI settings.
	 */
	void setBitOrder(uint8_t bitOrder);
	void setDataMode(uint8_t dataMode);
	void setClockDivider(uint8_t clockDiv);
};

extern SPIClass SPI;

#endif
