//#include <nds32_intrinsic.h>
#include "f1_ae210_spi.h"
//#include "f1_ae210.h"

void SPI_EnableManualCS(SPI_TypeDef *spiPort)
{
	spiPort->DIRECTIO |= CS_OE;
}

void SPI_DisableManualCS(SPI_TypeDef *spiPort)
{
	spiPort->DIRECTIO &= ~CS_OE;
}

void SPI_SetCS(SPI_TypeDef *spiPort)
{
	spiPort->DIRECTIO |= CS_O;
}

void SPI_ClrCS(SPI_TypeDef *spiPort)
{
	spiPort->DIRECTIO &= ~CS_O;
}

void SPI_SetBitLength(SPI_TypeDef *spiPort,u8 u8Len)
{
	//Set bit length
	spiPort->TRANSFMT =  ((spiPort->TRANSFMT & ~(0x1F<<8)) | (((u8Len-1) & 0x1F) << 8));
}

void SPI_StartTransfer(SPI_TypeDef *spiPort,u32 u32Data)
{
	/*
	TransMode: 0x00 ; Write 1 byte ; Read 1 byte;
	*/
	spiPort->TRANSCTRL = (SPI_TRANSMODE_WRnRD | WR_TRANCNT(1) | RD_TRANCNT(1));
	spiPort->INTRST &= SPI_ENDINT;
	spiPort->INTREN = SPI_ENDINT;

	spiPort->DATA = u32Data;
	spiPort->CMD = 0;
}

u8 SPI_IsBusy(SPI_TypeDef *spiPort)
{
	return((spiPort->INTRST & SPI_ENDINT)?0:1);
}

u32 SPI_ReadRxFIFO(SPI_TypeDef *spiPort)
{
	spiPort->INTRST |= SPI_ENDINT;
	return spiPort->DATA;
}

void SPI_WriteTxFIFO(SPI_TypeDef *spiPort,u32 u32Data)
{
	spiPort->DATA = u32Data;
}

void SPI_ClrTxFIFO(SPI_TypeDef *spiPort)
{
	spiPort->CTRL |= TXFIFORST;
}

void SPI_ClrRxFIFO(SPI_TypeDef *spiPort)
{
	spiPort->CTRL |= RXFIFORST;
}

void SPI_SetClockFreq(SPI_TypeDef *spiPort,u8 u8Div)
{
	spiPort->TIMING &= ~0xff;
	spiPort->TIMING |= u8Div;
}

void SPI_Init_portonly(SPI_TypeDef *spiPort)
{
	spiPort->CTRL = (TXFIFORST | RXFIFORST | SPIRST);

	SPI_SetMaster(spiPort);
}

void SPI_Init(SPI_TypeDef *spiPort,SPI_DATA_t *tParam)
{
}

void SPI_DeInit(SPI_TypeDef *spiPort)
{
}

void SPI_SetMaster(SPI_TypeDef *spiPort)
{
	spiPort->TRANSFMT &= ~(SPI_MERGE | SPI_SLAVE);
}

void _SPI_SetDataMode(SPI_TypeDef *spiPort,SPI_DATA_t *tParam)
{

	if(tParam->u8ClkPhase == SPI_DRV_CLKPH_ONE && tParam->u8ClkPolarity == SPI_DRV_CLKPO_LOW){
		spiPort->TRANSFMT &= ~SPI_CPOL;
		spiPort->TRANSFMT |= SPI_CPHA;
	}else if(tParam->u8ClkPhase == SPI_DRV_CLKPH_HALF && tParam->u8ClkPolarity == SPI_DRV_CLKPO_LOW){
		spiPort->TRANSFMT &= ~(SPI_CPOL|SPI_CPHA);
        }else if(tParam->u8ClkPhase == SPI_DRV_CLKPH_ONE && tParam->u8ClkPolarity == SPI_DRV_CLKPO_HIGH){
		spiPort->TRANSFMT |= SPI_CPOL;
		spiPort->TRANSFMT &= ~SPI_CPHA;
        }else{
		spiPort->TRANSFMT |= SPI_CPOL;
		spiPort->TRANSFMT |= SPI_CPHA;
	}

}

void SPI_SetSPIDataMode(SPI_TypeDef *spiPort, u8 dataMode)
{
    SPI_DATA_t tSpiData;

    if(dataMode == 0)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 1)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 2)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }
    else if(dataMode == 3)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }

    _SPI_SetDataMode(spiPort, &tSpiData);
}

void SPI_Settings(SPI_TypeDef *spiPort, u8 div, u8 dataMode)
{
    SPI_DATA_t tSpiData;

    tSpiData.u8Mode = SPI_DRV_MODE_MASTER;
    tSpiData.u8Div = div;

    if(dataMode == 0)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 1)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_LOW;
    }
    else if(dataMode == 2)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_ONE;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }
    else if(dataMode == 3)
    {
        tSpiData.u8ClkPhase = SPI_DRV_CLKPH_HALF;
        tSpiData.u8ClkPolarity = SPI_DRV_CLKPO_HIGH;
    }

    _SPI_SetDataMode(spiPort, &tSpiData); /* mode 1 */
    SPI_SetClockFreq(spiPort, div);

}

u32 SPI_Transfer(SPI_TypeDef *spiPort, u8 byte_lens, u32 data)
{
    u32 rx_fifo;

    SPI_SetBitLength(spiPort, (byte_lens << 3) );
    SPI_ClrRxFIFO(spiPort);
    SPI_ClrTxFIFO(spiPort);
    SPI_StartTransfer(spiPort, data);

    while(SPI_IsBusy(spiPort));

    rx_fifo = SPI_ReadRxFIFO(spiPort);
    //spiPort->INTRST |= (SPI_ENDINT|SPI_RXFIFOINT|SPI_TXFIFOINT);

    return rx_fifo;
}
