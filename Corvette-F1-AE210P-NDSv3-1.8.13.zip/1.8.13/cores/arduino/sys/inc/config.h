/*
 * Copyright (c) 2012-2015 Andes Technology Corporation
 * All rights reserved.
 *
 */
// Config the features of startup demo programs.

#ifndef __CONFIG_H__
#define __CONFIG_H__

// Please put the defines shared by makefile projects and AndeSight projects

#define GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)

// GCC < 4.8.2 (Before BSP400 gcc version)
// Check the GCC version for toolchain builtin macro compatible issue.
#if GCC_VERSION < 40802

#ifdef NDS32_BASELINE_V3
#define __NDS32_ISA_V3__	NDS32_BASELINE_V3
#endif

#ifdef NDS32_BASELINE_V3M
#define __NDS32_ISA_V3M__	NDS32_BASELINE_V3M
#endif

#endif

// Chkeck whether the following intrinsic functions are supported by toolchain.
// Some intrinsic functions are not supported by old toolchain and need to be wrapped.
#ifndef __ASSEMBLER__

#include <nds32_intrinsic.h>

#ifndef __nds32__mtsr_isb
#define __nds32__mtsr_isb(val, srname)  \
do {__nds32__mtsr(val, srname);__nds32__isb();} while(0)
#endif

#ifndef __nds32__mtsr_dsb
#define __nds32__mtsr_dsb(val, srname)	\
do {__nds32__mtsr(val, srname);__nds32__dsb();} while(0)
#endif

#endif

#ifndef	CFG_MAKEFILE

// The defines are only used by AndeSight projects

//----------------------------------------------------------------------------------------------------

// Users can configure the defines in this area
// to match different environment setting

// Platform select : F1 AE100
#define	CFG_F1_AE100			// platform is F1 AE100

// Address mode select
//#define	CFG_16MB		// platform is 16MB, if it isn't defined, platform is 4GB

// Support ZOL select			// do ZOL supporting when CPU supports ZOL
//#define	CFG_HWZOL

// Code coverage select
//#define	CFG_GCOV		// do code coverage support

// Simulation environment select
//#define	CFG_SIMU		// do simulation on SID

// Build mode select
// The BUILD_MODE can be specified to BUILD_XIP/BUILD_BURN/BUILD_LOAD only.
//
// NOTE: The BUILD_SIMU is not supported any more. Please uncomment CFG_SIMU
//       to select simulation environment.
#define BUILD_MODE	BUILD_XIP


//----------------------------------------------------------------------------------------------------
// The followings are predefined settings
// Please do not modify them

#define	BUILD_LOAD	1		// The program is loaded by GDB or eBIOS
#define	BUILD_BURN	2		// The program is burned to the flash, but run in RAM
					// demo-ls2 use BURN mode
#define	BUILD_XIP	3		// The program is burned to the flash and run in the flash
					// To use this mode, xip linker script files must be used
					// demo-ls1 use XIP mode

#ifndef __NDS32_EXT_EX9__
	// This toolchain cannot support EX9
//	#define CONFIG_NO_NDS32_EXT_EX9
#endif

// Burn mode
#define CFG_XIP
#define CFG_LLINIT

#endif // CFG_MAKEFILE

// Please put the defines shared by makefile projects and AndeSight projects (may overwrite AndeSight setting)

#ifdef __NDS32_ISA_V3M__
	// v3m toolchain only support 16MB
	#undef CFG_16MB
	#define CFG_16MB
#endif

// f1_ae210 always use 16MB currently.
#define CFG_16MB

#include "f1_ae210.h"			//Platform header file

#endif // __CONFIG_H__

