#ifndef F1_AE210_SPI_H_
#define F1_AE210_SPI_H_

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus


#include "f1_ae210.h"

typedef struct
{
    u8 u8Mode;/*SPI Mode: Maste/Slave*/
    u8 u8Div;   /*SPI clock divider*/
    u8 u8ClkPhase;  /*SPI clock phase*/
    u8 u8ClkPolarity; /*SPI clock polarity*/
}SPI_DATA_t;

#define SPI_DRV_MODE_MASTER (1)
#define SPI_DRV_MODE_SLAVE  (0)
/*SPI clock polarity*/
#define SPI_DRV_CLKPO_HIGH (1) /*Clock remain high when SPI is idle*/
#define SPI_DRV_CLKPO_LOW  (0) /*Clock remain low when SPI is idle*/

/*SPI clock phase*/
#define SPI_DRV_CLKPH_HALF (1)
#define SPI_DRV_CLKPH_ONE  (0)

//==============================================

/* SPI transfer format register */
#define SPI_CPHA			(1UL << 0)
#define SPI_CPOL			(1UL << 1)
#define SPI_SLAVE			(1UL << 2)
#define SPI_LSB				(1UL << 3)
#define SPI_MERGE			(1UL << 7)
#define DATA_BITS(data_bits)		((data_bits - 1) << 8)

/* SPI transfer control register */
// RD/WR transfer count
#define RD_TRANCNT(num)			((num - 1) << 0)
#define WR_TRANCNT(num)			((num - 1) << 12)

// SPI transfer mode
#define SPI_TRANSMODE_WRnRD		(0x0 << 24)
#define SPI_TRANSMODE_WRONLY		(0x1 << 24)
#define SPI_TRANSMODE_RDONLY		(0x2 << 24)
#define SPI_TRANSMODE_WR_RD		(0x3 << 24)
#define SPI_TRANSMODE_RD_WR		(0x4 << 24)
#define SPI_TRANSMODE_WR_DMY_RD		(0x5 << 24)
#define SPI_TRANSMODE_RD_DMY_WR		(0x6 << 24)
#define SPI_TRANSMODE_NONEDATA		(0x7 << 24)
#define SPI_TRANSMODE_DMY_WR		(0x8 << 24)
#define SPI_TRANSMODE_DMY_RD		(0x9 << 24)

#define SPI_TXDMA_EN			(1UL << 4)
#define SPI_RXDMA_EN			(1UL << 3)
/* SPI control register */
#define SPIRST				(1UL << 0)
#define RXFIFORST			(1UL << 1)
#define TXFIFORST			(1UL << 2)
#define RXTHRES(num)			(num << 8)
#define TXTHRES(num)			(num << 16)

#define THRES_MASK			(0x1f)
#define RXTHRES_OFFSET			(8)
#define TXTHRES_OFFSET			(16)


/* SPI intrrupts status register */
/* SPI interrupt enable register*/
//==============================================
#define SPI_RXFIFOOORINT              (1UL << 0)
#define SPI_TXFIFOOURINT              (1UL << 1)
#define SPI_RXFIFOINT                 (1UL << 2)
#define SPI_TXFIFOINT                 (1UL << 3)
#define SPI_ENDINT                    (1UL << 4)
#define SPI_SLVCMD                    (1UL << 5)

/* SPI direct IO control register */
//==============================================
#define CS_OE				(1UL << 16)
#define CS_O				(1UL << 8)

void SPI_EnableManualCS(SPI_TypeDef *spiPort);
void SPI_DisableManualCS(SPI_TypeDef *spiPort);
void SPI_SetCS(SPI_TypeDef *spiPort);
void SPI_ClrCS(SPI_TypeDef *spiPort);
void SPI_SetBitLength(SPI_TypeDef *spiPort,u8 u8Len);
void SPI_StartTransfer(SPI_TypeDef *spiPort,u32 u32Data);
u8 SPI_IsBusy(SPI_TypeDef *spiPort);
u32 SPI_ReadRxFIFO(SPI_TypeDef *spiPort);
void SPI_WriteTxFIFO(SPI_TypeDef *spiPort,u32 u32Data);
void SPI_ClrTxFIFO(SPI_TypeDef *spiPort);
void SPI_ClrRxFIFO(SPI_TypeDef *spiPort);
void SPI_SetClockFreq(SPI_TypeDef *spiPort,u8 u8Div);
void SPI_SetMaster(SPI_TypeDef *spiPort);
void SPI_Init_portonly(SPI_TypeDef *spiPort);
void SPI_Init(SPI_TypeDef *spiPort,SPI_DATA_t *tParam);
void SPI_DeInit(SPI_TypeDef *spiPort);
void SPI_SetSPIDataMode(SPI_TypeDef *spiPort, u8 dataMode);
void SPI_Settings(SPI_TypeDef *spiPort, u8 div, u8 dataMode);
u32 SPI_Transfer(SPI_TypeDef *spiPort, u8 bitlen, u32 data);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif
