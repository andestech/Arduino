#include "config.h"

#pragma GCC optimize "no-test-coverage"
#pragma GCC optimize "no-profile-arcs"

asm (".text");

/*  Declare a pointer to void function type.  */
typedef void (*func_ptr) (void);

/* Define __dso_handle which would be needed for C++ library.
 *    Since our elf-toolchain only builds programs with static link,
 *       we can directly define 'void *__dso_handle = 0'.  */
void *__dso_handle = 0;

/* Put a word containing zero at the end of each of our two lists of function
   addresses.  Note that the words defined here go into the .ctors and .dtors
   sections of the crtend.o file, and since that file is always linked in
   last, these words naturally end up at the very ends of the two lists
   contained in these two sections.  */

func_ptr __CTOR_END__[1] __attribute__((__unused__)) __attribute__ ((section (".ctors")))
	= { (func_ptr) 0 };

/* Run all global constructors for the program.
   Note that they are run in reverse order.  */
extern func_ptr __CTOR_LIST__[1];
void __do_global_ctors (void)
{
	func_ptr *p;
	for (p = __CTOR_END__ - 1; p != __CTOR_LIST__ ; p--)
	(*p) ();
}

asm (".text");
