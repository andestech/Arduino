/*
 * Copyright (c) 2012-2015 Andes Technology Corporation
 * All rights reserved.
 *
 */
/*
	This file includes weak (i.e. optional) functions to perform SoC related
	initialization. They are:
	1). _nds32_init_mem():
		Executed before C language initialization to make memory
		ready so that program data can be initialized. An example
		is to initialize DRAM.
		Since this is called before C initialization, please
		use provided macros to avoid problems.
	2). __soc_init():
		Further SoC intialization. Called after C language
		initialization, so it is a typical C function.
*/

#include <nds32_intrinsic.h>
#include "config.h"


#ifdef CFG_LLINIT
/* This must be a leave function, no child funcion. */
#if GCC_VERSION < 40802
void _nds32_init_mem(void) __attribute__((no_prologue));
#else
void _nds32_init_mem(void) __attribute__((naked));
#endif
void _nds32_init_mem(void) //The function is weak (optional)
{
	/* System without RAM. Use data local memory as system memory. */
        extern char __data_start;
        register unsigned int dlmsize;

        dlmsize = 0x1000 << ((__nds32__mfsr(NDS32_SR_DLMB) >> 1) & 0xf);

        /* Set DLM base to .data start address and enable it */
        __nds32__mtsr_dsb((unsigned)&__data_start|1, NDS32_SR_DLMB);

        /* Update stack pointer to end of DLM
         * We suppose the .data + .bss + stack less then DLM size */
        __nds32__set_current_sp((unsigned)&__data_start + dlmsize);
}
#endif


void __soc_init()
{
}

