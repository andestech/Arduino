#include "wiring_shift.h"

#ifdef __cplusplus
 extern "C" {
#endif

uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder) {
	static uint8_t i = 0;
	i++;
	return i;
}

void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val)
{
	static uint8_t i = 0;
	i++;

}

#ifdef __cplusplus
}
#endif
