#ifndef WIRING_ANALOG_H
#define WIRING_ANALOG_H
#include "typedef.h"

typedef enum{
	A0 = 0,
	A1,
	A2,
	A3,
	A4,
	A5
}AnalogPinName;


typedef enum{
	DEFAULT = 0,
	EXTERNAL,
	INTERNAL,
	INTERNAL1V1,
	INTERNAL2V56
}VoltageRef;


void analogReference(uint8_t mode);
int analogRead(uint8_t pin);
void analogWrite(uint8_t pin, int val);
void analogReadResolution(uint8_t bit);
void analogWriteResolution(uint8_t bit);

#endif //WIRING_ANALOG_H
