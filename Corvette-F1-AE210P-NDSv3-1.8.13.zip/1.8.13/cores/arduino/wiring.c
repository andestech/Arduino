/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "wiring.h"

#ifdef __cplusplus
extern "C" {
#endif

volatile uint32_t us_time = 0;
volatile uint32_t ms_time = 0;

void TIMER1_isr(){

	uint32_t us_time_unit;
        uint32_t ms_time_unit;

	TIMER1_INT_CLEAR();

        /* Timer overflow, add time period to global timer counter */
        us_time_unit = MB_UCLK / 1000000;
        us_time += 0x0fffffff / us_time_unit;

        ms_time_unit = MB_UCLK / 1000;
        ms_time += 0x0fffffff / ms_time_unit;

}

void TIMER1_init(void) {

	TIMER_RegisterCallback(TIMER1,TIMER1_isr);
	ms_time = 0;
	us_time = 0;
	TIMER_Init(CH0,TIMER_32,0,0,0x0fffffff);
}

uint32_t us_ticker_read(void) {

	uint32_t tm1_cntr;
	uint32_t us_time_unit;
	us_time_unit = MB_UCLK / 1000000;
	tm1_cntr = (PIT->CHANNEL[0].RELOAD - PIT->CHANNEL[0].COUNTER) / us_time_unit;

	return tm1_cntr;

}

void delay(uint32_t ms) {

	volatile uint32_t start;
	start = millis();
	while ((millis() - start) < ms);

}

uint32_t millis( void ) {

	uint32_t ms_time_tmp;
	ms_time_tmp = (uint32_t) us_ticker_read() / 1000;
	return ms_time + ms_time_tmp;

}

uint32_t micros( void ) {

	uint32_t us_time_tmp;
	us_time_tmp = (uint32_t) us_ticker_read();
	return us_time + us_time_tmp;

}

void delayMicroseconds(uint32_t usec) {

	volatile uint32_t start;
	start = micros();
	while ((micros() - start) < usec);

}
#ifdef __cplusplus
}
#endif
