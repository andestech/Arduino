#ifndef WIRING_DIGITAL_H
#define WIRING_DIGITAL_H

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

#include "f1_ae210_gpio.h"

typedef enum{
	INPUT,
	OUTPUT,
	INPUT_PULLUP
}IO_TYPE;

/* Digital I/O */
void pinMode( int pin, IO_TYPE mode );
void digitalWrite( int pin, int value );
int digitalRead(int pin);

/* F1 GPIO pin names. */
typedef enum {
	D0 = 0,
	D1,
	D2,
	D3,
	D4,
	D5,
	D6,
	D7,
	D8,
	D9,
	D10,
	D11,
	D12,
	D13,
	D14,
	D15,
	BT1,
	BT2,
	BT3,
	BT4,
	LED1,
	LED2,
	LED3,
	LED4,
	PIN_NUM
}PinName;

extern int pinMap[PIN_NUM];

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus


#endif //WIRING_DIGITAL_H
