#ifndef WIRING_SHIFT_H
#define WIRING_SHIFT_H
#include "typedef.h"

typedef enum{
	LSBFIRST = 0,
	MSBFIRST
}BIT_ORDER;


uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder);
void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val);

#endif //WIRING_SHIFT_H
