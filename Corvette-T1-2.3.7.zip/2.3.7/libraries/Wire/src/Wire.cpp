/*
  TwoWire.cpp - TWI/I2C library for Wiring & Arduino
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "Wire.h"
#include "typedef.h"

extern "C" {
#include "i2c.h"
}

#define I2C_STANDARD_CLK          100000 // i2c clock 400K.
#define I2C_FASTMODE_CLK          400000 // i2c clock 400K.
#define RX_FIFO_SIZE              4
#define SUBORDINATE_BUF_SIZE      16
#define I2C_IP_NUMBER             1

volatile uint8_t rx_read_index = 0;
volatile uint8_t subordinate_rx_buff[BUFFER_LENGTH];

TwoWire Wire;
static TwoWire* WireArray[2] = {NULL, &Wire};

static bool pinMuxCheckAndSet(uint8_t pinindex, PinFunction pin_function)
{
	int pin_usage = pinMuxCheckUsage(pinindex);

	if (pin_usage == PINMUX_FUNC_UNUSED) {
		int err = pinMuxSet(pinindex, pin_function);
		if (err)
			return false;
	}
	else if (pin_usage != pin_function) {
		// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
		return false;
	}

	return true;
}

static bool i2cSetPinMux(uint8_t ip_num)
{
	I2cPins i2c_pins = i2cIpToPins(ip_num);

	if (pinSupportPinMux(i2c_pins.sda)) {
		if (!pinMuxCheckAndSet(i2c_pins.sda, PINMUX_FUNC_I2C)) {
			return false;
		}
	}
	if (pinSupportPinMux(i2c_pins.scl)) {
		if (!pinMuxCheckAndSet(i2c_pins.scl, PINMUX_FUNC_I2C)) {
			return false;
		}
	}

	return true;
}

void TwoWire::begin(void)
{
	bool flag = i2cSetPinMux(I2C_IP_NUMBER);

	if (flag == true) {

		// Init buffer index
		rxBufferIndex = 0;
		rxBufferLength = 0;
		txBufferIndex = 0;
		txBufferLength = 0;

		// Manager mode
		manager_subordinate = 1;

		// Set pin, manager init and set I2C clock
		i2c_set_pin(I2C_GPIO_SDA_C2,I2C_GPIO_SCL_C1);
		i2c_manager_init();
		i2c_set_manager_clk((unsigned char)(PCLKFREQ/(4*I2C_STANDARD_CLK)));
	}
}

void TwoWire::begin(uint8_t address)
{
	unsigned char id = (address << 1);  // Shift 1 bit for telink setting id

	bool flag = i2cSetPinMux(I2C_IP_NUMBER);

	if (flag == true) {

		// Init buffer index
		rxBufferIndex = 0;
		rxBufferLength = 0;
		txBufferIndex = 0;
		txBufferLength = 0;

		// Subordinate mode
		manager_subordinate = 0;

		// Set pin, subordinate init and enable RX_BUF, RX_DONE ISR
		i2c_set_pin(I2C_GPIO_SDA_C2,I2C_GPIO_SCL_C1);
		i2c_subordinate_init(id);
		i2c_set_irq_mask(static_cast<i2c_irq_mask_e>(I2C_RX_BUF_MASK|I2C_RX_DONE_MASK));
		i2c_rx_irq_trig_cnt(RX_FIFO_SIZE);
		plic_interrupt_enable(IRQ21_I2C);
	}
}

void TwoWire::begin(int address)
{
	begin((uint8_t)address);
}

void TwoWire::end(void)
{
  ;
}

void TwoWire::setClock(uint32_t frequency)
{
	// Telink I2C module supports standard mode (100kbps) and Fast-mode (400kbps)
	if ((frequency == I2C_STANDARD_CLK) || (frequency == I2C_FASTMODE_CLK)) {
		i2c_set_manager_clk((unsigned char)(PCLKFREQ/(4*frequency)));
	}
}

void TwoWire::setWireTimeout(uint32_t timeout, bool reset_on_timeout)
{
	i2c_set_timeout(timeout, reset_on_timeout);
}

bool TwoWire::getWireTimeoutFlag(void)
{
	return i2c_get_timeout_flag();
}

void TwoWire::clearWireTimeoutFlag(void)
{
	i2c_clear_timeout_flag();
}

uint8_t TwoWire::requestFrom(uint8_t address, size_t quantity, uint8_t sendStop)
{
	uint8_t read_num;
	unsigned char id = (address << 1);  // Shift 1 bit for telink setting id

	// clamp to buffer length
	if(quantity > BUFFER_LENGTH){
		quantity = BUFFER_LENGTH;
	}

	// clear rx FIFO
	i2c_clr_fifo(I2C_RX_BUFF_CLR);

	// if not sendStop, it must send restart flag
	send_restart = (sendStop ? 0 : 1);

	// perform blocking read into buffer
	read_num =  i2c_manager_read_config(id, rxBuffer, quantity, send_start, sendStop, send_restart);

	// if send restart, do not send start next time
	send_start = (send_restart ? 0 : 1);

	// set rx buffer iterator vars
	rxBufferIndex = 0;
	rxBufferLength = read_num;

	return read_num;
}

uint8_t TwoWire::requestFrom(uint8_t address, size_t quantity)
{
	return requestFrom((uint8_t)address, (size_t)quantity, (uint8_t)true);
}

uint8_t TwoWire::requestFrom(uint8_t address, int quantity)
{
	return requestFrom((uint8_t)address, (size_t)quantity, (uint8_t)true);
}

uint8_t TwoWire::requestFrom(int address, int quantity)
{
	return requestFrom((uint8_t)address, (size_t)quantity, (uint8_t)true);
}

uint8_t TwoWire::requestFrom(int address, unsigned int quantity)
{
	return requestFrom((uint8_t)address, (size_t)quantity, (uint8_t)true);
}

uint8_t TwoWire::requestFrom(int address, int quantity, int sendStop)
{
	return requestFrom((uint8_t)address, (size_t)quantity, (uint8_t)sendStop);
}

void TwoWire::beginTransmission(uint8_t address)
{
	// indicate that we are transmitting
	manager_transmitting = 1;

	// set address of targeted subordinate
	txAddress = address;

	// reset tx buffer iterator vars
	txBufferIndex = 0;
	txBufferLength = 0;
}

void TwoWire::beginTransmission(int address)
{
	beginTransmission((uint8_t)address);
}

//
//	Originally, 'endTransmission' was an f(void) function.
//	It has been modified to take one parameter indicating
//	whether or not a STOP should be performed on the bus.
//	Calling endTransmission(false) allows a sketch to
//	perform a repeated start.
//
//	WARNING: Nothing in the library keeps track of whether
//	the bus tenure has been properly ended with a STOP. It
//	is very possible to leave the bus in a hung state if
//	no call to endTransmission(true) is made. Some I2C
//	devices will behave oddly if they do not see a STOP.
//
uint8_t TwoWire::endTransmission(uint8_t sendStop)
{
	// transmit buffer (blocking)
	unsigned char id = (txAddress << 1);  // Shift 1 bit for telink setting id

	// if not sendStop, it must send restart flag
	send_restart = (sendStop ? 0 : 1);

	// perform blocking write into buffer
	uint8_t ret = i2c_manager_write_config(id,(unsigned char *)txBuffer, txBufferLength, send_start, sendStop, send_restart);

	// if send restart, do not send start next time
	send_start = (send_restart ? 0 : 1);

	// reset tx buffer iterator vars
	txBufferIndex = 0;
	txBufferLength = 0;

	// indicate that we are done transmitting
	manager_transmitting = 0;

	return ret;
}

//	This provides backwards compatibility with the original
//	definition, and expected behaviour, of endTransmission
//
uint8_t TwoWire::endTransmission(void)
{
	return endTransmission(true);
}

// must be called in:
// subordinate tx event callback
// or after beginTransmission(address)
size_t TwoWire::write(uint8_t data)
{
	size_t write_cnt = 0;

	if (manager_transmitting) {

		// in manager transmitter mode
		// don't bother if buffer is full
		if(txBufferLength > BUFFER_LENGTH) {
			//setWriteError();
			write_cnt = 0;
		}

		// put byte in tx buffer
		txBuffer[txBufferIndex] = data;
		++txBufferIndex;

		// update amount in buffer
		txBufferLength = txBufferIndex;
		write_cnt = 1;

	} else if (manager_subordinate == 0) {

		// in subordinate send mode
		// reply to manager
		i2c_subordinate_write(&data, 1);
		write_cnt = 1;

	}

	return write_cnt;
}

// must be called in:
// subordinate tx event callback
// or after beginTransmission(address)
size_t TwoWire::write(const uint8_t *data, size_t quantity)
{
	size_t write_cnt = 0;
	if (manager_transmitting) {

		// in manager transmitter mode
		for(size_t i = 0; i < quantity; ++i){
			write_cnt += write(data[i]);
		}

	} else if (manager_subordinate == 0) {

		// in subordinate send mode
		// reply to manager
		i2c_subordinate_write((unsigned char*)data, quantity);
		write_cnt = quantity;

	}

	return write_cnt;
}

// must be called in:
// subordinate rx event callback
// or after requestFrom(address, numBytes)
int TwoWire::available(void)
{
	return (rxBufferLength - rxBufferIndex);
}

// must be called in:
// subordinate rx event callback
// or after requestFrom(address, numBytes)
int TwoWire::read(void)
{
	int value = -1;

	// get each successive byte on each call
	if(rxBufferIndex < rxBufferLength) {
		value = rxBuffer[rxBufferIndex];
		++rxBufferIndex;
	}

	return value;
}

// must be called in:
// subordinate rx event callback
// or after requestFrom(address, numBytes)
int TwoWire::peek(void)
{
	int value = -1;

	if(rxBufferIndex < rxBufferLength) {
		value = rxBuffer[rxBufferIndex];
	}

	return value;
}

void TwoWire::flush(void)
{
	// XXX: to be implemented.
}

// behind the scenes function that is called when data is received
void TwoWire::onReceiveService(uint8_t* inBytes, int numBytes, uint8_t ip_num)
{
	TwoWire* pthis = WireArray[ip_num];

	// don't bother if user hasn't registered a callback
	if(!pthis->user_onReceive) {
		return;
	}

	// don't bother if rx buffer is in use by a manager requestFrom() op
	// i know this drops data, but it allows for slight stupidity
	// meaning, they may not have read all the manager requestFrom() data yet
	if(pthis->rxBufferIndex < pthis->rxBufferLength) {
		return;
	}

	// copy twi rx buffer into local read buffer
	// this enables new reads to happen in parallel
	for(uint8_t i = 0; i < numBytes; ++i) {
		pthis->rxBuffer[i] = inBytes[i];
	}

	// set rx iterator vars
	pthis->rxBufferIndex = 0;
	pthis->rxBufferLength = numBytes;

	// alert user program
	pthis->user_onReceive(numBytes);
}

// behind the scenes function that is called when data is requested
void TwoWire::onRequestService(uint8_t ip_num)
{
	TwoWire* pthis = WireArray[ip_num];

	// don't bother if user hasn't registered a callback
	if(!pthis->user_onRequest) {
		return;
	}

	// reset tx buffer iterator vars
	// !!! this will kill any pending pre-manager sendTo() activity
	pthis->txBufferIndex = 0;
	pthis->txBufferLength = 0;

	// alert user program
	pthis->user_onRequest();
}

// sets function called on subordinate write
void TwoWire::onReceive( void (*function)(int) )
{
	user_onReceive = function;
}

// sets function called on subordinate read
void TwoWire::onRequest( void (*function)(void) )
{
	user_onRequest = function;
}

void i2c_irq_handler(void)
{
	if (i2c_get_irq_status(I2C_RX_BUF_STATUS)) {

		// rx FIFO exceed threshold
		uint8_t read_size = SUBORDINATE_BUF_SIZE - rx_read_index;

		// Make sure received data not exceed rx buffer size
		read_size = ((read_size > RX_FIFO_SIZE) ? RX_FIFO_SIZE : read_size);

		// Received data from rx FIFO
		i2c_subordinate_read((unsigned char*)(subordinate_rx_buff+rx_read_index), read_size);
		rx_read_index += read_size;

		if (rx_read_index >= SUBORDINATE_BUF_SIZE) {
			// rx buffer is full, call the callback to user
			Wire.onReceiveService((uint8_t*)subordinate_rx_buff, rx_read_index, I2C_IP_NUMBER);
			rx_read_index = 0;
		}
	}

	if ((i2c_get_irq_status(I2C_RXDONE_STATUS))) {
		// when SUBORDINATE_BUF_SIZE % RX_FIFO_SIZE =0,it can not enter rx_done irq.

		// rx buffer remained size
		uint8_t read_size = SUBORDINATE_BUF_SIZE - rx_read_index;

		// rx FIFO received data size
		uint8_t recv_size = i2c_get_rx_buf_cnt();
		read_size = ((read_size > recv_size) ? recv_size : read_size);

		// Received data from rx FIFO
		i2c_subordinate_read((unsigned char*)(subordinate_rx_buff+rx_read_index), read_size);
		rx_read_index += read_size;

		// Clear FIFO after Stop flag
		i2c_clr_fifo(I2C_RX_BUFF_CLR);

		// Receive stop flag, call the callback to user
		Wire.onReceiveService((uint8_t*)subordinate_rx_buff, rx_read_index, I2C_IP_NUMBER);
		rx_read_index = 0;
	}
}
