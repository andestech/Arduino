#include "Arduino.h"
#include "wiring.h"
#include "wiring_tone.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "pwm.h"

#define PWM_PCLK_SPEED      12000000 //pwm clock 12M.
#define PWM_MAX_PERIOD      (0xFFFF)
#define MAX_TONE_CONCURRENT 5

typedef struct {
	GpioPin pin;
	uint32_t timer_overflow;
	uint32_t tick;
} ToneReq;

struct _ToneReqList {
	int request_num;
	int pend_request_num;
	ToneReq requests[MAX_TONE_CONCURRENT];
	ToneReq pend_requests[MAX_TONE_CONCURRENT]; // Pending Requests: requests occur after timer overflow.
	bool pin_has_request[GPIO_PIN_NUM];

	_ToneReqList() {
		this->request_num = 0;
		this->pend_request_num = 0;
		for (int i = 0; i < GPIO_PIN_NUM; ++i) {
			pin_has_request[i] = false;
		}
	}
};

struct _ToneReqList ToneReqList;

static void toneReqDel(GpioPin pin);

void toneTimerInit()
{
	plic_interrupt_enable(IRQ3_TIMER1);
	timer_set_init_tick(TIMER1, 0);
	timer_set_cap_tick(TIMER1, TIMER_OVERFLOW_TICK);
	timer_set_mode(TIMER1, TIMER_MODE_SYSCLK);
	timer_start(TIMER1);
}

/*
 * Note: toneReq{Add*|Del*|Remove*}() functions should be called when disabling IRQ.
 */

static void toneReqAdd(GpioPin pin, uint32_t tick)
{
	uint8_t pinindex = GpioPinToPinIndex(pin);

	if (ToneReqList.request_num >= MAX_TONE_CONCURRENT)
		return;

	if (ToneReqList.pin_has_request[pinindex]) {
		toneReqDel(pin);
		ToneReqList.pin_has_request[pinindex] = false;
	}

	int num = ToneReqList.request_num;

	ToneReqList.requests[num].pin = pin;
	ToneReqList.requests[num].timer_overflow = 0;
	ToneReqList.requests[num].tick = tick;
	ToneReqList.request_num++;
	ToneReqList.pin_has_request[pinindex] = true;
}

static void tonePendReqAdd(GpioPin pin, uint32_t timer_overflow, uint32_t tick)
{
	uint8_t pinindex = GpioPinToPinIndex(pin);

	if (ToneReqList.pend_request_num >= MAX_TONE_CONCURRENT)
		return;

	if (ToneReqList.pin_has_request[pinindex]) {
		toneReqDel(pin);
	}

	int num = ToneReqList.pend_request_num;

	ToneReqList.pend_requests[num].pin = pin;
	ToneReqList.pend_requests[num].timer_overflow = timer_overflow;
	ToneReqList.pend_requests[num].tick = tick;
	ToneReqList.pend_request_num++;
	ToneReqList.pin_has_request[pinindex] = true;
}

static void toneReqRemoveIndex(int index)
{
	int pinindex = ToneReqList.requests[index].pin;

	for (int i = index; i < (ToneReqList.request_num-1); ++i) {
		ToneReqList.requests[i] = ToneReqList.requests[i+1];
	}
	ToneReqList.request_num--;
	ToneReqList.pin_has_request[pinindex] = false;
}

static void tonePendReqRemoveIndex(int index)
{
	int pinindex = ToneReqList.pend_requests[index].pin;

	for (int i = index; i < (ToneReqList.request_num-1); ++i) {
		ToneReqList.pend_requests[i] = ToneReqList.pend_requests[i+1];
	}
	ToneReqList.pend_request_num--;
	ToneReqList.pin_has_request[pinindex] = false;
}

/*
 * toneRelDel(): Delete request or pending request with this pin
 */
static void toneReqDel(GpioPin pin)
{
	uint8_t pinindex = GpioPinToPinIndex(pin);

	if (ToneReqList.request_num == 0)
		return;

	if (!ToneReqList.pin_has_request[pinindex])
		return;

	bool req_deleted = false;

	for (int i = 0; i < ToneReqList.request_num; ++i) {
		if (ToneReqList.requests[i].pin == pin) {
			toneReqRemoveIndex(i);

			req_deleted = true;
			break;
		}
	}

	if (!req_deleted) {
		for (int i = 0; i < ToneReqList.pend_request_num; ++i) {
			if (ToneReqList.pend_requests[i].pin == pin) {
				tonePendReqRemoveIndex(i);

				break;
			}
		}
	}
}

/*
 * toneReqDelAll(): Delete all request (not including pending request)
 */
static void toneReqDelAll()
{
	for (int i = 0; i < ToneReqList.request_num; ++i) {
		uint8_t pinindex = GpioPinToPinIndex(ToneReqList.requests[i].pin);
		ToneReqList.pin_has_request[pinindex] = false;
	}

	ToneReqList.request_num = 0;
}

_attribute_ram_code_sec_ void timer1_irq_handler(void)
{
	if(timer_get_irq_status(TMR_STA_TMR1))
	{
		timer_clr_irq_status(TMR_STA_TMR1);
		// Disable timer by default.
		timer_stop(TIMER1);

		// Timer1 overfolw
		if (ToneReqList.request_num == 0) {
			if (ToneReqList.request_num != 0) {
				// Invalid condition, there should be no request if Timer1 occurs overflow.
				// Clear all requests.
				for (int i = 0; i < ToneReqList.request_num; ++i) {
					pwm_id_e pwm_id = static_cast<pwm_id_e>(get_pwmid(static_cast<pwm_pin_e>(ToneReqList.requests[i].pin)));
					pwm_stop(pwm_id);
				}
				toneReqDelAll();
			}

			if (ToneReqList.pend_request_num != 0) {
				// Decrements all pending request's timer_overflow, and move requests before next timer_overflow to non-pending request.
				for (int i = 0; i < ToneReqList.pend_request_num; ++i) {
					ToneReqList.pend_requests[i].timer_overflow--;

					if (ToneReqList.pend_requests[i].timer_overflow == 0) {
						ToneReq request = ToneReqList.pend_requests[i];
						toneReqDel(ToneReqList.pend_requests[i].pin);
						toneReqAdd(request.pin, request.tick);
					}
				}
			}
		} else {
			// Trigger by timeout pin
			ToneReq timeout_req = ToneReqList.requests[0];

			// disable tone()'s PWM.
			pwm_id_e pwm_id = static_cast<pwm_id_e>(get_pwmid(static_cast<pwm_pin_e>(timeout_req.pin)));
			pwm_stop(pwm_id);

			// remove from request list
			toneReqDel(timeout_req.pin);

			// For each timeout requests, disable PWM + remove from request list
			while (ToneReqList.request_num != 0) {
				ToneReq next_req = ToneReqList.requests[0];
				uint32_t current_tick = timer1_get_tick();

				if (next_req.tick < current_tick) {
					pwm_id = static_cast<pwm_id_e>(get_pwmid(static_cast<pwm_pin_e>(next_req.pin)));
					pwm_stop(pwm_id);
					toneReqDel(next_req.pin);
				}
				else {
					// No timeout requests.
					break;
				}
			}
		}

		// No request.
		if (ToneReqList.request_num == 0) {
			// Set timeout to overflow
			timer_set_cap_tick(TIMER1, TIMER_OVERFLOW_TICK);
		} else {
			// Set the next pin timeout
			ToneReq next_req = ToneReqList.requests[0];
			uint32_t current_tick = timer1_get_tick();

			if (next_req.tick < current_tick) {
				timer_set_cap_tick(TIMER1, 1);
			}
			else {
				timer_set_cap_tick(TIMER1, (next_req.tick - current_tick));
			}
		}

		timer_start(TIMER1);
	}
}


static void addToneReqDuration(GpioPin pin, unsigned long duration)
{
	volatile uint32_t current_tick = timer1_get_tick();
	volatile uint64_t duration_tick = ((uint64_t)duration) * PCLKFREQ / 1000 + current_tick;
	uint32_t timer_overflow = duration_tick / TIMER_OVERFLOW_TICK;
	duration_tick = duration_tick % TIMER_OVERFLOW_TICK;

	// tone() is disabled
	timer_stop(TIMER1);

	if (timer_overflow != 0) {
		// tone() is disabled
		tonePendReqAdd(pin, timer_overflow, duration_tick);
		timer_start(TIMER1);
		return;
	}

	if (ToneReqList.request_num == 0) {
		timer_set_cap_tick(TIMER1, duration_tick);
	} else {
		ToneReq next_req = ToneReqList.requests[0];
		if (duration_tick < next_req.tick) {
			timer_set_cap_tick(TIMER1, duration_tick);
		}
	}
	toneReqAdd(pin, duration_tick);
	timer_start(TIMER1);
}

void tone(uint8_t pin, unsigned int frequency, unsigned long duration)
{
	/* Supported frequency range: 1Hz ~ 20MHz(PCLKFREQ/2).
	 *
	 * Arduino Uno's guaranteed frequency range is 31Hz ~ 4MHz.
	 * ref: https://github.com/bhagman/Tone#ugly-details
	 */
	if (frequency == 0)
		return;

	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);
	uint8_t pinindex = GpioPinToPinIndex(gpio_pin);

	if (pinSupportPinMux(pinindex)) {
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(pinindex, PINMUX_FUNC_PWM);
			if (err)
				return;
		}
		else if (pin_usage != PINMUX_FUNC_PWM) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}

	uint32_t pwm_period = PWM_PCLK_SPEED / frequency;
	if (pwm_period > PWM_MAX_PERIOD) {
		return;
	}

	pwm_id_e pwm_id = static_cast<pwm_id_e>(get_pwmid(static_cast<pwm_pin_e>(gpio_pin)));
	pwm_set_pin(static_cast<pwm_pin_e>(gpio_pin));
	pwm_set_clk((unsigned char) ((PCLKFREQ/PWM_PCLK_SPEED)-1));
	pwm_set_tcmp(pwm_id,(pwm_period/2));
	pwm_set_tmax(pwm_id,pwm_period);
	pwm_set_pwm0_mode(PWM_NORMAL_MODE);
	pwm_start(pwm_id);

	if (duration != 0) {
		// Turn off PWM in Timer ISR triggered after duration ms.
		addToneReqDuration(gpio_pin, duration);
	}
}

void noTone(uint8_t pin)
{
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)pin);
	uint8_t pinindex = GpioPinToPinIndex(gpio_pin);
	if (pinSupportPinMux(pinindex)) {
		int pin_usage = pinMuxCheckUsage(pinindex);

		if (pin_usage != PINMUX_FUNC_PWM)
			return;
	}

	pwm_id_e pwm_id = static_cast<pwm_id_e>(get_pwmid(static_cast<pwm_pin_e>(gpio_pin)));
	pwm_stop(pwm_id);

	timer_stop(TIMER1);

	if (ToneReqList.pin_has_request[pinindex]) {
		toneReqDel(gpio_pin);
	}

	timer_start(TIMER1);
}
