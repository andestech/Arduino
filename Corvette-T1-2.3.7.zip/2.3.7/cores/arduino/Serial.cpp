#include "Serial.h"
#include "arduino_pin.h"
#include "pinmux.h"

static UART_RCV_SEND_QUEUE *puartCh1, uartCh1={{0}, {0}, 0, 0, 0, 0};
static UART_RCV_SEND_QUEUE *puartCh0, uartCh0={{0}, {0}, 0, 0, 0, 0};

// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
void serialEvent() __attribute__((weak));
void serialEvent1() __attribute__((weak));

Uart::Uart(unsigned int UARTNUM)
{
	uartnum = UARTNUM;
}

void Uart::begin(unsigned long baud)
{
	begin(baud, SERIAL_8N1);
}

void Uart::begin(unsigned long baud, uint16_t config)
{
	uint8_t rx_pin = 0, tx_pin = 0;
	unsigned short div;
	unsigned char bwpc;

	u8 UART_DRV_STOPBITS = (u8) (config & 0xf);
	u8 UART_DRV_PARITY = (u8) ((config >> 4) & 0xf);

	uart_parity_e parity_arrar[4] = {UART_PARITY_NONE, UART_PARITY_ODD, UART_PARITY_NONE, UART_PARITY_EVEN};
	uart_stop_bit_e stopbit_array[2] = {UART_STOP_BIT_ONE, UART_STOP_BIT_TWO};

	if (static_cast<uart_num_e>(uartnum) == UART1) {
		uartCh1 = {{0}, {0}, 0, 0, 0, 0};
		uart_set_pin(UART1_TX_PC6,UART1_RX_PC7);
	} else if (static_cast<uart_num_e>(uartnum) == UART0) {
		uartCh0 = {{0}, {0}, 0, 0, 0, 0};
		uart_set_pin(UART0_TX_PB2,UART0_RX_PB3);
	}

	uart_reset(static_cast<uart_num_e>(uartnum));
	uart_clr_tx_index(static_cast<uart_num_e>(uartnum));
	uart_cal_div_and_bwpc(baud, PCLKFREQ, &div, &bwpc);
	uart_init(static_cast<uart_num_e>(uartnum), div, bwpc, parity_arrar[UART_DRV_PARITY], stopbit_array[UART_DRV_STOPBITS]);
	uart_tx_irq_trig_level(static_cast<uart_num_e>(uartnum), 0);
	uart_rx_irq_trig_level(static_cast<uart_num_e>(uartnum), 1);

	uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_RX_IRQ_MASK|UART_ERR_IRQ_MASK));

	if (static_cast<uart_num_e>(uartnum) == UART1) {
		plic_interrupt_enable(IRQ18_UART1); //if you want to use UART1,the parameter is - IRQ18_UART1
		// PinMux config
		rx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D0));
		tx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D1));

		puartCh1 = &uartCh1;
	} else if (static_cast<uart_num_e>(uartnum) == UART0) {
		plic_interrupt_enable(IRQ19_UART0); //if you want to use UART0,the parameter is - IRQ19_UART0
		// PinMux config
		rx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(A4));
		tx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(A5));

		puartCh0 = &uartCh0;
	}

	if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UART)
		pinMuxSet(rx_pin, PINMUX_FUNC_UART);
	if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UART)
		pinMuxSet(tx_pin, PINMUX_FUNC_UART);

	begin_flag = 1;
}

void Uart::end()
{
	uint8_t rx_pin = 0, tx_pin = 0;

	if(!begin_flag)
		return;

	begin_flag = 0;

	uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK|UART_RX_IRQ_MASK|UART_ERR_IRQ_MASK));

	if (static_cast<uart_num_e>(uartnum) == UART1) {
		plic_interrupt_disable(IRQ18_UART1); //if you want to use UART1,the parameter is - IRQ18_UART1
		rx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D0));
		tx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(D1));
	} else if (static_cast<uart_num_e>(uartnum) == UART0) {
		plic_interrupt_disable(IRQ19_UART0); //if you want to use UART0,the parameter is - IRQ19_UART0
		rx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(A4));
		tx_pin = GpioPinToPinIndex(arduinoPinToGpioPin(A5));
	}

	uart_reset(static_cast<uart_num_e>(uartnum));
	uart_clr_tx_index(static_cast<uart_num_e>(uartnum));

	// Reset the software flag for the next pin application
	if (pinMuxCheckUsage(rx_pin) == PINMUX_FUNC_UNUSED)
		pinMuxReset(rx_pin, PINMUX_FUNC_UART);
	if (pinMuxCheckUsage(tx_pin) == PINMUX_FUNC_UNUSED)
		pinMuxReset(tx_pin, PINMUX_FUNC_UART);
}

int Uart::available(void)
{
	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

 	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	if(!begin_flag)
		return 0;

	return (tUartCh->uartRcvTail < tUartCh->uartRcvHead) ? ((tUartCh->uartRcvTail-tUartCh->uartRcvHead) + UART_MAX_BUF_SIZ)	\
		:(tUartCh->uartRcvTail - tUartCh->uartRcvHead) ;
}

int Uart::read(void)
{
	if(!begin_flag)
		return -1;

	if(available()) {
		volatile char ch = ' ';
		UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

		if (static_cast<uart_num_e>(uartnum) == UART0) {
			tUartCh = puartCh0;
		}

		ch=tUartCh->uartRcvBuf[tUartCh->uartRcvHead];

		if(++tUartCh->uartRcvHead == UART_MAX_BUF_SIZ)
			tUartCh->uartRcvHead = 0;

		return (int)ch;
	} else {
		return -1;
	}
}

size_t Uart::write(uint8_t c)
{
	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	if(!begin_flag)
		return 1;

	// If THR is empty, we write data to THR directly.
	if((tUartCh->uartSendTail == tUartCh->uartSendHead) && (!uart_tx_is_busy(static_cast<uart_num_e>(uartnum)))) {
		uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		uart_send_byte(static_cast<uart_num_e>(uartnum), c);
	} else {
		// If the transmission buffer is full, we have to consume an old data befor enqueue the new data
		while( ((tUartCh->uartSendTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartSendHead) {
			uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
			while (uart_tx_is_busy(static_cast<uart_num_e>(uartnum)));
			uart_send_byte(static_cast<uart_num_e>(uartnum), tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
			uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
			if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
				tUartCh->uartSendHead = 0;
		}
		// Enqueue the new data
		tUartCh->uartSendBuf[tUartCh->uartSendTail++] = c;

		if(tUartCh->uartSendTail == UART_MAX_BUF_SIZ)
			tUartCh->uartSendTail = 0;

		uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
	}

	return 1;
}

size_t Uart::write(const uint8_t *buffer, size_t size)
{
	size_t len = size;

	if(!begin_flag)
		return size;

	while (len--) {
		UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

		if (static_cast<uart_num_e>(uartnum) == UART0) {
			tUartCh = puartCh0;
		}

		// If THR is empty, we write data to THR directly.
		if((tUartCh->uartSendTail == tUartCh->uartSendHead) && (!uart_tx_is_busy(static_cast<uart_num_e>(uartnum)))){
			uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
			uart_send_byte(static_cast<uart_num_e>(uartnum), *buffer);
		} else {
			// If the transmission buffer is full, we have to consume an old data befor enqueue the new data
			while( ((tUartCh->uartSendTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartSendHead) {
				uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
				while (uart_tx_is_busy(static_cast<uart_num_e>(uartnum)));
				uart_send_byte(static_cast<uart_num_e>(uartnum), tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
				uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
				if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
					tUartCh->uartSendHead = 0;
			}
			// Enqueue the new data
			tUartCh->uartSendBuf[tUartCh->uartSendTail++] = *buffer;

			if(tUartCh->uartSendTail == UART_MAX_BUF_SIZ)
				tUartCh->uartSendTail = 0;

			uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		}
		buffer++;
	}

	return size;
}

int Uart::peek(void)
{
	if(!begin_flag)
		return -1;

	if(available()) {
		UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

 		if (static_cast<uart_num_e>(uartnum) == UART0) {
			tUartCh = puartCh0;
		}
		return (int)(tUartCh->uartRcvBuf[tUartCh->uartRcvHead]);
	}
	else
		return -1;
}

void Uart::flush()
{
	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	if(!begin_flag)
		return;

	uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
	u32 len = (tUartCh->uartSendTail >= tUartCh->uartSendHead)?(tUartCh->uartSendTail-tUartCh->uartSendHead)	\
		:(tUartCh->uartSendTail-tUartCh->uartSendHead)+UART_MAX_BUF_SIZ;

	while(len) {
		while (uart_tx_is_busy(static_cast<uart_num_e>(uartnum)));
		uart_send_byte(static_cast<uart_num_e>(uartnum), tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
		len--;
		if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
			tUartCh->uartSendHead = 0;
	}
	while (uart_tx_is_busy(static_cast<uart_num_e>(uartnum)));
}

int Uart::availableForWrite() {

	unsigned int len;
	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	if(!begin_flag)
		return 0;

	uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
	len = (tUartCh->uartSendTail >= tUartCh->uartSendHead)?(tUartCh->uartSendTail-tUartCh->uartSendHead)	\
		:(tUartCh->uartSendTail-tUartCh->uartSendHead)+UART_MAX_BUF_SIZ;

	if (len)
		uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));

	return len;
}

void arduino::serialEventRun(void)
{
	if (Serial && serialEvent && Serial.available()) serialEvent();

	if (Serial1 && serialEvent1 && Serial1.available()) serialEvent1();
}

void Uart::insertRcvData(char* buffer, unsigned int len) {

	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	for(unsigned int i=0; i<len; i++) {
		tUartCh->uartRcvBuf[tUartCh->uartRcvTail++] = *buffer++;

		if(tUartCh->uartRcvTail == UART_MAX_BUF_SIZ)
			tUartCh->uartRcvTail = 0;
	}
}

void Uart::insertSendData(char* buffer, unsigned int len) {

	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));

	for(unsigned int i=0; i<len; i++) {
		tUartCh->uartSendBuf[tUartCh->uartSendTail++] = *buffer++;

		if(tUartCh->uartSendTail == UART_MAX_BUF_SIZ)
			tUartCh->uartSendTail = 0;
	}

	uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
}

void uart_irq_handler(unsigned int uartnum)
{
	UART_RCV_SEND_QUEUE *tUartCh = puartCh1;

	if (static_cast<uart_num_e>(uartnum) == UART0) {
		tUartCh = puartCh0;
	}

	if(uart_get_irq_status(static_cast<uart_num_e>(uartnum), UART_RX_ERR)) {
		uart_clr_irq_status(static_cast<uart_num_e>(uartnum),UART_CLR_RX);// it will clear rx_fifo and rx_err_irq ,rx_buff_irq,so it won't enter rx_buff interrupt.
		uart_reset(static_cast<uart_num_e>(uartnum)); //clear hardware pointer
		uart_clr_rx_index(static_cast<uart_num_e>(uartnum)); //clear software pointer
	}
	if(uart_get_irq_status(static_cast<uart_num_e>(uartnum), UART_RXBUF_IRQ_STATUS)) {
		unsigned int isFull = ((tUartCh->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartRcvHead ? 1 : 0;
		if(!isFull) {
			tUartCh->uartRcvBuf[tUartCh->uartRcvTail++] = uart_read_byte(static_cast<uart_num_e>(uartnum));
			if(tUartCh->uartRcvTail == UART_MAX_BUF_SIZ)
				tUartCh->uartRcvTail = 0;
		}
		else {
			uart_read_byte(static_cast<uart_num_e>(uartnum));
		}
	}
	if(uart_get_irq_status(static_cast<uart_num_e>(uartnum), UART_TXBUF_IRQ_STATUS)) {
		uart_clr_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		if(tUartCh->uartSendTail != tUartCh->uartSendHead) {
			uart_send_byte(static_cast<uart_num_e>(uartnum), tUartCh->uartSendBuf[tUartCh->uartSendHead++]);
			if(tUartCh->uartSendHead == UART_MAX_BUF_SIZ)
				tUartCh->uartSendHead = 0;
		}
		if(tUartCh->uartSendTail != tUartCh->uartSendHead) {
			uart_set_irq_mask(static_cast<uart_num_e>(uartnum), static_cast<uart_irq_mask_e>(UART_TX_IRQ_MASK));
		}
	}
}

void uart1_irq_handler(void)// if you want to use UART1,the function is - uart1_irq_handler()
{
	uart_irq_handler(UART1);
}

void uart0_irq_handler(void)// if you want to use UART0,the function is - uart0_irq_handler()
{
	uart_irq_handler(UART0);
}

Uart Serial(UART1);
Uart Serial1(UART0);
