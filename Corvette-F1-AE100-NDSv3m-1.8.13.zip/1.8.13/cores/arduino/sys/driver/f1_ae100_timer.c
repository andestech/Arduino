/***********************************************************************************************
*   INCLUDES
************************************************************************************************/
#include "f1_ae100_timer.h"
#include "f1_ae100_int.h"
#include "f1_ae100.h"

/***********************************************************************************************
*   Global variable
************************************************************************************************/
DRVTIMER_Callback *gTIMER1Callback;
DRVTIMER_Callback *gTIMER2Callback;
DRVTIMER_Callback *gTIMER3Callback;
DRVTIMER_Callback *gTIMER4Callback;

/***********************************************************************************************
@brief:Init specified Timer,set counter,clk source
@para:
        -u8TimerIdx:specified Timer Index
        -u8ClkSrc: clock source TIMER_CLK_SRC_32K/TIMER_CLK_SRC_APB
        -u32LoadCnt:Load value to counter and Load register
************************************************************************************************/
void TIMER_Init(u8 u8Ch,u8 u8Mode,u8 u8TimerIdx,u8 u8ClkSrc,u32 u32LoadCnt)
{
	PIT->CHANNEL[u8Ch].CTRL &= ~(PIT_CCR_CH_MODE);
	PIT->CHANNEL[u8Ch].CTRL |= u8Mode;

	//Use APB clock
	PIT->CHANNEL[u8Ch].CTRL &= ~(PIT_CCR_CH_CLK);
	PIT->CHANNEL[u8Ch].CTRL |= PIT_CCR_CH_CLK;

	PIT->CHANNEL[u8Ch].RELOAD = u32LoadCnt;

	switch(u8Ch){
	case 0:
		PIT->INTEN |= PIT_IER_CH0INT0EN;
		PIT->CHNEN|=PIT_CER_CH0TMR0EN;
		break;
	case 1:
		PIT->INTEN |= PIT_IER_CH1INT0EN;
		PIT->CHNEN|=PIT_CER_CH1TMR0EN;
		break;
	case 2:
		PIT->INTEN |= PIT_IER_CH2INT0EN;
		PIT->CHNEN|=PIT_CER_CH2TMR0EN;
		break;
	case 3:
		PIT->INTEN |= PIT_IER_CH3INT0EN;
		PIT->CHNEN|=PIT_CER_CH3TMR0EN;
		break;
	}

	INT_IrqEn(1 << IRQ_PIT_INTR, 0, 0);
}

/***********************************************************************************************
@brief:Disable Timer clock
@para:
        -u8TimerIdx:specified Timer
************************************************************************************************/
void TIMER_DeInit(u8 u8Ch,u8 u8TimerIdx)
{

}

/***********************************************************************************************
@brief:Start specified Timer
@para:
        -u8TimerIdx:specified Timer Index
************************************************************************************************/
void TIMER_Start(u8 u8Ch,u8 u8TimerIdx)
{
}

/***********************************************************************************************
@brief:Stop specified Timer
@para:
        -u8TimerIdx:specified Timer Index
************************************************************************************************/
void TIMER_Stop(u8 u8Ch,u8 u8TimerIdx)
{
}

/***********************************************************************************************
@brief:Set Match1 and Match2 of specified Timer
@para:
        -u8TimerIdx:specified Timer Index
        -u32Match1: Match1 value
        -u32Match2: Match2 value
************************************************************************************************/
void TIMER_SetMatchValue(u8 u8Ch,u8 u8TimerIdx,u32 u32Match1,u32 u32Match2)
{
}

/***********************************************************************************************
@brief:Register specified Timer interrupt callback function
@para:
        -u8TimerIdx:specified Timer Index
        -cb: Timer callback function
***********************************************************************************************/
void TIMER_RegisterCallback(u8 u8TimerIdx,DRVTIMER_Callback cb)
{
	if(u8TimerIdx == TIMER1)
		gTIMER1Callback = cb;
	else if(u8TimerIdx == TIMER2)
		gTIMER2Callback = cb;
	else if(u8TimerIdx == TIMER3)
		gTIMER3Callback = cb;
	else
		gTIMER4Callback = cb;
}

/***********************************************************************************************
@brief:Enable specified Timer interrupt  function
@para:
        -u8TimerIdx:specified Timer Index
***********************************************************************************************/
void TIMER_EnableInt(u8 u8Ch,u8 u8TimerIdx)
{
}

/***********************************************************************************************
@brief:Disable specified Timer interrupt  function
@para:
        -u8TimerIdx:specified Timer Index
***********************************************************************************************/
void TIMER_DisableInt(u8 u8Ch,u8 u8TimerIdx)
{
}


/***********************************************************************************************
@brief:Get TIMER current counter
@para:
        -u8TimerIdx:specified Timer Index
***********************************************************************************************/
u32 TIMER_GetCounter(u8 u8Ch,u8 u8TimerIdx)
{
	return 0;
}

/***********************************************************************************************
@brief:Set CPUPLL to Timer divider of specified Timer
@para:
        -u8TimerIdx:specified Timer Index
        -u8Divider:divider value 1~15
************************************************************************************************/
void TIMER_SetCpupllDivider(u8 u8TimerIdx,u8 u8Divider)
{
}

