/***********************************************************************************************
*	INCLUDES
************************************************************************************************/
#include "f1_ae100_uart.h"
#include "f1_ae100_int.h"
#include "f1_ae100.h"

/***********************************************************************************************
*	MACROS
************************************************************************************************/
#define GET_BAUDRATE_DIVISOR(baudrate)			(int)(((float)MB_UCLK / (float)baudrate / 16)+0.5)
#define CHECK_UART_PORT(port)				((port == UART0) || (port == UART1))
#define CHECK_UART_PARITY(parity)			((parity==UART_DRV_PARITY_NONE) || (parity==UART_DRV_PARITY_ODD) || (parity==UART_DRV_PARITY_EVEN) || (parity==UART_DRV_PARITY_ONE) || (parity==UART_DRV_PARITY_ZERO))
#define CHECK_UART_DATABIT(databit)			((databit==UART_DRV_DATABITS_5) || (databit==UART_DRV_DATABITS_6) || (databit==UART_DRV_DATABITS_7) || (databit==UART_DRV_DATABITS_8))
#define CHECK_UART_STOPBIT(stopbit)			((stopbit==UART_DRV_STOPBITS_1) || (stopbit==UART_DRV_STOPBITS_1_5))

#define CHECK_UART_PSR_IS_OVERFLOW(val)			(val > 31)

#define CHECK_UART_BAUDRATE_IS_UNDER_3(expBr,relBr)	((expBr>relBr)?(expBr-relBr)*100/relBr <3:(relBr-expBr)*100/expBr<3)


/***********************************************************************************************
*	GLOBAL VARIABLES
************************************************************************************************/
DRVUART_Callback *gUart0Callback;
DRVUART_Callback *gUart1Callback;

#define UART_MAX_BUF_SIZ	256
typedef struct _UART_RCV_SEND_QUEUE{
	UART_RegDef *gUartConsole;
	char uartRcvBuf[UART_MAX_BUF_SIZ];
	char uartSendBuf[UART_MAX_BUF_SIZ];
	volatile unsigned int uartRcvHead;
	volatile unsigned int uartRcvTail;
	volatile unsigned int uartSendHead;
	volatile unsigned int uartSendTail;
}UART_RCV_SEND_QUEUE;

static UART_RCV_SEND_QUEUE *pUartCh0,uartCh0={UART0,{0},{0},0,0,0,0};
static UART_RCV_SEND_QUEUE *pUartCh1,uartCh1={UART1,{0},{0},0,0,0,0};

/***********************************************************************************************
*	LOCAL FUNCTIONS
************************************************************************************************/

static inline void UART_DequeueSendBuf(UART_RegDef *tUart, UART_RCV_SEND_QUEUE *tUartCh) {
	tUart->THR = tUartCh->uartSendBuf[tUartCh->uartSendHead++];
	tUartCh->uartSendHead %= UART_MAX_BUF_SIZ;
}

void UART0_ISR(int unused)
{
#ifdef ARDUINO_PRE_1_0
	u32 u32Intsts;

	u32Intsts = UART0->LSR;

	if(u32Intsts & UART_LSR_DATA_READY) {
		unsigned int isFull = ((pUartCh0->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh0->uartRcvHead;
		if(isFull)
			return;

		pUartCh0->uartRcvBuf[pUartCh0->uartRcvTail++] = UART0->RBR;
		pUartCh0->uartRcvTail %= UART_MAX_BUF_SIZ;
	}
#else
	switch(UART0->IIR & UART_IIR_MASK) {

		case UART_IIR_RDA: { // Received Data Available interrupt handler

			unsigned int isFull = ((pUartCh0->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh0->uartRcvHead;
			if(isFull)
				break;

			pUartCh0->uartRcvBuf[pUartCh0->uartRcvTail++] = UART0->RBR;
			pUartCh0->uartRcvTail %= UART_MAX_BUF_SIZ;
			break;
		}

		case UART_IIR_THRE: { // Transmitter Holding Register Empty interrupt handler
			UART0->IER &= ~UART_IER_THRE;

			if(pUartCh0->uartSendTail != pUartCh0->uartSendHead) {
				UART0->THR = pUartCh0->uartSendBuf[pUartCh0->uartSendHead++];
				pUartCh0->uartSendHead %= UART_MAX_BUF_SIZ;
			}

			if(pUartCh0->uartSendTail != pUartCh0->uartSendHead)
				UART0->IER |= UART_IER_THRE;

			break;
		}
	}
#endif // ARDUINO_PRE_1_0
}

void UART1_ISR(int unused)
{
#ifdef ARDUINO_PRE_1_0
	u32 u32Intsts;

	u32Intsts = UART1->LSR;

	if(u32Intsts & UART_LSR_DATA_READY) {
		unsigned int isFull = ((pUartCh1->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh1->uartRcvHead;
		if(isFull)
			return;

		pUartCh1->uartRcvBuf[pUartCh1->uartRcvTail++] = UART1->RBR;
		pUartCh1->uartRcvTail %= UART_MAX_BUF_SIZ;
	}
#else
	switch(UART1->IIR & UART_IIR_MASK) {

		case UART_IIR_RDA: { // Received Data Available interrupt handler

			unsigned int isFull = ((pUartCh1->uartRcvTail + 1) % UART_MAX_BUF_SIZ) == pUartCh1->uartRcvHead;
			if(isFull)
				break;

			pUartCh1->uartRcvBuf[pUartCh1->uartRcvTail++] = UART1->RBR;
			pUartCh1->uartRcvTail %= UART_MAX_BUF_SIZ;
			break;
		}

		case UART_IIR_THRE: { // Transmitter Holding Register Empty interrupt handler
			UART1->IER &= ~UART_IER_THRE;

			if(pUartCh1->uartSendTail != pUartCh1->uartSendHead) {
				UART1->THR = pUartCh1->uartSendBuf[pUartCh1->uartSendHead++];
				pUartCh1->uartSendHead %= UART_MAX_BUF_SIZ;
			}

			if(pUartCh1->uartSendTail != pUartCh1->uartSendHead)
				UART1->IER |= UART_IER_THRE;

			break;
		}
	}
#endif // ARDUINO_PRE_1_0
}

/***********************************************************************************************
*	GLOBAL FUNCTIONS
************************************************************************************************/

void UART_IsrInit(UART_RegDef *tUart)
{
	if((u32)tUart == UART0_BASE) {
		pUartCh0=&uartCh0;
		ISR_InsertCb(INT_TYPE_IRQ,IRQ_UART0_INTR,UART0_ISR);
		INT_IrqEn(1 << IRQ_UART0_INTR, 0, 0);
	}
	else if((u32)tUart == UART1_BASE) {
		pUartCh1=&uartCh1;
		ISR_InsertCb(INT_TYPE_IRQ,IRQ_UART1_INTR,UART1_ISR);
		INT_IrqEn(1 << IRQ_UART1_INTR, 0, 0);
	}
}


/**********************************************************************************************
@brief:Initialize specified UART port
@para:
		-tUart: Specified UART port UART0/UART1
		-tParam.u32BaudRate : Baud rate(Hz)
			UART_DRV_BAUDRATE_38400
			UART_DRV_BAUDRATE_57600
			UART_DRV_BAUDRATE_115200
			UART_DRV_BAUDRATE_230400
			UART_DRV_BAUDRATE_460800
		  tParam.u8DataBits : Data bit setting
			UART_DRV_DATABITS_5
			UART_DRV_DATABITS_6
			UART_DRV_DATABITS_7
			UART_DRV_DATABITS_8
		  tParam.u8StopBits : Stop bit setting
			UART_DRV_STOPBITS_1
			UART_DRV_STOPBITS_1_5
		  tParam.u8Parity : Parity setting
			UART_DRV_PARITY_NONE
			UART_DRV_PARITY_ODD
			UART_DRV_PARITY_EVEN
			UART_DRV_PARITY_ONE
			UART_DRV_PARITY_ZERO
***********************************************************************************************/
void UART_Init(UART_RegDef *tUart,UART_DATA_t * tParam)
{
	u32 div = 0;

	/* Set DLAB to 1 */
	tUart->LCR |= UART_LCR_DLAB;

	/*Get current UART clock source frequency */
	div = GET_BAUDRATE_DIVISOR(tParam->u32BaudRate);

	/* Set DLL and DLM */
	tUart->DLL = (div >> 0) & 0xff ;
	tUart->DLM = (div >> 8) & 0xff ;

	/* LCR: Set (1)Length 8, parity, stop bit. (2)DLAB = 0 */
	tUart->LCR = tParam->u8DataBits | (tParam->u8StopBits << 2) |(tParam->u8Parity << 3);

	/* FCR: reset TX and RX. */
	tUart->FCR = UART_FCR_RX_FIFO_RESET | UART_FCR_TX_FIFO_RESET;

	/* IER: Enable received data available interrupt */
	tUart->IER = UART_IER_RDA;

	/* MCR: Set loopback mode for test*/
	//tUart->MCR |= (1 << 4);
}

/***********************************************************************************************
@brief:Disable UART clock
@para:
		-tUart: Specified UART port UART0/UART1
***********************************************************************************************/
void UART_DeInit(UART_RegDef *tUart)
{
	if((u32)tUart == UART0_BASE)
		INT_IrqDis(1 << IRQ_UART0_INTR);
	else if((u32)tUart == UART1_BASE)
		INT_IrqDis(1 << IRQ_UART1_INTR);
}

/***********************************************************************************************
@brief:Write one byte data to SW TX Buffer and transmit data by specified UART
@para:
		-tUart: Specified UART port UART0/UART1
		-u8Data: write data
***********************************************************************************************/
void UART_WriteByte(UART_RegDef *tUart,u8 u8Data)
{
#if ARDUINO_PRE_1_0
	while(!(tUart->LSR & UART_LSR_THR_EMPTY));
	tUart->THR = u8Data;
#else

	UART_RCV_SEND_QUEUE *tUartCh;
	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	// Disable the THRE interrupt to avoid race condition
	tUart->IER &= ~UART_IER_THRE;

	// If THR is empty, we write data to THR directly.
	if((tUartCh->uartSendTail == tUartCh->uartSendHead) && (tUart->LSR & UART_LSR_THR_EMPTY)) {
		tUart->THR = u8Data;
		return;
	}

	// If the transmission buffer is full, we have to consume an old data befor enqueue the new data
	while(((tUartCh->uartSendTail + 1) % UART_MAX_BUF_SIZ) == tUartCh->uartSendHead) {
		if(tUart->LSR & UART_LSR_THR_EMPTY)
			UART_DequeueSendBuf(tUart, tUartCh);
	}

	// Enqueue the new data
	tUartCh->uartSendBuf[tUartCh->uartSendTail++] = u8Data;
	tUartCh->uartSendTail %= UART_MAX_BUF_SIZ;

	tUart->IER |= UART_IER_THRE;
	return;
#endif // ARDUINO_PRE_1_0
}

void UART_Flush(UART_RegDef *tUart)
{
#if ARDUINO_PRE_1_0
	UART_RCV_SEND_QUEUE *tUartCh;
	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	tUart->IER = 0x0;

	while(1) {
		if(UART_IsDataAvailable(tUart))
			UART_ReadByte(tUart);
		else
			break;
	}

	tUart->FCR = UART_FCR_RX_FIFO_RESET | UART_FCR_TX_FIFO_RESET;
	tUartCh->uartRcvHead = 0;
	tUartCh->uartRcvTail = 0;
	tUart->IER = 0x1;
#else

	UART_RCV_SEND_QUEUE *tUartCh;

	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	tUart->IER &= ~UART_IER_THRE;

	u32 len = (tUartCh->uartSendTail - tUartCh->uartSendHead + UART_MAX_BUF_SIZ) % UART_MAX_BUF_SIZ;
	while(len--) {
		while(!(tUart->LSR & UART_LSR_THR_EMPTY));
		tUart->THR = tUartCh->uartSendBuf[tUartCh->uartSendHead++];
		tUartCh->uartSendHead %= UART_MAX_BUF_SIZ;
	}
#endif // ARDUINO_PRE_1_0
}

int UART_IsDataAvailable(UART_RegDef *tUart)
{
	UART_RCV_SEND_QUEUE *tUartCh;
	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	return tUartCh->uartRcvTail != tUartCh->uartRcvHead;
}

/***********************************************************************************************
@brief: Check how many bytes in queue are available for write
@para:
		-tUart: Specified UART port UART0/UART1
@ret:
		-The number of bytes avaliable for write(Only 1 byte buffer if the port is not busy)
***********************************************************************************************/
int UART_BytesAvailableForWrite(UART_RegDef *tUart)
{
	UART_RCV_SEND_QUEUE *tUartCh;
	unsigned int len;

	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	// Disable the THRE interrupt to avoid race condition
	tUart->IER &= ~UART_IER_THRE;

	// calculate the number of elements in Queue.
	len = (tUartCh->uartSendTail - tUartCh->uartSendHead + UART_MAX_BUF_SIZ) % UART_MAX_BUF_SIZ;

	tUart->IER |= UART_IER_THRE;

	return len;
}
/***********************************************************************************************
@brief:Read one byte data from SW Rx Buffer of specified UART
@para:
		-tUart: Specified UART port UART0/UART1
@ret:
***********************************************************************************************/
u8 UART_ReadByte(UART_RegDef *tUart)
{
	volatile char ch = ' ';
	UART_RCV_SEND_QUEUE *tUartCh;

	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	ch = tUartCh->uartRcvBuf[tUartCh->uartRcvHead++];
	tUartCh->uartRcvHead %= UART_MAX_BUF_SIZ;
	return ch;
}

u8 UART_PeekByte(UART_RegDef *tUart)
{
	UART_RCV_SEND_QUEUE *tUartCh;

	if((u32)tUart == UART0_BASE)
		tUartCh=pUartCh0;
	else
		tUartCh=pUartCh1;

	return tUartCh->uartRcvBuf[tUartCh->uartRcvHead];
}

/***********************************************************************************************
@brief:Write number of	bytes data to Tx FIFO and transmit data by specified UART
@para:
		-tUart: Specified UART port UART0/UART1
		-u8Len: write data number bytes
		-pu8Data:Specify the buffer to transmit the data to UART
@ret: UART_RET_TIMEOUT /UART_RET_SUCCESS
***********************************************************************************************/
u8 UART_Write(UART_RegDef *tUart,u8 u8Len,const u8 * pu8Data)
{
	u32 u32Delay = 0;
	int i;
	for(i=0;i<u8Len;i++) {
			u32Delay = 0;
		while(tUart->IIR & UART_IIR_TX_FULL) {
			if(u32Delay++ >= 0x100000)
				return UART_RET_TIMEOUT;
		}
		tUart->THR = *pu8Data++;

	}
	return UART_RET_SUCCESS;
}


/***********************************************************************************************
@brief:Read number of  bytes data from Tx FIFO and transmit data by specified UART
@para:
		-tUart: Specified UART port UART0/UART1
		-u8Len: read data number bytes
		-pu8Data:Specify the buffer to receive the data of UART rx buffer
@ret: UART_RET_TIMEOUT /UART_RET_SUCCESS
***********************************************************************************************/
u8 UART_Read(UART_RegDef *tUart,u8 u8Len, u8 * pu8Data)
{
	u32 u32Delay = 0;
	int i;
	for(i=0;i<u8Len;i++) {
		u32Delay = 0;
		while((tUart->LSR & UART_LSR_DATA_READY) == 0x0) {
			if(u32Delay++ >= 0x100000)
				return UART_RET_TIMEOUT;
		}
		*pu8Data++ =  tUart->RBR;
	}
	return UART_RET_SUCCESS;
}

/***********************************************************************************************
@brief:Register UART interrupt callback function
@para:
		-tUart: Specified UART port UART0/UART1
		-cb : UART callback function
***********************************************************************************************/
void UART_RegisterCallback(UART_RegDef *tUart,DRVUART_Callback cb)
{
	if((u32)tUart == UART0_BASE)
		gUart0Callback = cb;
	else if((u32)tUart == UART1_BASE)
		gUart1Callback = cb;
}

/***********************************************************************************************
@brief:Enable interrupt of	specified UART
@para:
		-tUart: Specified UART port UART0/UART1
		-u32IntFlag: UART enable interrupt flag
			UART_DRV_RDAINT
			UART_DRV_THREINT
			UART_DRV_RLSINT
			UART_DRV_MODEMINT
***********************************************************************************************/
void UART_EnableInt(UART_RegDef *tUart,u32 u32IntFlag)
{
	tUart->IER = u32IntFlag;
}

/***********************************************************************************************
@brief:Disable interrupt of specified UART
@para:
		-tUart: Specified UART port UART0/UART1
***********************************************************************************************/
void UART_DisableInt(UART_RegDef *tUart)
{
	tUart->IER = 0x0;
}


/***********************************************************************************************
@brief:Set the trigger level of the RX FIFO interrupt of specified UART
@para:
		-tUart: Specified UART port UART0/UART1
		-u8TrigVal: trigger level value
***********************************************************************************************/
 void UART_SetRxFIFOTrigger(UART_RegDef *tUart,u8 u8TrigVal)
{
	tUart->FCR = (tUart->FCR &~UART_FCR_RXFIFO_TRGL_MASK) |	 u8TrigVal;
}


/***********************************************************************************************
@brief:Set specified UART port clock source
@para:
		-tUart: Specified UART port UART0/UART1
		-u8ClkSrc:UART_CLK_SRC_XO/UART_CLK_SRC_CPULL
************************************************************************************************/
void UART_SetClockSrc(UART_RegDef *tUart, u8 u8ClkSrc)
{
}

/***********************************************************************************************
@brief:Set specified UART port CPUPLL divider
@para:
		-tUart: Specified UART port UART0/UART1
		-u8Div:divider value 1~16
************************************************************************************************/
void UART_SetCpupllDivider(UART_RegDef *tUart, u8 u8Div)
{
}

#ifdef TESTING

// Insert to UART1's (Serial) Rcv Queue
void insertStrToRcvQueue(char* buffer, unsigned int len) 
{

	int i;
	for(i=0; i<len; i++) {
		pUartCh1->uartRcvBuf[pUartCh1->uartRcvTail++] = *buffer++;
		pUartCh1->uartRcvTail %= UART_MAX_BUF_SIZ;
	}

}

// Insert to UART1's (Serial) Send Queue
void insertStrToSendQueue(char* buffer, unsigned int len) 
{

	pUartCh1->gUartConsole->IER &= ~UART_IER_THRE;

	int i;
	for(i=0; i<len; i++) {
		pUartCh1->uartSendBuf[pUartCh1->uartSendTail++] = *buffer++;
		pUartCh1->uartSendTail %= UART_MAX_BUF_SIZ;
	}

	pUartCh1->gUartConsole->IER |= UART_IER_THRE;

}

#endif
