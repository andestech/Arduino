#ifndef F1_AE100_GPIO_H
#define F1_AE100_GPIO_H
#include "f1_ae100.h"
#include "typedef.h"

/*    Interrupt mode	*/
#define HIGH            2
#define LOW             3
#define FALLING         5
#define RISING          6
#define CHANGE          7

#define GPIO_NUM	32

/***********************************************************************************************
*   TYPEDEFS
************************************************************************************************/
typedef void (DRVGPIO_Callback)(u32);


typedef enum{
	GPIO_LOW,
	GPIO_HIGH
}GPIO_STATE;

typedef enum{
	GPIO_INPUT,
	GPIO_OUTPUT,
	GPIO_INPUT_PULLUP
}GPIO_TYPE;

typedef enum{
	GPIO_PULL_DOWN,
	GPIO_PULL_UP,
}GPIO_PULL_TYPE;

typedef enum{
	GPIO_TRIG_LEVEL,
	GPIO_TRIG_EDGE,
}GPIO_TRIGGER_TYPE;

typedef enum{
	GPIO_RISING_HIGH,
	GPIO_FALLING_LOW,
}GPIO_TRIGGERED_EDGE_TYPE;


void GPIO_SetDir(u8 u8Idx, GPIO_TYPE Dir);
void GPIO_SetInputType(u8 u8Idx, GPIO_PULL_TYPE type);
void GPIO_SetOutput(u8 u8Idx, GPIO_STATE Val);
u8 GPIO_GetBit(u8 u8Idx);

void GPIO_IsrInit(void);
void GPIO_EnableInt(u8 u8Idx,u8 u8Mode);
void GPIO_DisableInt(u8 u8Idx);
void GPIO_RegisterCallback(DRVGPIO_Callback *cb);

#endif /* F1_AE100_GPIO_H */
