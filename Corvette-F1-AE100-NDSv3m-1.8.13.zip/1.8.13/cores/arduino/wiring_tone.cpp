#include "wiring_tone.h"

void noTone(uint8_t pin)
{
}

void tone(uint8_t pin, unsigned int frequency, unsigned long duration)
{
}
