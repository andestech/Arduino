
#include "Wire.h"
#include "EEPROM.h"

#define eeprom_address 0x50

void eeprom_write_byte (uint8_t *__p, uint8_t __value)
{
  uint8_t send_array[3];

  if( !EEPROM.init_flag ) {
    Wire.begin();
    EEPROM.init_flag = 1;
  }
  Wire.beginTransmission(eeprom_address);
  send_array[0] = (uint8_t)(((uint32_t)__p & 0xff00) >> 8);
  send_array[1] = (uint8_t)((uint32_t)__p & 0xff);
  send_array[2] = __value;
  Wire.write(send_array, 3);
  Wire.endTransmission(true);

  delay(5);
}

uint8_t eeprom_read_byte (const uint8_t *__p)
{
  uint8_t send_array[2], recv_data = 0;

  if( !EEPROM.init_flag ) {
    Wire.begin();
    EEPROM.init_flag = 1;
  }

  Wire.beginTransmission(eeprom_address);
  send_array[0] = (uint8_t)(((uint32_t)__p & 0xff00) >> 8);
  send_array[1] = (uint8_t)((uint32_t)__p & 0xff);
  Wire.write(send_array, 2);
  Wire.endTransmission(false);

  Wire.requestFrom(eeprom_address, 1, true);

  while (Wire.available()){
    recv_data = Wire.read();
  };
    return recv_data;
}
