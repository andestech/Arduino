#include "SPI.h"

#include "gpio.h"

#define DISABLE_IRQSAVE()               read_csr(NDS_MSTATUS) & MSTATUS_MIE; 	clear_csr(NDS_MSTATUS, MSTATUS_MIE);
#define ENABLE_IRQRESTORE(flag)         do { if ((flag)) { set_csr(NDS_MSTATUS, MSTATUS_MIE); } } while(0);

// SPIClass SPI(&SPI_DRV2, true);
SPIClass SPI(&SPI_DRV3, false);
SPIClass SPI4(&SPI_DRV4, false);

static bool pinMuxCheckAndSet(GpioPin pin, PinFunction pin_function)
{
	int pin_usage = pinMuxCheckUsage(pin);

	if (pin_usage == PINMUX_FUNC_UNUSED) {
		int err = pinMuxSet(pin, pin_function);
		if (err)
			return false;
	}
	else if (pin_usage != pin_function) {
		// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
		return false;
	}

	return true;
}

static bool spiSetPinMux(SPI_Driver* spi)
{
	SpiPins spi_pins = spiIpToPins(spi->ip_num);

	if (pinSupportPinMux(spi_pins.sclk)) {
		if (!pinMuxCheckAndSet(spi_pins.sclk, PINMUX_FUNC_SPI)) {
			return false;
		}
	}
	if (pinSupportPinMux(spi_pins.mosi)) {
		if (!pinMuxCheckAndSet(spi_pins.mosi, PINMUX_FUNC_SPI)) {
			return false;
		}
	}
	if (pinSupportPinMux(spi_pins.miso)) {
		if (!pinMuxCheckAndSet(spi_pins.miso, PINMUX_FUNC_SPI)) {
			return false;
		}
	}

	return true;
}

void SPIClass::begin()
{
	// Set Pinmux
	if (this->may_need_pinmux) {
		spiSetPinMux(spi);
	}

	// Set GPIO pull-up resistor to SPI CS pin. (this behavior is copied from ArduinoCore-avr)
	GPIO_SetInputType(arduinoPinToGpioPin(SS), GPIO_PULL_UP);

	SPI_Init(spi);

	// SPI use default config if SPI library user doesn't call beginTransaction().
	SPI_SetBitOrder(spi, SPISettings::DEFAULT_BIT_ORDER);
	SPI_SetClockDivider(spi, SPISettings::clockToDivider(SPISettings::DEFAULT_CLK_RATE));
	SPI_SetDataMode(spi, SPISettings::DEFAULT_DATA_MODE);
}

void SPIClass::end()
{
	SPI_DeInit(spi);
}

void SPIClass::usingInterrupt(uint8_t interruptNumber)
{
	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)interruptNumber);
	unsigned long flag = DISABLE_IRQSAVE();

	if (gpio_pin != NOT_GPIO_PIN) {
		interrupt_mask |= (1 << gpio_pin);
	} else {
		interrupt_mode = 2;
	}

	if (!interrupt_mode)
		interrupt_mode = 1;

	ENABLE_IRQRESTORE(flag);
}

void SPIClass::notUsingInterrupt(uint8_t interruptNumber)
{
	// Once in mode 2 we can't go back to 0 without a proper reference count
	if (interrupt_mode == 2)
		return;

	GpioPin gpio_pin = arduinoPinToGpioPin((ArduinoPin)interruptNumber);
	unsigned long flag = DISABLE_IRQSAVE();

	if (gpio_pin != NOT_GPIO_PIN) {
		interrupt_mask &= ~(1 << gpio_pin);
	}

	if (!interrupt_mask) {
		interrupt_mode = 0;
	}

	ENABLE_IRQRESTORE(flag);
}

void SPIClass::beginTransaction(SPISettings settings) {
	if (interrupt_mode > 0) {
		unsigned long flag = DISABLE_IRQSAVE();

		if (interrupt_mode == 1) {
			GPIO_MaskInt(interrupt_mask);
			ENABLE_IRQRESTORE(flag);
		} else {
			interrupt_save = flag;
		}
	}

	SPI_SetBitOrder(spi, settings.msb_first);
	SPI_SetClockDivider(spi, settings.divider_ratio);
	SPI_SetDataMode(spi, settings.data_mode);
}

void SPIClass::endTransaction(void) {
	if (interrupt_mode > 0) {
		unsigned long flag = DISABLE_IRQSAVE();

		if (interrupt_mode == 1) {
			GPIO_UnmaskInt(interrupt_mask);
			ENABLE_IRQRESTORE(flag);
		} else {
			ENABLE_IRQRESTORE(interrupt_save);
		}
	}
}
