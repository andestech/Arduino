/*
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#define ARDUINO_MAIN
// [ARDUINO_MAIN] arduino_pin.h's variable definition is only defined in this C file.

#include "Arduino.h"
#include "arduino_pin.h"
#include "pinmux.h"
#include "gpio.h"
#include "pwm.h"

void pinMode( pin_size_t pin, PinMode mode )
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);

	if (mode == INPUT)
	{
		GPIO_SetDir(gpio_pin, GPIO_INPUT);
	}
	else if (mode == INPUT_PULLUP)
	{
		GPIO_SetDir(gpio_pin, GPIO_INPUT);
		GPIO_SetInputType(gpio_pin, GPIO_PULL_UP);
	}
	else if (mode == OUTPUT)
	{
		GPIO_SetDir(gpio_pin, GPIO_OUTPUT);
	}
}

void digitalWrite( pin_size_t pin, PinStatus value )
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);

	if (pinSupportPinMux(gpio_pin))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(gpio_pin, PINMUX_FUNC_GPIO);
			if (err)
				return;
		}
		else if (pin_usage == PINMUX_FUNC_PWM) {
			// use PWM Park to emulate GPIO output.
			PwmIpCh pwm = pinToPwmChannel(gpio_pin);
			if (value == HIGH) {
				PWM_SetFullyOn(pwm.ip_num, pwm.ch_num);
			}
			else {
				PWM_SetFullyOff(pwm.ip_num, pwm.ch_num);
			}
			PWM_Start(pwm.ip_num, pwm.ch_num);

			return;
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}
	// This pin is used by GPIO in pin mux, or this pin doesn't support pin mux.

	if(value == HIGH)
		GPIO_SetOutput(gpio_pin, GPIO_HIGH);
	else
		GPIO_SetOutput(gpio_pin, GPIO_LOW);
}

PinStatus digitalRead( pin_size_t pin )
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);

	if (pinSupportPinMux(gpio_pin))
	{
		// PinMux processing
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage == PINMUX_FUNC_UNUSED)
		{
			int err = pinMuxSet(gpio_pin, PINMUX_FUNC_GPIO);
			if (err)
				return LOW; // digitalRead() doesn't have error code to return, so return LOW for error currently.
		}
		else if (pin_usage == PINMUX_FUNC_PWM) {
			// digitalRead() turn off analogWrite() (PWM).
			PwmIpCh pwm = pinToPwmChannel(gpio_pin);
			PWM_SetFullyOff(pwm.ip_num, pwm.ch_num);
			PWM_Stop(pwm.ip_num, pwm.ch_num);

			return LOW;
		}
		else if (pin_usage != PINMUX_FUNC_GPIO)
		{
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return LOW;     // digitalRead() doesn't have error code to return, so return LOW for error currently.
		}
	}

	// This pin is used by GPIO in PinMux, or this pin doesn't support PinMux.
	if(!GPIO_GetBit(gpio_pin))
		return LOW;
	else
		return HIGH;
}
