#ifndef WIRING_TONE_H
#define WIRING_TONE_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void toneTimerInit();
void toneTimer1Overflow();
void timer2_irq_handler();

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //WIRING_TONE_H
