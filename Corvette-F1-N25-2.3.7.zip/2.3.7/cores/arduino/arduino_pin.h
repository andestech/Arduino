#ifndef ARDUINO_PIN_H
#define ARDUINO_PIN_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include "pinmux.h"

#define LED_BUILTIN 13

/* Arduino pin names of Corvette-F1 */

/*
 * Note for pin 18 and 19:
 *   In Arduino Uno, A4 and D14 are both pin 18, and A5 and D15 are both pin 19.
 *
 *   But A4 and D14 are different pins in F1-AE250, we can only map 1 pin to pin 18.
 *   Due to A4 can't be used (no GPIO pinout) in F1-AE250, we map D14 to pin 18.
 *   We also map D15 to 19 for the same reason.
 */
typedef enum {
	D0 = 0, D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D13, /* 0 ~ 13 */
	A0, A1, A2, A3, /* 14 ~ 17 */
	D14, D15,       /* 18 ~ 19 */
	A4, A5,
	BT1, BT2, BT3, BT4, LED1, LED2, LED3, LED4,
	WIFI_IRQ, WIFI_EN, WIFI_RST,
	PIN_NUM,
	NOT_PIN
} ArduinoPin;

extern const GpioPin arduino_pin_to_GPIO_pin[];

#define PIN_SPI_SS    (10)
#define PIN_SPI_MOSI  (11)
#define PIN_SPI_MISO  (12)
#define PIN_SPI_SCK   (13)

static const ArduinoPin SS   = (ArduinoPin)PIN_SPI_SS;
static const ArduinoPin MOSI = (ArduinoPin)PIN_SPI_MOSI;
static const ArduinoPin MISO = (ArduinoPin)PIN_SPI_MISO;
static const ArduinoPin SCK  = (ArduinoPin)PIN_SPI_SCK;

#ifdef ARDUINO_MAIN
// Only define data in wiring_digital.c to avoid duplicate symbol.
// This hack is borrowed from ArduinoCore-avr (pins_arduino.h)

const GpioPin arduino_pin_to_GPIO_pin[PIN_NUM] = {
	// D0 ~ D13
	16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
	// A0 ~ A3
	12, 13, 14, 15,
	// D14 ~ D15
	30, 31,
	// A4 ~ A5
	NOT_GPIO_PIN, NOT_GPIO_PIN,
	// BT1 ~ 4 and LED1 ~ 4
	1, 2, 3, 4, 5, 6, 7, 8,
	9, 10, 11,
};

#endif

static inline GpioPin arduinoPinToGpioPin(ArduinoPin pin){
	if (pin >= PIN_NUM)
		return NOT_GPIO_PIN;

	return arduino_pin_to_GPIO_pin[pin];
}

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif //ARDUINO_PIN_H
