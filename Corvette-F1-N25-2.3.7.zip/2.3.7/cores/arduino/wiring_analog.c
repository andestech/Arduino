#include "Arduino.h"
#include "arduino_pin.h"
#include "pwm.h"
#include "pinmux.h"

/*
 * CF1-AE250's analogWrite() output 980Hz PWM wave instead of Arduino Uno's 490Hz,
 * because the clock rate of timer in this platform isn't suitable for 490Hz.
 */
#define PWM_FREQ_ANALOG_WRITE 980
#define DUTY_LENGTH           255

/* Analog Input */
// p.s. Analog Input needs HW ADC support.
int analogRead(pin_size_t pin)
{
	static int i = 0;
	i++;
	return 0;
}

void analogReference(uint8_t mode)
{
}

/* Analog Output */

static inline void analogWriteGPIO(pin_size_t pin, int value)
{
	/*
	 * Error handling for analogWrite() to the pins without PWM support.
	 * This handling method is borrowed from ArduinoCore-avr.
	 */
	if (value < 128) {
		digitalWrite(pin, LOW);
	}
	else {
		digitalWrite(pin, HIGH);
	}
}

void analogWrite(pin_size_t pin, int value)
{
	GpioPin gpio_pin = arduinoPinToGpioPin(pin);

	/* 1. Config PinMux to PWM function. */
	if (pinSupportPinMux(gpio_pin)) {
		int pin_usage = pinMuxCheckUsage(gpio_pin);

		if (pin_usage == PINMUX_FUNC_UNUSED) {
			int err = pinMuxSet(gpio_pin, PINMUX_FUNC_PWM);
			if (err) {
				// This pin doesn't support PWM, output GPIO instead.
				analogWriteGPIO(pin, value);
				return;
			}
		}
		else if (pin_usage != PINMUX_FUNC_PWM) {
			// This gpio_pin is used by other peripheral, or pinMuxCheckUsage() return error.
			return;
		}
	}
	// This pin is used by PWM in PinMux, or this pin doesn't support PinMux.

	/* 2. find PWM channel of pin and init PWM channel. */
	PwmIpCh pwm = pinToPwmChannel(gpio_pin);

	if (pwm.ip_num == NO_PWM_IP) {
		// This pin doesn't support PWM, output GPIO instead.
			// p.s. This error handling is for the pins which doesn't support PinMux.
			//      PinMux's pins are error handled in previous code.

		analogWriteGPIO(pin, value);
		return;
	}

	if (!is_pwm_channel_init[pwm.ip_num][pwm.ch_num]) {
		is_pwm_channel_init[pwm.ip_num][pwm.ch_num] = true;
		PWM_Init(pwm.ip_num, pwm.ch_num);
	}

	/* 3. config PWM HW. */
	if (PWM_GetClockSrc(pwm.ip_num, pwm.ch_num) != PIT_CLKSRC_APB) {
		PWM_Stop(pwm.ip_num, pwm.ch_num);
		PWM_SetClockSrc(pwm.ip_num, pwm.ch_num, PIT_CLKSRC_APB);
	}

	if ((value < 0) || (value > DUTY_LENGTH)) {
		// invalid value
		return;
	}
	else if (value == 0) {
		PWM_SetFullyOff(pwm.ip_num, pwm.ch_num);
	}
	else if (value == DUTY_LENGTH) {
		PWM_SetFullyOn(pwm.ip_num, pwm.ch_num);
	}
	else {
		uint32_t pwm_period_cycle = PCLKFREQ / PWM_FREQ_ANALOG_WRITE;
		uint16_t hi_cycle = (pwm_period_cycle * value) / DUTY_LENGTH;
		uint16_t lo_cycle = pwm_period_cycle - hi_cycle;
		PWM_SetPeriod(pwm.ip_num, pwm.ch_num, hi_cycle, lo_cycle);
	}

	PWM_Start(pwm.ip_num, pwm.ch_num);
}
