#ifndef F1_AE250_PWM_H_
#define F1_AE250_PWM_H_

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


#include "ae250.h"
#include "typedef.h"
#include "platform.h"
#include "pinmux.h"

#define PIT_CLKSRC_APB 0
#define PIT_CLKSRC_EXT 1

#define PWM_MAX_PERIOD (1<<16)

extern bool is_pwm_channel_init[PWM_IP_NUM+1][PWM_IP_CHANNEL_NUM];

void PWM_Init(uint8_t ip_num, uint8_t ch_num);
void PWM_Start(uint8_t ip_num, uint8_t ch_num);
void PWM_Stop(uint8_t ip_num, uint8_t ch_num);

void PWM_SetPeriod(uint8_t ip_num, uint8_t ch_num, uint16_t hi_cycle, uint16_t lo_cycle);
void PWM_SetFullyOn(uint8_t ip_num, uint8_t ch_num);
void PWM_SetFullyOff(uint8_t ip_num, uint8_t ch_num);

void PWM_SetClockSrc(uint8_t ip_num, uint8_t ch_num, uint8_t clk_src);
uint8_t PWM_GetClockSrc(uint8_t ip_num, uint8_t ch_num);


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* end of include guard: F1_AE250_PWM_H_ */
