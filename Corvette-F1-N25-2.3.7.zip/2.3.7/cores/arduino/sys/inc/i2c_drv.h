#ifndef F1_AE250_I2C_H_
#define F1_AE250_I2C_H_

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

#include <stdbool.h>
#include "platform.h"
#include "ae250.h"
#include "typedef.h"

#ifndef BIT
#define BIT(n)                      ((unsigned int) 1 << (n))
#define BITS2(m,n)                  (BIT(m) | BIT(n) )

/* bits range: for example BITS(16,23) = 0xFF0000
 *   ==>  (BIT(m)-1)   = 0x0000FFFF     ~(BIT(m)-1)   => 0xFFFF0000
 *   ==>  (BIT(n+1)-1) = 0x00FFFFFF
 */
#define BITS(m,n)                   (~(BIT(m)-1) & ((BIT(n) - 1) | BIT(n)))
#endif /* BIT */

//selet APB clock
#define APB_CLK_30MHZ			0
#define APB_CLK_40MHZ			0
#define APB_CLK_60MHZ			1

// n-byte FIFO, where n is the number 2, 4, 8 or 16.
#define ATCIIC100_FIFO_DEPTH_N      (16)

// id rev register bit define(RO)
#define ATCIIC100_ID                BITS(12,31)     // ID number for ATCRTC100
#define ATCIIC100_MAJOR             BITS(4,11)      // Enable alarm wakeup signal
#define ATCIIC100_MINOR             BITS(0,3)       // Enable alarm interrupt

// Configuration Register(RO)
#define FIFO_SZ_MSK                 BITS(0,1)       // FIFO size mask
#define FIFO_SZ_2                   (0x0)           // 2 bytes
#define FIFO_SZ_4                   (0x1)           // 4 bytes
#define FIFO_SZ_8                   (0x2)           // 8 bytes
#define FIFO_SZ_16                  (0x3)           // 16 bytes
#define MAX_XFER_SZ                 (256)           // 256 bytes

// Interrupt Enable Register(RW)
#define IEN_ALL                     BITS(0,9)       // All Interrupts mask.
#define IEN_CMPL                    BIT(9)          // Completion Interrupt.
#define IEN_BYTE_RECV               BIT(8)          // Byte Receive Interrupt.
#define IEN_BYTE_TRANS              BIT(7)          // Byte Transmit Interrupt.
#define IEN_START                   BIT(6)          // START Condition Interrupt.
#define IEN_STOP                    BIT(5)          // STOP Condition Interrupt.
#define IEN_ARB_LOSE                BIT(4)          // Arbitration Lose Interrupt.
#define IEN_ADDR_HIT                BIT(3)          // Address Hit Interrupt.
#define IEN_FIFO_HALF               BIT(2)          // FIFO Half Interrupt.
#define IEN_FIFO_FULL               BIT(1)          // FIFO Full Interrupt.
#define IEN_FIFO_EMPTY              BIT(0)          // FIFO Empty Interrupt.

// Status Register(RW)
#define STATUS_W1C_ALL              BITS(3,9)       // All Interrupts status write 1 clear mask.
#define STATUS_LINE_SDA             BIT(14)         // current status of the SDA line on the bus.
#define STATUS_LINE_SCL             BIT(13)         // current status of the SCL line on the bus.
#define STATUS_GEN_CALL             BIT(12)         // the address of the current transaction is a general call address.
#define STATUS_BUS_BUSY             BIT(11)         // the bus is busy.
#define STATUS_ACK                  BIT(10)         // the type of the last received/transmitted acknowledgement bit.
#define STATUS_CMPL                 BIT(9)          // Transaction Completion
#define STATUS_BYTE_RECV            BIT(8)          // a byte of data has been received
#define STATUS_BYTE_TRANS           BIT(7)          // a byte of data has been transmitted.
#define STATUS_START                BIT(6)          // a START Condition or a repeated TART condition has been transmitted/received.
#define STATUS_STOP                 BIT(5)          // a STOP Condition has been transmitted/received.
#define STATUS_ARB_LOSE             BIT(4)          // the controller has lost the bus arbitration (manager mode only).
#define STATUS_ADDR_HIT             BIT(3)          // Manager: indicates that a subordinate has responded to the transaction, Subordinate: indicates that a transaction is targeting the controller (including the General Call).
#define STATUS_FIFO_HALF            BIT(2)          // Indicates that the FIFO is half-full or half-empty.
#define STATUS_FIFO_FULL            BIT(1)          // the FIFO is full.
#define STATUS_FIFO_EMPTY           BIT(0)          // the FIFO is empty.

// Address Register(RW)
#define SUBORDINATE_ADDR_MSK        BITS(0,9)       // The subordinate address.

// Data Register(RW)
#define DATA_MSK                    BITS(0,7)       // Write this register to put one byte of data to the FIFO, Read this register to get one byte of data from the FIFO.

// Control Register(RW)
#define CTRL_PHASE_START            BIT(12)         // Enable this bit to send a START condition at the beginning of transaction, manager mode only.
#define CTRL_PHASE_ADDR             BIT(11)         // Enable this bit to send the address after START condition, manager mode only.
#define CTRL_PHASE_DATA             BIT(10)         // Enable this bit to send the data after Address phase, manager mode only.
#define CTRL_PHASE_STOP             BIT(9)          // Enable this bit to send a STOP condition at the end of a transaction, manager mode only.
#define CTRL_DIR                    BIT(8)          // Transaction direction
#define CTRL_DATA_COUNT             BITS(0,7)       // Data counts in bytes.

// Command Register(RW)
#define CMD_MSK                     BITS(0,2)       // action command mask
#define CMD_NO_ACT                  (0x0)           // no action
#define CMD_ISSUE_TRANSACTION       (0x1)           // issue a data transaction (Manager only)
#define CMD_ACK                     (0x2)           // respond with an ACK to the received byte
#define CMD_NACK                    (0x3)           // respond with a NACK to the received byte
#define CMD_CLEAR_FIFO              (0x4)           // clear the FIFO
#define CMD_RESET_I2C               (0x5)           /* reset the I2C controller(abort current
                                                       ransaction, set the SDA and SCL line to the
                                                       open-drain mode, reset the Status Register and
                                                       the Interrupt Enable Register, and empty the
                                                       FIFO) */

// Setup Register(RW)
#define SETUP_T_SUDAT               BITS(24,28)     // T_SUDAT defines the data setup time before releasing the SCL.
#define SETUP_T_SP                  BITS(21,23)     // T_SP defines the pulse width of spikes that must be suppressed by the input filter.
#define SETUP_T_HDDAT               BITS(16,20)     // T_SUDAT defines the data hold time after SCL goes LOW.
#define SETUP_T_SCL_RATIO           BIT(13)         // The LOW period of the generated SCL clock is defined by the combination of T_SCLRatio and T_SCLHi values
#define SETUP_T_SCLHI               BITS(4,12)      // The HIGH period of generated SCL clock is defined by T_SCLHi.
#define SETUP_DMA_EN                BIT(3)          // Enable the direct memory access mode data transfer.
#define SETUP_MANAGER               BIT(2)          // Configure this device as a manager or a subordinate.
#define SETUP_ADDRESSING            BIT(1)          // I2C addressing mode: 10-bit or 7-bit addressing mode
#define SETUP_I2C_EN                BIT(0)          // Enable the ATCIIC100 I2C controller.

#if APB_CLK_30MHZ
// I2C mode: standard-mode, fast-mode, fast-mode-plus, all based on APB-clk(30MHZ)
#define SETUP_T_SUDAT_STD           (0x3)           // setup time = (4 + 1 + 3) * 33ns = 264ns, Min 250ns
#define SETUP_T_SP_STD              (0x1)           // spikes time = 1 * 33ns = 33ns, Max 50ns
#define SETUP_T_HDDAT_STD           (5)             // hold time = (4 + 1 + 5) * 33ns = 330ns, Min 300ns
#define SETUP_T_SCL_RATIO_STD       (0x0)           // ratio=1, (4 + 1 + 138) * 33ns >= 4000ns, for I2C SCL clock, SCLHI Min 4000ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_STD           (138)           // (4 + 1 + 138 * 1) * 33ns >= 4700ns, SCLLOW Min 4700ns

#define SETUP_T_SUDAT_FAST          (0x0)           // setup time = (4 + 1 + 0) * 33ns = 165ns, Min 100ns
#define SETUP_T_SP_FAST             (0x1)           // spikes time = 1 * 33ns =  33ns, Max 50ns
#define SETUP_T_HDDAT_FAST          (5)             // hold time = (4 + 1 + 5) * 33ns = 330ns, Min 300ns
#define SETUP_T_SCL_RATIO_FAST      (0x1)           // ratio=2, (4 + 1 + 18) * 33ns >= 600ns, for I2C SCL clock, SCLHI Min 600ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_FAST          (18)            // (4 + 1 + 18 * 2) * 33ns >= 1300ns, SCLLOW Min 1300ns

#define SETUP_T_SUDAT_FAST_P        (0x0)           // setup time = (4 + 1 + 0) * 33ns = 165s, Min 50ns
#define SETUP_T_SP_FAST_P           (0x1)           // spikes time = 1 * 33ns = 33ns, Max 50ns
#define SETUP_T_HDDAT_FAST_P        (0x0)           // hold time = (4 + 1 + 0) * 33ns = 165ns, Min 0ns
#define SETUP_T_SCL_RATIO_FAST_P    (0x1)           // ratio=2, (4 + 1 + 6) * 33ns >= 260ns, for I2C SCL clock, SCLHI Min 260ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_FAST_P        (6)             // (4 + 1 + 6 * 2) * 33ns >= 500ns, SCLLOW Min 500ns

#elif APB_CLK_40MHZ
// I2C mode: standard-mode, fast-mode, fast-mode-plus, all based on APB-clk(40MHZ)
#define SETUP_T_SUDAT_STD           (0x4)           // setup time = (4 + 2 + 4) * 25ns = 250ns, Min 250ns
#define SETUP_T_SP_STD              (0x2)           // spikes time = 2 * 25ns = 50ns, Max 50ns
#define SETUP_T_HDDAT_STD           (0x6)           // hold time = (4 + 2 + 6) * 25ns = 300ns, Min 300ns
#define SETUP_T_SCL_RATIO_STD       (0x0)           // ratio=1, (4 + 2 + 182) * 25ns >= 4000ns, for I2C SCL clock, SCLHI Min 4000ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_STD           (182)           // (4 + 2 + 182 * 1) * 25ns >= 4700ns, SCLLOW Min 4700ns

#define SETUP_T_SUDAT_FAST          (0x0)           // setup time = (4 + 2 + 0) * 25ns = 150ns, Min 100ns
#define SETUP_T_SP_FAST             (0x2)           // spikes time = 2 * 25ns = 50ns, Max 50ns
#define SETUP_T_HDDAT_FAST          (0x6)           // hold time = (4 + 2 + 6) * 25ns = 300ns, Min 300ns
#define SETUP_T_SCL_RATIO_FAST      (0x1)           // ratio=2, (4 + 2 + 23) * 25ns >= 600ns, for I2C SCL clock, SCLHI Min 600ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_FAST          (23)            // (4 + 2 + 23 * 2) * 25ns >= 1300ns, SCLLOW Min 1300ns

#define SETUP_T_SUDAT_FAST_P        (0x0)           // setup time = (4 + 2 + 0) * 25ns = 150ns, Min 50ns
#define SETUP_T_SP_FAST_P           (0x2)           // spikes time = 2 * 25ns = 50ns, Max 50ns
#define SETUP_T_HDDAT_FAST_P        (0x0)           // hold time = (4 + 2 + 0) * 25ns = 150ns, Min 0ns
#define SETUP_T_SCL_RATIO_FAST_P    (0x1)           // ratio=2, (4 + 2 + 7) * 25ns >= 260ns, for I2C SCL clock, SCLHI Min 260ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_FAST_P        (7)             // (4 + 2 + 7 * 2) * 25ns >= 500ns, SCLLOW Min 500ns

#elif APB_CLK_60MHZ
// I2C mode: standard-mode, fast-mode, fast-mode-plus, all based on APB-clk(60MHZ)
#define SETUP_T_SUDAT_STD           (0x9)           // setup time = (4 + 3 + 9) * 16ns = 256ns, Min 250ns
#define SETUP_T_SP_STD              (0x3)           // spikes time = 3 * 16ns = 48ns, Max 50ns
#define SETUP_T_HDDAT_STD           (12)            // hold time = (4 + 3 + 12) * 16ns = 304ns, Min 300ns
#define SETUP_T_SCL_RATIO_STD       (0x0)           // ratio=1, (4 + 3 + 287) * 16ns >= 4000ns, for I2C SCL clock, SCLHI Min 4000ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_STD           (287)           // (4 + 3 + 287 * 1) * 16ns >= 4700ns, SCLLOW Min 4700ns

#define SETUP_T_SUDAT_FAST          (0x0)           // setup time = (4 + 3 + 0) * 16ns = 112ns, Min 100ns
#define SETUP_T_SP_FAST             (0x3)           // spikes time = 3 * 16ns =  48ns, Max 50ns
#define SETUP_T_HDDAT_FAST          (12)           // hold time = (4 + 3 + 12) * 16ns = 304ns, Min 300ns
#define SETUP_T_SCL_RATIO_FAST      (0x1)           // ratio=2, (4 + 3 + 38) * 16ns >= 600ns, for I2C SCL clock, SCLHI Min 600ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_FAST          (38)            // (4 + 3 + 38 * 2) * 16ns >= 1300ns, SCLLOW Min 1300ns

#define SETUP_T_SUDAT_FAST_P        (0x0)           // setup time = (4 + 3 + 0) * 16ns = 112ns, Min 50ns
#define SETUP_T_SP_FAST_P           (0x3)           // spikes time = 3 * 16ns = 48ns, Max 50ns
#define SETUP_T_HDDAT_FAST_P        (0x0)           // hold time = (4 + 3 + 0) * 16ns = 112ns, Min 0ns
#define SETUP_T_SCL_RATIO_FAST_P    (0x1)           // ratio=2, (4 + 3 + 13) * 16ns >= 260ns, for I2C SCL clock, SCLHI Min 260ns
// The T_SCLHi value must be greater than T_SP and T_HDDAT values.
#define SETUP_T_SCLHI_FAST_P        (13)             // (4 + 3 + 13 * 2) * 16ns >= 500ns, SCLLOW Min 500ns
#endif

#define PARA_IGNORE                 (0)

#define USE_MANAGER          1
#define USE_SUBORDINATE      0

#define I2C_STATE_RX 0
#define I2C_STATE_TX 1

// ATCIIC100 counter limitation
#define BUFFER_LENGTH 255

// I2C Resource Configuration
typedef struct
{
	I2C_RegDef*         reg;                                                        // I2C register interface
	uint8_t             ip_num;
	uint8_t             overflow_cnt;
	uint32_t            timeout_us;
	uint8_t             timeout_flag;
	uint8_t             reset_on_timeout;
	uint8_t             i2c_state;
	uint8_t*            i2c_ManagerBuffer;
	uint8_t             i2c_SubordinateBuffer[BUFFER_LENGTH];
	volatile uint8_t    i2c_ErrorFlag;
	volatile uint8_t    i2c_InRepeatStartlFlag;
	volatile uint8_t    i2c_SendStopFlag;
	volatile uint8_t    i2c_CmplFlag;
	volatile uint32_t   i2c_RxBufferIndex;
	volatile uint32_t   i2c_RxBufferLength;
	volatile uint32_t   i2c_TxBufferIndex;
	volatile uint32_t   i2c_TxBufferLength;
	void                (*OnSubordinateTransmit)(uint8_t);
	void                (*OnSubordinateReceive)(uint8_t*, int, uint8_t);
} I2C_Driver;

void I2C_Init(I2C_Driver* drv, uint8_t ManagerSubordinate, uint8_t address);
void I2C_SetClock(I2C_Driver* drv, uint32_t frequency);
void I2C_SetTimeout(I2C_Driver* drv, uint32_t timeout, uint8_t resetOnTimeout);
uint8_t I2C_GetTimeoutFlag(I2C_Driver* drv);
void I2C_ClearTimeoutFlag(I2C_Driver* drv);
void I2C_AttachSubordinateTxEvent(I2C_Driver* drv, void (*function)(uint8_t));
void I2C_AttachSubordinateRxEvent(I2C_Driver* drv, void (*function)(uint8_t*, int, uint8_t));
uint8_t I2C_ReadFrom(I2C_Driver* drv, uint8_t address, uint8_t* data, uint32_t length, uint8_t sendStop);
uint8_t I2C_WriteTo(I2C_Driver* drv, uint8_t address, uint8_t* data, uint32_t length, uint8_t sendStop);
uint8_t I2C_Transmit(I2C_Driver* drv, const uint8_t* data, uint32_t length);

extern I2C_Driver I2C_DRV1, I2C_DRV2;

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* __I2C_AE250_H */
