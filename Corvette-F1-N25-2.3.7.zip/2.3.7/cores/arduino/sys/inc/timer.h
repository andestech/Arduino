#ifndef F1_AE250_TIMER_H_
#define F1_AE250_TIMER_H_

#include "ae250.h"
#include "typedef.h"
#include "platform.h"

/***********************************************************************************************
*   MARCOS
************************************************************************************************/
#define TIMER_CLK_SRC_EXT   (0)
#define TIMER_CLK_SRC_APB   (1)

#define TIMER1          0
#define TIMER2          1
#define TIMER3          2
#define TIMER4          3

/***********************************************************************************************
*   SOC Timer definition
************************************************************************************************/

/********************* Bit definition of Timer channel control register **********************/
#define PIT_CCR_CH_MODE			(0x7)
#define PIT_CCR_CH_CLK			(0x1 << 3)
#define PIT_CCR_PWM_PARK		(0x1 << 4)

/**************************************************************************************************
 *   GLOBAL PROTOTYPES
 *************************************************************************************************/

void TIMER_Init(u8 u8Ch, u8 u8Mode, u8 u8ClkSrc, u32 u32LoadCnt);
void TIMER_DeInit(u8 u8Ch);
void TIMER_Start(u8 u8Ch);
void TIMER_Stop(u8 u8Ch);

void TIMER_EnableInt(u8 u8Ch);
void TIMER_DisableInt(u8 u8Ch);
void TIMER_ClearInt(u8 u8Ch);
u32 TIMER_IntStatus(u8 u8Ch);

void TIMER_SetPeriod(u8 u8Ch, u32 u32Period);
u32 TIMER_Read(u8 u8Ch);

#endif /* F1_AE250_TIMER_H_ */
