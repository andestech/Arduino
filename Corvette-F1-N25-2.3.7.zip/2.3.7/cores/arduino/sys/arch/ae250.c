/*
 * Copyright (c) 2012-2017 Andes Technology Corporation
 * All rights reserved.
 *
 */

#include "platform.h"
#include "ae250.h"
#include "uart.h"

/* This must be a leaf function, no child function */
void __platform_init (void)__attribute__((naked));
void __platform_init(void)
{
	/* Do your platform low-level initial */
	/* Enable the Machine-External bit in MIE */
	set_csr(NDS_MIE, MIP_MEIP);

	/* Enable the Machine-Timer bit in MIE */
	//set_csr(NDS_MIE, MIP_MTIP);

	/* Enable the Machine-SWI bit in MIE */
	//set_csr(NDS_MIE, MIP_MSIP);

	/* Enable interrupts in general. */
	set_csr(NDS_MSTATUS, MSTATUS_MIE);

	/* Priority must be set > 0 to trigger the interrupt */
	//__nds__plic_set_priority(IRQ_UART2_SOURCE, 1);

	/* Enable PLIC interrupt PIT source */
	//__nds__plic_enable_interrupt(IRQ_UART2_SOURCE);

	__asm("ret");
}

void reset_handler(void)
{
	extern int main(void);

	/*
	 * Do your system reset handling here
	 */
	/* Enable PLIC features */
	if (read_csr(NDS_MMISC_CTL) & (1 << 1)) {
		/* External PLIC interrupt is vectored */
		__nds__plic_set_feature(NDS_PLIC_FEATURE_PREEMPT | NDS_PLIC_FEATURE_VECTORED);
	} else {
		/* External PLIC interrupt is NOT vectored */
		__nds__plic_set_feature(NDS_PLIC_FEATURE_PREEMPT);
	}

	/* Enable misaligned access and non-blocking load. */
	set_csr(NDS_MMISC_CTL, (1 << 8) | (1 << 6));

	/* Entry function */
	main();
}

/* Define __dso_handle which would be needed for C++ library.
 * Since our elf-toolchain only builds programs with static link,
 * we can directly define 'void *__dso_handle = 0'.  */
void *__dso_handle = 0;
