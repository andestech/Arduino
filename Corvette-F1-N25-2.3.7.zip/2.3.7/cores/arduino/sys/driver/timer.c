/***********************************************************************************************
*   INCLUDES
************************************************************************************************/
#include "timer.h"
#include "int.h"
#include "ae250.h"
#include "platform.h"

/***********************************************************************************************
*   Global variable
************************************************************************************************/
/***********************************************************************************************
@brief:Init specified Timer,set counter,clk source
@para:
        -u8ClkSrc: clock source TIMER_CLK_SRC_EXT/TIMER_CLK_SRC_APB
        -u32LoadCnt:Load value to counter and Load register
************************************************************************************************/
void TIMER_Init(u8 u8Ch, u8 u8Mode, u8 u8ClkSrc, u32 u32LoadCnt)
{
	DEV_PIT->CHNEN &= ~(1 << (4*u8Ch));

	DEV_PIT->CHANNEL[u8Ch].CTRL &= ~(PIT_CCR_CH_MODE);
	DEV_PIT->CHANNEL[u8Ch].CTRL |= u8Mode;

	//Use APB clock
	DEV_PIT->CHANNEL[u8Ch].CTRL &= ~(PIT_CCR_CH_CLK);
	DEV_PIT->CHANNEL[u8Ch].CTRL |= PIT_CCR_CH_CLK;

	DEV_PIT->CHANNEL[u8Ch].RELOAD = u32LoadCnt;
}

/***********************************************************************************************
@brief:Disable Timer clock
@para:
************************************************************************************************/
void TIMER_DeInit(u8 u8Ch)
{
}

/***********************************************************************************************
@brief:Start specified Timer
@para:
************************************************************************************************/
void TIMER_Start(u8 u8Ch)
{
    // CHn_TMR0 = (1 << (4*n))
    DEV_PIT->CHNEN |= (1 << (4*u8Ch));
}

/***********************************************************************************************
@brief:Stop specified Timer
@para:
************************************************************************************************/
void TIMER_Stop(u8 u8Ch)
{
    DEV_PIT->CHNEN &= ~(1 << (4*u8Ch));
}

/***********************************************************************************************
@brief:Enable specified Timer interrupt  function
@para:
***********************************************************************************************/
void TIMER_EnableInt(u8 u8Ch)
{
    DEV_PIT->INTEN |= (1 << (4*u8Ch));
}

/***********************************************************************************************
@brief:Disable specified Timer interrupt  function
@para:
***********************************************************************************************/
void TIMER_DisableInt(u8 u8Ch)
{
    DEV_PIT->INTEN &= ~(1 << (4*u8Ch));
}

void TIMER_ClearInt(u8 u8Ch)
{
	DEV_PIT->INTST = (0xF << (4*u8Ch));
}

u32 TIMER_IntStatus(u8 u8Ch)
{
	return DEV_PIT->INTST & (0xF << (4*u8Ch));
}

void TIMER_SetPeriod(u8 u8Ch, u32 u32Period)
{
	DEV_PIT->CHANNEL[u8Ch].RELOAD = u32Period;
}

u32 TIMER_Read(u8 u8Ch)
{
	return DEV_PIT->CHANNEL[u8Ch].RELOAD - DEV_PIT->CHANNEL[u8Ch].COUNTER;
}
