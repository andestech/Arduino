#include "i2c_drv.h"
#include "Arduino.h"

/* I2C drivers */
I2C_Driver I2C_DRV1 = { .reg = DEV_I2C1, .ip_num = 1, .timeout_us = 25000, .reset_on_timeout = 1 };
I2C_Driver I2C_DRV2 = { .reg = DEV_I2C2, .ip_num = 2, .timeout_us = 25000, .reset_on_timeout = 1 };
static uint32_t i2c_source[3] = {0, IRQ_I2C1_SOURCE, IRQ_I2C2_SOURCE};

// Reset Sequence triggered when manager mode I2C_ReadFrom() or I2C_WriteTo() fail
static void I2C_ResetSequence(I2C_Driver* drv){
	// Read SETUP reg and reset i2c ip then write back SETUP reg
	uint32_t Tmp, Tmp_S = drv->reg->SETUP;
	uint8_t address;
	uint8_t ManagerSubordinate = ( (Tmp_S & SETUP_MANAGER) ? 1 : 0);

	drv->i2c_CmplFlag = 0;
	drv->i2c_SendStopFlag = 1;
	drv->i2c_InRepeatStartlFlag = 0;
	// If subordinate mode, read subordinate address and write back after reset i2c ip
	if (USE_SUBORDINATE == ManagerSubordinate){
		address = (drv->reg->ADDR & SUBORDINATE_ADDR_MSK);
	}

	// I2C reset controller, including disable all I2C interrupts & clear fifo
	Tmp = drv->reg->CMD;
	Tmp &= (~CMD_MSK);
	Tmp |= (CMD_RESET_I2C);
	drv->reg->CMD = Tmp;

	// Write back SETUP reg
	drv->reg->SETUP = Tmp_S;

	if (USE_SUBORDINATE == ManagerSubordinate){
		// Write back subordinate address
		Tmp = drv->reg->ADDR;
		Tmp &= (~ SUBORDINATE_ADDR_MSK);
		Tmp |= (address & (SUBORDINATE_ADDR_MSK));
		drv->reg->ADDR = Tmp;

		// Enable completion & address hit interrupt in subordinate mode
		Tmp = drv->reg->INTEN;
		Tmp |= (IEN_CMPL | IEN_ADDR_HIT);
		drv->reg->INTEN = Tmp;
	}
}

// Send repeated start
static void I2C_ResetFIFO(I2C_Driver* drv){
	// Reset FIFO before transmit
	uint32_t Tmp = drv->reg->CMD;
	Tmp &= (~ CMD_MSK);
	Tmp |= (CMD_CLEAR_FIFO);
	drv->reg->CMD = Tmp;
}


// Send repeated start
static void I2C_RepeatStart(I2C_Driver* drv){
	uint32_t Tmp = 0;
	drv->i2c_InRepeatStartlFlag = 1;

	Tmp = drv->reg->CTRL;
	Tmp &= (~ (CTRL_PHASE_START | CTRL_PHASE_ADDR | CTRL_PHASE_DATA | CTRL_PHASE_STOP | CTRL_DIR | CTRL_DATA_COUNT));
	Tmp |= (CTRL_PHASE_START);
	drv->reg->CTRL = Tmp;

	Tmp = drv->reg->CMD;
	Tmp &= (~ CMD_MSK);
	Tmp |= (CMD_ISSUE_TRANSACTION);
	drv->reg->CMD = Tmp;
}

void I2C_Init(I2C_Driver* drv, uint8_t ManagerSubordinate, uint8_t address)
{
	uint32_t Tmp = 0;

	// Priority must be set > 0 to trigger the interrupt
	__nds__plic_set_priority(i2c_source[drv->ip_num], 1);
	// Enable PLIC interrupt I2C source
	__nds__plic_enable_interrupt(i2c_source[drv->ip_num]);

	drv->i2c_CmplFlag = 0;
	drv->i2c_SendStopFlag = 1;
	drv->i2c_InRepeatStartlFlag = 0;

	// I2C reset controller, including disable all I2C interrupts & clear fifo
	Tmp = drv->reg->CMD;
	Tmp &= (~CMD_MSK);
	Tmp |= (CMD_RESET_I2C);
	drv->reg->CMD = Tmp;

	// I2C setting: speed standard, manager/subordinate mode
	// FIFO(CPU) mode, 7-bit subordinate address, Ctrl enable
	drv->reg->SETUP = 0x0;
	Tmp = drv->reg->SETUP;
	Tmp |=   (( SETUP_T_SUDAT_STD     << 24) |
	          ( SETUP_T_SP_STD        << 21) |
	          ( SETUP_T_HDDAT_STD     << 16) |
	          ( SETUP_T_SCL_RATIO_STD << 13) |
	          ( SETUP_T_SCLHI_STD     <<  4) |
	          ( SETUP_I2C_EN          <<  0) );
	if (USE_MANAGER == ManagerSubordinate) {
		Tmp |= SETUP_MANAGER;
	}
	drv->reg->SETUP = Tmp;

	if (USE_SUBORDINATE == ManagerSubordinate){
		// Set subordinate address
		Tmp = drv->reg->ADDR;
		Tmp &= (~ SUBORDINATE_ADDR_MSK);
		Tmp |= (address & (SUBORDINATE_ADDR_MSK));
		drv->reg->ADDR = Tmp;

		// Enable completion & address hit interrupt in subordinate mode
		Tmp = drv->reg->INTEN;
		Tmp |= (IEN_ADDR_HIT);
		drv->reg->INTEN = Tmp;
	}
}

void I2C_SetClock(I2C_Driver* drv, uint32_t frequency)
{
	uint32_t Tmp = 0;

	Tmp = drv->reg->SETUP;
	// clear previous setting
	Tmp &= (~ (SETUP_T_SUDAT | SETUP_T_SP | SETUP_T_HDDAT | SETUP_T_SCL_RATIO | SETUP_T_SCLHI));

	switch (frequency) {
		case 100000 :
			// I2C speed standard
			Tmp |=   ((SETUP_T_SUDAT_STD     << 24) |
			          (SETUP_T_SP_STD        << 21) |
			          (SETUP_T_HDDAT_STD     << 16) |
			          (SETUP_T_SCL_RATIO_STD << 13) |
			          (SETUP_T_SCLHI_STD     <<  4) );
			break;
		case 400000 :
			// I2C speed fast
			Tmp |=   ((SETUP_T_SUDAT_FAST     << 24) |
			          (SETUP_T_SP_FAST        << 21) |
			          (SETUP_T_HDDAT_FAST     << 16) |
			          (SETUP_T_SCL_RATIO_FAST << 13) |
			          (SETUP_T_SCLHI_FAST     <<  4) );
			break;
		case 1000000 :
			// I2C speed fast plus
			Tmp |=   ((SETUP_T_SUDAT_FAST_P     << 24) |
			          (SETUP_T_SP_FAST_P        << 21) |
			          (SETUP_T_HDDAT_FAST_P     << 16) |
			          (SETUP_T_SCL_RATIO_FAST_P << 13) |
			          (SETUP_T_SCLHI_FAST_P     <<  4) );
			break;
		default:
				;
	}
	drv->reg->SETUP = Tmp;
}

void I2C_SetTimeout(I2C_Driver* drv, uint32_t timeout, uint8_t resetOnTimeout)
{
	drv->timeout_us = timeout;
	drv->timeout_flag = 0;
	drv->reset_on_timeout = resetOnTimeout;
}

uint8_t I2C_GetTimeoutFlag(I2C_Driver* drv)
{
	return drv->timeout_flag;
}

void I2C_ClearTimeoutFlag(I2C_Driver* drv)
{
	drv->timeout_flag = 0;
}

// Sets function called before a subordinate write operation
void I2C_AttachSubordinateTxEvent(I2C_Driver* drv, void (*function)(uint8_t))
{
	drv->OnSubordinateTransmit = function;
}

// Sets function called before a subordinate read operation
void I2C_AttachSubordinateRxEvent(I2C_Driver* drv, void (*function)(uint8_t*, int, uint8_t))
{
	drv->OnSubordinateReceive = function;
}

// Attempts to become bus manager and read a series of bytes from a device on the bus
uint8_t I2C_ReadFrom(I2C_Driver* drv, uint8_t address, uint8_t* data, uint32_t length, uint8_t sendStop)
{
	uint32_t Tmp = 0;
	uint8_t recv_cnt = 0;
	uint8_t timeout_flag = 0;
	drv->i2c_SendStopFlag = sendStop;

	if (length > CTRL_DATA_COUNT) {
		// send_state 1:Data too long to fit in transmit buffer
		length &= CTRL_DATA_COUNT;
	}

	// Initialze receive buffer, index, length and state
	drv->i2c_ManagerBuffer = data;
	drv->i2c_RxBufferIndex = 0;
	drv->i2c_RxBufferLength = length;
	drv->i2c_state = I2C_STATE_RX;

	// Enable ADDR, DATA phase, Receive direction and Data count
	// Enable STOP phase if necessary
	// Enable START phase if not in repeated start state
	Tmp = drv->reg->CTRL;
	Tmp &= (~ (CTRL_PHASE_START | CTRL_PHASE_ADDR | CTRL_PHASE_STOP | CTRL_DIR | CTRL_DATA_COUNT));
	Tmp |= (CTRL_PHASE_ADDR | CTRL_PHASE_DATA | CTRL_DIR | (length & CTRL_DATA_COUNT));
	if (true == drv->i2c_SendStopFlag)
		Tmp |= CTRL_PHASE_STOP;
	if (false == drv->i2c_InRepeatStartlFlag)
		Tmp |= CTRL_PHASE_START;

	drv->reg->CTRL = Tmp;

	// Sets subordinate address
	Tmp = drv->reg->ADDR;
	Tmp &= (~ SUBORDINATE_ADDR_MSK);
	Tmp |= (address & (SUBORDINATE_ADDR_MSK));
	drv->reg->ADDR = Tmp;

	// Enable Complete, ARB_LOSE interrupt and enable FIFO_FULL interrupt if data length larger than fifo size
	Tmp = drv->reg->INTEN;
	Tmp |= (IEN_CMPL | IEN_ARB_LOSE | IEN_FIFO_FULL);
	drv->reg->INTEN = Tmp;

	drv->i2c_ErrorFlag = 0;

	// Reset FIFO before transmit
	I2C_ResetFIFO(drv);

	// I2C Write 0x1 to the Command register to issue the transaction
	Tmp = drv->reg->CMD;
	Tmp &= (~ CMD_MSK);
	Tmp |= (CMD_ISSUE_TRANSACTION);
	drv->reg->CMD = Tmp;

	drv->i2c_CmplFlag = 1;
	uint32_t startMicros = micros();
	// Wait until receive index equal to Length
	while( drv->i2c_CmplFlag ) {
		if ((drv->timeout_us > 0ul) && ((micros() - startMicros) > drv->timeout_us)) {
			timeout_flag = 1;
			drv->timeout_flag = 1;
			if (drv->reset_on_timeout)
				I2C_ResetSequence(drv);
			break;
		} else if (drv->i2c_ErrorFlag) {
			I2C_ResetSequence(drv);
			break;
		}
	}
	recv_cnt = drv->i2c_RxBufferIndex;

	if (!(timeout_flag || drv->i2c_ErrorFlag)) {
		if (drv->i2c_SendStopFlag) {
			// Send stop then reset i2c and release bus
			I2C_ResetSequence(drv);
		} else{
			I2C_RepeatStart(drv);
			// Send restart then clear status and hold bus
			Tmp = drv->reg->STATUS;
			drv->reg->STATUS = (Tmp & STATUS_W1C_ALL);
		}
	}

	return recv_cnt;
}

// Attempts to become bus manager and write a series of bytes to a device on the bus
uint8_t I2C_WriteTo(I2C_Driver* drv, uint8_t address, uint8_t* data, uint32_t length, uint8_t sendStop)
{
	uint32_t Tmp = 0;
	// send_state 0:success
	uint8_t fifo_size, send_state = 0;
	uint8_t timeout_flag = 0;
	drv->i2c_SendStopFlag = sendStop;

	if (length > CTRL_DATA_COUNT) {
		// send_state 1:Data too long to fit in transmit buffer
		length &= CTRL_DATA_COUNT;
		send_state = 1;
	}
	fifo_size = (1 << (drv->reg->CFG + 1));

	// Initialze transmit buffer, index, length and state
	drv->i2c_ManagerBuffer = data;
	drv->i2c_TxBufferLength = length;
	drv->i2c_TxBufferIndex = ( (length > fifo_size) ? fifo_size : length);
	drv->i2c_state = I2C_STATE_TX;

	// Enable ADDR, DATA phase, Transmit direction and Data count
	// Enable STOP phase if necessary
	// Enable START phase if not in repeated start state
	Tmp = drv->reg->CTRL;
	Tmp &= (~ (CTRL_PHASE_START | CTRL_PHASE_ADDR | CTRL_PHASE_STOP | CTRL_DIR | CTRL_DATA_COUNT));
	Tmp |= (CTRL_PHASE_ADDR | CTRL_PHASE_DATA | (length & CTRL_DATA_COUNT));
	if (true == drv->i2c_SendStopFlag)
		Tmp |= CTRL_PHASE_STOP;
	if (false == drv->i2c_InRepeatStartlFlag)
		Tmp |= CTRL_PHASE_START;
	drv->reg->CTRL = Tmp;

	// Sets subordinate address
	Tmp = drv->reg->ADDR;
	Tmp &= (~ SUBORDINATE_ADDR_MSK);
	Tmp |= (address & (SUBORDINATE_ADDR_MSK));
	drv->reg->ADDR = Tmp;

	// Reset FIFO before transmit
	I2C_ResetFIFO(drv);

	// Load data to fifo until fifo full
	for(uint8_t i=0; i < drv->i2c_TxBufferIndex; i++) {
		drv->reg->DATA = (uint8_t)*(drv->i2c_ManagerBuffer + i);
	}

	// Enable Complete, ARB_LOSE FIFO_EMPTY interrupt
	Tmp = drv->reg->INTEN;
	Tmp |= (IEN_CMPL | IEN_ARB_LOSE | IEN_FIFO_EMPTY);
	drv->reg->INTEN = Tmp;

	drv->i2c_ErrorFlag = 0;
	drv->i2c_CmplFlag = 1;

	// I2C Write 0x1 to the Command register to issue the transaction
	Tmp = drv->reg->CMD;
	Tmp &= (~ CMD_MSK);
	Tmp |= (CMD_ISSUE_TRANSACTION);
	drv->reg->CMD = Tmp;

	uint32_t startMicros = micros();
	// Wait until transmit index equal to Length
	while( drv->i2c_CmplFlag ) {
		if ((drv->timeout_us > 0ul) && ((micros() - startMicros) > drv->timeout_us)) {
			timeout_flag = 1;
			drv->timeout_flag = 1;
			// send_state 5:timeout
			send_state = 5;
			if (drv->reset_on_timeout)
				I2C_ResetSequence(drv);
			break;
		} else if (drv->i2c_ErrorFlag) {
			// send_state 4:lost bus arbitration
			send_state = 4;
			I2C_ResetSequence(drv);
			break;
		}
	}

	if (!(timeout_flag || drv->i2c_ErrorFlag)) {
		if (drv->i2c_SendStopFlag) {
			// Send stop then reset i2c and release bus
			I2C_ResetSequence(drv);
		} else {
			I2C_RepeatStart(drv);
			// Send restart then clear status and hold bus
			Tmp = drv->reg->STATUS;
			drv->reg->STATUS = (Tmp & STATUS_W1C_ALL);
		}
	}

	return send_state;
}

// Fills subordinate tx buffer with data and must be called in subordinate tx event callback
uint8_t I2C_Transmit(I2C_Driver* drv, const uint8_t* data, uint32_t length)
{
	uint8_t send_cnt = 0;

	if (drv->i2c_TxBufferLength >= BUFFER_LENGTH) {
		return send_cnt;
	} else {
		for(uint32_t i=0; i<length; i++) {
			drv->i2c_SubordinateBuffer[drv->i2c_TxBufferLength] = (uint8_t)(*(data+i));
			drv->i2c_TxBufferLength++;
			send_cnt++;
			if (drv->i2c_TxBufferLength >= BUFFER_LENGTH) {
				break;
			}
		}
	}
	return send_cnt;
}

static void i2c_irq_handler(I2C_Driver* drv)
{
	uint8_t transmit_cnt, fifo_size = (1 << (drv->reg->CFG + 1));
	volatile uint32_t Tmp_STATUS = drv->reg->STATUS, Tmp_SETUP = drv->reg->SETUP, Tmp_CTRL = drv->reg->CTRL, Tmp_INT;

	// write 1 clear for those interrupts be able to W1C
	drv->reg->STATUS = (Tmp_STATUS & STATUS_W1C_ALL);

	// Here is the entry for subordinate mode to detect subordinate RX/TX action depend on manager action.
	if ( (Tmp_STATUS & STATUS_ADDR_HIT) && (!(Tmp_SETUP & SETUP_MANAGER)) ) {
		if ( I2C_STATE_RX == ((Tmp_CTRL & CTRL_DIR) >> 8) ) {
			// Subordinate mode RX action, initialze rx index and enable FIFO_FULL interrupt
			// Do not reset FIFO because it have received data
			drv->i2c_state = I2C_STATE_RX;
			drv->overflow_cnt = 0;
			drv->i2c_RxBufferIndex = 0;

			// Enable CMPL and FIFO_FULL interrupt
			Tmp_INT = drv->reg->INTEN;
			Tmp_INT |= (IEN_CMPL | IEN_FIFO_FULL);
			drv->reg->INTEN = Tmp_INT;
		} else if ( I2C_STATE_TX == ((Tmp_CTRL & CTRL_DIR) >> 8) ) {
			// Subordinate mode TX action, initialze Tx index, transmit length and enable FIFO_EMPTY interrupt
			drv->i2c_state = I2C_STATE_TX;
			drv->i2c_TxBufferIndex = 0;
			drv->i2c_TxBufferLength = 0;

			// Reset FIFO before transmit
			I2C_ResetFIFO(drv);

			// Function called entry before a subordinate write operation
			drv->OnSubordinateTransmit(drv->ip_num);

			// If user didn't change buffer & length, initialize it
			if (0 == drv->i2c_TxBufferLength) {
				drv->i2c_SubordinateBuffer[0] = 0x00;
				drv->i2c_TxBufferLength = 1;
			}

			// Enable CMPL and FIFO_EMPTY interrupt
			Tmp_INT = drv->reg->INTEN;
			Tmp_INT |= (IEN_CMPL | IEN_FIFO_EMPTY);
			drv->reg->INTEN = Tmp_INT;
		}
	} else if ( Tmp_STATUS & STATUS_CMPL ) {
		// Complete interrupt may be trigger by stop or restart but restart may be the begin or end of data transmit
		uint8_t transmit_cmpl_flag = 1;
		if (Tmp_STATUS & STATUS_START) {
			if (Tmp_SETUP & SETUP_MANAGER) {
				// Manager mode restart after data transmit ip data count should be 0
				transmit_cmpl_flag = ((Tmp_CTRL & CTRL_DATA_COUNT) ? 0 : 1 );
			} else {
				// Subordinate mode restart after data transmit ip data count should be larger than zero
				transmit_cmpl_flag = ((Tmp_CTRL & CTRL_DATA_COUNT) ? 1 : 0 );
			}
		}

		// Manager / Subordinate Send / Recv STOP means that next start is not restart
		if ((Tmp_STATUS & STATUS_STOP) && (Tmp_SETUP & SETUP_MANAGER)) {
			drv->i2c_InRepeatStartlFlag = 0;
		}

		// Complete event is truely transmission complete
		if (transmit_cmpl_flag) {
			if( I2C_STATE_RX == drv->i2c_state ) {
				// RX action, receive remain data
				// Manager receive from ManagerBuffer, Subordinate receive from SubordinateBuffer
				uint8_t* src = ( (Tmp_SETUP & SETUP_MANAGER) ? drv->i2c_ManagerBuffer : drv->i2c_SubordinateBuffer );
				// Manager receive: if CTRL has remain data count, recv not complete, else recv complete, recv number: (BufferLength - BufferIndex),
				// Subordinate receive (CTRL_DATA_COUNT - BufferIndex)
				transmit_cnt = ( (Tmp_SETUP & SETUP_MANAGER) ? ( (Tmp_CTRL & CTRL_DATA_COUNT) ? 0 : (drv->i2c_RxBufferLength - drv->i2c_RxBufferIndex) )
				                                            : ( (Tmp_CTRL & CTRL_DATA_COUNT) - drv->i2c_RxBufferIndex ) );
				for (uint8_t i=0; i<transmit_cnt; i++) {
					// Increase drv->overflow_cnt if rx buffer overflow
					if(drv->i2c_RxBufferIndex >= BUFFER_LENGTH) {
						drv->overflow_cnt++;
					} else {
						src[drv->i2c_RxBufferIndex] = (drv->reg->DATA & (DATA_MSK));
						drv->i2c_RxBufferIndex++;
					}
				}

				// Disable CMPL, ARB_LOSE FIFO_FULL interrupt
				Tmp_INT = drv->reg->INTEN;
				Tmp_INT &= (~( IEN_CMPL | IEN_ARB_LOSE | IEN_FIFO_FULL));
				drv->reg->INTEN = Tmp_INT;

				// Reset FIFO after transmit
				I2C_ResetFIFO(drv);

				// Put a null char to rx buffer if there's room
				if(drv->i2c_RxBufferIndex <= BUFFER_LENGTH){
					drv->i2c_SubordinateBuffer[drv->i2c_RxBufferIndex] = '\0';
				}

				if (Tmp_SETUP & SETUP_MANAGER) {
					drv->i2c_CmplFlag = 0;
				} else {
					// callback to user defined callback
					drv->OnSubordinateReceive(drv->i2c_SubordinateBuffer, drv->i2c_RxBufferIndex, drv->ip_num);

					// Reset rx index after submit rx buffer
					drv->i2c_RxBufferIndex = 0;
				}
			} else if ( I2C_STATE_TX == drv->i2c_state ) {
				// TX action, all data has been transmitted
				// Disable CMPL, ARB_LOSE FIFO_EMPTY interrupt
				Tmp_INT = drv->reg->INTEN;
				Tmp_INT &= (~( IEN_CMPL | IEN_ARB_LOSE | IEN_FIFO_EMPTY));
				drv->reg->INTEN = Tmp_INT;

				// Reset FIFO after transmit
				I2C_ResetFIFO(drv);

				if (Tmp_SETUP & SETUP_MANAGER) {
					drv->i2c_CmplFlag = 0;
				}
			}
		}
	} else if ( Tmp_STATUS & STATUS_FIFO_EMPTY ) {
		// Manager transmit from ManagerBuffer, Subordinate transmit from SubordinateBuffer
		uint8_t* src = ( (Tmp_SETUP & SETUP_MANAGER) ? drv->i2c_ManagerBuffer : drv->i2c_SubordinateBuffer );
		// Write data to fifo until fifo full
		transmit_cnt = ( ((drv->i2c_TxBufferLength-drv->i2c_TxBufferIndex) > fifo_size) ? fifo_size : (drv->i2c_TxBufferLength-drv->i2c_TxBufferIndex));
		for (uint8_t i=0; i<transmit_cnt; i++) {
			drv->reg->DATA = (uint8_t)src[drv->i2c_TxBufferIndex];
			drv->i2c_TxBufferIndex++;
		}
		if (drv->i2c_TxBufferIndex == drv->i2c_TxBufferLength) {
			Tmp_INT = drv->reg->INTEN;
			Tmp_INT &= (~ IEN_FIFO_EMPTY);
			drv->reg->INTEN = Tmp_INT;
		}
	} else if ( Tmp_STATUS & STATUS_FIFO_FULL ) {
		// Manager transmit from ManagerBuffer, Subordinate transmit from SubordinateBuffer
		uint8_t* src = ( (Tmp_SETUP & SETUP_MANAGER) ? drv->i2c_ManagerBuffer : drv->i2c_SubordinateBuffer );
		// Read data from fifo until fifo full
		for (uint8_t i=0; i<fifo_size; i++) {
			// Increase drv->overflow_cnt if rx buffer overflow
			if(drv->i2c_RxBufferIndex >= BUFFER_LENGTH) {
				drv->overflow_cnt++;
			} else {
				src[drv->i2c_RxBufferIndex] = (drv->reg->DATA & (DATA_MSK));
				drv->i2c_RxBufferIndex++;
			}
		}
	}  else if ( Tmp_STATUS & STATUS_ARB_LOSE ) {
		// Disable CMPL, ARB_LOSE interrupt (only triggered in manager mode)
		Tmp_INT = drv->reg->INTEN;
		Tmp_INT &= (~( IEN_CMPL | IEN_ARB_LOSE | STATUS_FIFO_FULL | STATUS_FIFO_EMPTY));
		drv->reg->INTEN = Tmp_INT;

		// Indicate ARB_LOSE happend
		drv->i2c_ErrorFlag = 1;
	}
}

void i2c1_irq_handler()
{
	i2c_irq_handler(&I2C_DRV1);
}

void i2c2_irq_handler()
{
	i2c_irq_handler(&I2C_DRV2);
}
