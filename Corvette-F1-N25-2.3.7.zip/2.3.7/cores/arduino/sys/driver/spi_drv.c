#include "spi_drv.h"

/* SPI IP Register definition */

/* SPI ID revision register */
#define SPI_IDREV_MINOR_BIT           (0)
#define SPI_IDREV_MINOR_MASK          (0xf << 0)
#define SPI_IDREV_MAJOR_BIT           (4)
#define SPI_IDREV_MAJOR_MASK          (0xf << 4)

/* SPI transfer format register */
#define SPI_CPHA                      (1UL << 0)
#define SPI_CPOL                      (1UL << 1)
#define SPI_SUBORDINATE                     (1UL << 2)
#define SPI_LSB                       (1UL << 3)
#define SPI_MERGE                     (1UL << 7)
#define DATA_BITS(data_bits)          (((data_bits - 1) & 0x1f) << 8)

/* SPI transfer control register */
#define SPI_TRANSCTRL_SLV_DATA_ONLY   (0x1 << 31)

// RD/WR transfer count
#define RD_TRANCNT(num)               (((num - 1) & 0x1ff) << 0)
#define WR_TRANCNT(num)               (((num - 1) & 0x1ff) << 12)

// SPI transfer mode
#define SPI_TRANSMODE_WRnRD           (0x0 << 24)
#define SPI_TRANSMODE_WRONLY          (0x1 << 24)
#define SPI_TRANSMODE_RDONLY          (0x2 << 24)
#define SPI_TRANSMODE_WR_RD           (0x3 << 24)
#define SPI_TRANSMODE_RD_WR           (0x4 << 24)
#define SPI_TRANSMODE_WR_DMY_RD       (0x5 << 24)
#define SPI_TRANSMODE_RD_DMY_WR       (0x6 << 24)
#define SPI_TRANSMODE_NONEDATA        (0x7 << 24)
#define SPI_TRANSMODE_DMY_WR          (0x8 << 24)
#define SPI_TRANSMODE_DMY_RD          (0x9 << 24)

/* SPI control register */
#define SPIRST                        (1UL << 0)
#define RXFIFORST                     (1UL << 1)
#define TXFIFORST                     (1UL << 2)
#define RXDMAEN                       (1UL << 3)
#define TXDMAEN                       (1UL << 4)
#define RXTHRES(num)                  (num << 8)
#define TXTHRES(num)                  (num << 16)

#define THRES_MASK_FIFO_16            (0x1f)
#define THRES_MASK_FIFO_128           (0xff)
#define RXTHRES_OFFSET                (8)
#define TXTHRES_OFFSET                (16)

/* SPI status register */
#define SPI_STATUS_SPIACTIVE          (1UL << 0)
#define SPI_STATUS_RXEMPTY            (1UL << 14)
#define SPI_STATUS_RXFULL             (1UL << 15)
#define SPI_STATUS_TXEMPTY            (1UL << 22)
#define SPI_STATUS_TXFULL             (1UL << 23)

#define SPI_STATUS_RXNUM_FIFO_16(status)        (  (status >>  8) & 0x1f )
#define SPI_STATUS_TXNUM_FIFO_16(status)        (  (status >> 16) & 0x1f )
#define SPI_STATUS_RXNUM_FIFO_128(status)       ( ((status >>  8) & 0x3f) | ((status >> (28-6)) & 0xc0) )
#define SPI_STATUS_TXNUM_FIFO_128(status)       ( ((status >> 16) & 0x3f) | ((status >> (24-6)) & 0xc0) )

/* SPI interrupt enable and status register */
#define SPI_RXFIFOOORINT              (1UL << 0)
#define SPI_TXFIFOOURINT              (1UL << 1)
#define SPI_RXFIFOINT                 (1UL << 2)
#define SPI_TXFIFOINT                 (1UL << 3)
#define SPI_ENDINT                    (1UL << 4)
#define SPI_SLVCMD                    (1UL << 5)

/* SPI interface timing register */
#define SPI_TIMING_SCLK_DIV_BIT       (0)
#define SPI_TIMING_SCLK_DIV_MASK      (0xff)

/* SPI configuration register */
#define SPI_RXFIFO_SIZE_BIT_FIFO_16   (0)
#define SPI_RXFIFO_SIZE_MASK_FIFO_16  (0x3 << 0)
#define SPI_TXFIFO_SIZE_BIT_FIFO_16   (4)
#define SPI_TXFIFO_SIZE_MASK_FIFO_16  (0x3 << 4)

#define SPI_RXFIFO_SIZE_BIT_FIFO_128  (0)
#define SPI_RXFIFO_SIZE_MASK_FIFO_128 (0xf << 0)
#define SPI_TXFIFO_SIZE_BIT_FIFO_128  (4)
#define SPI_TXFIFO_SIZE_MASK_FIFO_128 (0xf << 4)

/* SPI drivers */
SPI_Driver SPI_DRV1 = {DEV_SPI1, 1};
SPI_Driver SPI_DRV2 = {DEV_SPI2, 2};
SPI_Driver SPI_DRV3 = {DEV_SPI3, 3};
SPI_Driver SPI_DRV4 = {DEV_SPI4, 4};

/* SPI driver functions */
static inline uint32_t SPI_IpRevisionNumber(SPI_Driver* drv)
{
	return drv->reg->IDREV & (SPI_IDREV_MAJOR_MASK | SPI_IDREV_MINOR_MASK);
}
/* SPI_REVISION_NUM(major, minor): Generate revision number from major and minor number. */
#define SPI_REVISION_NUM(major, minor)  (((major << SPI_IDREV_MAJOR_BIT) & SPI_IDREV_MAJOR_MASK) | (minor & SPI_IDREV_MINOR_MASK))
#define SPI_IP_HAS_FIFO_DEPTH_128(drv)  (SPI_IpRevisionNumber(drv) > SPI_REVISION_NUM(4, 6))


static uint32_t SPI_GetTxfifoSize(SPI_Driver* drv)
{
	if (SPI_IP_HAS_FIFO_DEPTH_128(drv)) {
		return 2 << ((drv->reg->CONFIG & SPI_TXFIFO_SIZE_MASK_FIFO_128) >> SPI_TXFIFO_SIZE_BIT_FIFO_128);
	}
	else {
		return 2 << ((drv->reg->CONFIG & SPI_TXFIFO_SIZE_MASK_FIFO_16) >> SPI_TXFIFO_SIZE_BIT_FIFO_16);
	}
}

static void SPI_DefaultConfig(SPI_Driver* drv)
{
	// set SPI manager mode and disable data merge mode
	drv->reg->TRANSFMT &= ~(SPI_MERGE | SPI_SUBORDINATE);

	// set number of data bits
	drv->reg->TRANSFMT |= DATA_BITS(8);
}

void SPI_Init(SPI_Driver* drv)
{
	// SPI reset
	drv->reg->CTRL = (TXFIFORST | RXFIFORST | SPIRST);

	SPI_DefaultConfig(drv);

	drv->transfer_busy = false;
	drv->txfifo_size = SPI_GetTxfifoSize(drv);
}

void SPI_DeInit(SPI_Driver* drv)
{
	// SPI reset
	drv->reg->CTRL = (TXFIFORST | RXFIFORST | SPIRST);
}

void SPI_SetBitOrder(SPI_Driver* drv, bool msb_first)
{
	if (msb_first)
		drv->reg->TRANSFMT &= ~SPI_LSB;
	else
		drv->reg->TRANSFMT |= SPI_LSB;
}

void SPI_SetClockDivider(SPI_Driver* drv, uint32_t divider_ratio)
{
	uint8_t sclk_div;

	// divider_ratio == 1 or even number between 2 to 510.
	if (divider_ratio == 1)
		sclk_div = 0xff;
	else
		sclk_div = (divider_ratio / 2) - 1;

	drv->reg->TIMING &= ~SPI_TIMING_SCLK_DIV_MASK;
	drv->reg->TIMING |= ((sclk_div << SPI_TIMING_SCLK_DIV_BIT) & SPI_TIMING_SCLK_DIV_MASK);
}

void SPI_SetDataMode(SPI_Driver* drv, uint8_t data_mode)
{
	if (data_mode == SPI_DRV_CPOL0_CPHA0) {
		drv->reg->TRANSFMT &= ~(SPI_CPOL | SPI_CPHA);
	}
	else if (data_mode == SPI_DRV_CPOL0_CPHA1) {
		drv->reg->TRANSFMT &= ~SPI_CPOL;
		drv->reg->TRANSFMT |= SPI_CPHA;
	}
	else if (data_mode == SPI_DRV_CPOL1_CPHA0) {
		drv->reg->TRANSFMT |= SPI_CPOL;
		drv->reg->TRANSFMT &= ~SPI_CPHA;
	}
	else if (data_mode == SPI_DRV_CPOL1_CPHA1) {
		drv->reg->TRANSFMT |= (SPI_CPOL | SPI_CPHA);
	}
}

uint8_t SPI_TransferByte(SPI_Driver* drv, uint8_t data)
{
	// config SPI IP
	drv->reg->TRANSCTRL = (SPI_TRANSMODE_WRnRD | WR_TRANCNT(1) | RD_TRANCNT(1));
	drv->reg->INTREN = SPI_ENDINT;

	drv->reg->DATA = data; // push sending data to TX FIFO
	drv->reg->CMD = 0; // trigger SPI transfer

	// wait for recieving data
	while(!(drv->reg->INTRST & SPI_ENDINT));
	data = drv->reg->DATA; // pop recieving data from RX FIFO

	// disable SPI interrupts and clear interrupt status
	drv->reg->INTREN = 0;
	drv->reg->INTRST = SPI_ENDINT;
	// make sure "write 1 clear" take effect before iret
	drv->reg->INTRST;
	// clear TX/RX FIFOs when SPI complete
	drv->reg->CTRL = (TXFIFORST | RXFIFORST);

	return data;
}

uint16_t SPI_Transfer2Bytes(SPI_Driver* drv, uint16_t data)
{
	// use 16 bits data bits for 2 bytes transfer.
	drv->reg->TRANSFMT |= DATA_BITS(16);

	// config SPI IP
	drv->reg->TRANSCTRL = (SPI_TRANSMODE_WRnRD | WR_TRANCNT(1) | RD_TRANCNT(1));
	drv->reg->INTREN = SPI_ENDINT;

	drv->reg->DATA = data; // push sending data to TX FIFO
	drv->reg->CMD = 0; // trigger SPI transfer

	// wait for recieving data
	while(!(drv->reg->INTRST & SPI_ENDINT));
	data = drv->reg->DATA; // pop recieving data from RX FIFO

	// disable SPI interrupts and clear interrupt status
	drv->reg->INTREN = 0;
	drv->reg->INTRST = SPI_ENDINT;
	// make sure "write 1 clear" take effect before iret
	drv->reg->INTRST;
	// clear TX/RX FIFOs when SPI complete
	drv->reg->CTRL = (TXFIFORST | RXFIFORST);

	// use default data bits (8).
	drv->reg->TRANSFMT |= DATA_BITS(8);

	return data;
}

void spi_event_handler(SPI_Driver* drv)
{
	// read status register
	uint32_t status = drv->reg->INTRST;

	if ((status & SPI_RXFIFOOORINT) || (status & SPI_TXFIFOOURINT)) {
		// TX FIFO underrun or RX FIFO overrun interrupt status

		// Arduino doesn't have error handling, so just do nothing.
	}

	if (status & (SPI_RXFIFOINT | SPI_ENDINT)) {
		// Check RXFIFO at the end of SPI transfer because the last receive data may not exceed RXFIFO threshold.
		uint8_t rx_num;
		if (SPI_IP_HAS_FIFO_DEPTH_128(drv))
			rx_num = SPI_STATUS_RXNUM_FIFO_128(drv->reg->STATUS);
		else
			rx_num = SPI_STATUS_RXNUM_FIFO_16(drv->reg->STATUS);

		int i;
		for (i = 0; i < rx_num; ++i) {
			*drv->xfer.rx_buf = (uint8_t) drv->reg->DATA;
			drv->xfer.rx_buf++;
		}
	}

	if (status & SPI_TXFIFOINT) {
		int i;
		for (i = 0; i < drv->xfer.txfifo_refill; i++) {
			if (drv->xfer.tx_buf >= drv->xfer.tx_buf_limit) {
				// Driver has already pushed all TX data into TX FIFO.
				drv->reg->INTREN &= ~SPI_TXFIFOINT;
				break;
			}

			drv->reg->DATA = (uint8_t) *drv->xfer.tx_buf;
			drv->xfer.tx_buf++;
		}
	}

	if (status & SPI_ENDINT) {
		// disable SPI interrupts and clear interrupt status
		drv->reg->INTREN = 0;

		// clear TX/RX FIFOs when SPI complete
		drv->reg->CTRL = (TXFIFORST | RXFIFORST);

		drv->transfer_busy = false;
	}

	// clear interrupt status
	drv->reg->INTRST = status;
	// make sure "write 1 clear" take effect before iret
	drv->reg->INTRST;
}

void SPI_Transfer(SPI_Driver* drv, uint8_t* data, uint32_t num)
{
	drv->transfer_busy = true;

	/* Note (in-place SPI transfer):
	 *   rx_buf wouldn't break tx_buf's data if rx_buf == tx_buf, due to SPI200 IP's transfer behavior.
	 *
	 *   In one SPI transfer, if only filling n-bytes data to SPI TXFIFO, SPI would only receive n-bytes data at maximum.
	 *   Because when receiving the (n+1)th byte, SPI should send the (n+1)th byte at same time,
	 *   and SPI IP would pause transfer to wait the (n+1) byte data to be pushed into TXFIFO.
	 */
	drv->xfer.rx_buf = drv->xfer.tx_buf = data;
	drv->xfer.tx_buf_limit = data + num;

	uint8_t tx_thres = 2, rx_thres = 2;
	drv->xfer.txfifo_refill = drv->txfifo_size - tx_thres;

	// config SPI IP
	drv->reg->TRANSCTRL = (SPI_TRANSMODE_WRnRD | WR_TRANCNT(num) | RD_TRANCNT(num));
	drv->reg->CTRL = (TXTHRES(tx_thres) | RXTHRES(rx_thres));
	drv->reg->INTREN = (SPI_TXFIFOINT | SPI_RXFIFOINT | SPI_ENDINT);

	drv->reg->CMD = 0; // trigger SPI transfer

	// Event loop for polling-based SPI driver
	while(1) {
		if (!drv->transfer_busy)
			// SPI transfer complete event
			break;

		if (drv->reg->INTRST)
			// polling SPI event
			spi_event_handler(drv);
	}

	return;
}
