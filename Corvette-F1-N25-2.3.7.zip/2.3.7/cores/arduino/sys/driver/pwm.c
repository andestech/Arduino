#include "pwm.h"

#define PIT_CH_CTRL_PWMPARK_MASK         (0x1 << 4)
#define PIT_CH_CTRL_PWMPARK_LOW          (0x0 << 4)
#define PIT_CH_CTRL_PWMPARK_HIGH         (0x1 << 4)

#define PIT_CH_CTRL_CHCLK_MASK           (0x1 << 3)
#define PIT_CH_CTRL_CHCLK_EXTCLK         (0x0 << 3)
#define PIT_CH_CTRL_CHCLK_PCLK           (0x1 << 3)

#define PIT_CH_CTRL_MODE_MASK            0x7
#define PIT_CH_CTRL_MODE_TMR_32BIT       1
#define PIT_CH_CTRL_MODE_TMR_16BIT       2
#define PIT_CH_CTRL_MODE_TMR_8BIT        3
#define PIT_CH_CTRL_MODE_PWM             4
#define PIT_CH_CTRL_MODE_MIXED_16BIT     6
#define PIT_CH_CTRL_MODE_MIXED_8BIT      7

static PIT_RegDef* const DEV_PIT_LIST[PWM_IP_NUM+1] = {
	NULL,
	NULL,
	DEV_PIT2,
	DEV_PIT3,
	DEV_PIT4,
	DEV_PIT5
};

static bool pwm_fully_on_or_off = true;

bool is_pwm_channel_init[PWM_IP_NUM+1][PWM_IP_CHANNEL_NUM] = {
	{false, false, false, false},
	{false, false, false, false},
	{false, false, false, false},
	{false, false, false, false},
	{false, false, false, false},
	{false, false, false, false},
};

void PWM_Init(uint8_t ip_num, uint8_t ch_num)
{
	// disable channel
	DEV_PIT_LIST[ip_num]->CHNEN &= ~(1 << (4*ch_num+3));

	// init PWM mode
	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL |= PIT_CH_CTRL_MODE_PWM;
}

void PWM_Start(uint8_t ip_num, uint8_t ch_num)
{
	if (pwm_fully_on_or_off)
		DEV_PIT_LIST[ip_num]->CHNEN &= ~(1 << (4*ch_num+3));
	else
		DEV_PIT_LIST[ip_num]->CHNEN |= (1 << (4*ch_num+3));
}

void PWM_Stop(uint8_t ip_num, uint8_t ch_num)
{
	DEV_PIT_LIST[ip_num]->CHNEN &= ~(1 << (4*ch_num+3));
}

void PWM_SetPeriod(uint8_t ip_num, uint8_t ch_num, uint16_t hi_cycle, uint16_t lo_cycle)
{
	if (hi_cycle == 0)
		PWM_SetFullyOff(ip_num, ch_num);
	else if(lo_cycle == 0)
		PWM_SetFullyOn(ip_num, ch_num);

	pwm_fully_on_or_off = false;
	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].RELOAD = ((hi_cycle - 1) << 16) | (lo_cycle - 1);
}

void PWM_SetFullyOn(uint8_t ip_num, uint8_t ch_num)
{
	pwm_fully_on_or_off = true;

	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL &= ~PIT_CH_CTRL_PWMPARK_MASK;
	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL |= PIT_CH_CTRL_PWMPARK_HIGH;
}

void PWM_SetFullyOff(uint8_t ip_num, uint8_t ch_num)
{
	pwm_fully_on_or_off = true;

	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL &= ~PIT_CH_CTRL_PWMPARK_MASK;
	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL |= PIT_CH_CTRL_PWMPARK_LOW;
}

void PWM_SetClockSrc(uint8_t ip_num, uint8_t ch_num, uint8_t clk_src)
{
	DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL &= ~PIT_CH_CTRL_CHCLK_MASK;

	if (clk_src == PIT_CLKSRC_APB)
		DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL |= PIT_CH_CTRL_CHCLK_PCLK;
	else if (clk_src == PIT_CLKSRC_EXT)
		DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL |= PIT_CH_CTRL_CHCLK_EXTCLK;
}

uint8_t PWM_GetClockSrc(uint8_t ip_num, uint8_t ch_num)
{
	uint8_t ctrl_clk_src = DEV_PIT_LIST[ip_num]->CHANNEL[ch_num].CTRL & PIT_CH_CTRL_CHCLK_MASK;
	uint8_t clk_src;

	if (ctrl_clk_src == PIT_CH_CTRL_CHCLK_PCLK)
		clk_src = PIT_CLKSRC_APB;
	else // ctrl_clk_src == PIT_CH_CTRL_CHCLK_EXTCLK
		clk_src = PIT_CLKSRC_EXT;

	return clk_src;
}
